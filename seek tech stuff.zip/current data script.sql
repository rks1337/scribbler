delete from Hardware;
delete from License;
delete from Support_Agreement;
delete from Communication_Link
delete from Warranty;
delete from Email_Address;
delete from [User];
delete from Client;
delete from Location;

insert into client (client_key, business_name, street, suburb, state, postcode, billing_name, status, notes)
values
(1, 'Seek Tech', '123 fake street', 'Adelaide', 'SA', 5000,'billing address here', 1,'business 1'),
(2, 'Company 2', '123 fake street', 'Adelaide', 'SA', 1337,'billing address here', 1,'business 2');

insert into dbo.Location (location_key, client_key, location_description, environment, notes)
values
(1, (select client_key from dbo.Client where business_name = 'Seek Tech'), 'Adelaide', 'cold', 'business one'),
(2, (select client_key from dbo.Client where business_name = 'Seek Tech'), 'Shanghai', 'cold', 'business one'),
(3, (select client_key from dbo.Client where business_name = 'Seek Tech'), 'Florida', 'hot', 'business one'),
(4, (select client_key from dbo.Client where business_name = 'Company 2'), 'USA', 'hot', 'business two'),
(5, (select client_key from dbo.Client where business_name = 'Company 2'), 'Tokyo', 'cold', 'business two');

insert into hardware (hardware_key, location_key, category_code, vendor, device_name, model, serial_number,
client_asset_number, date_purchased, warranty_expiry, date_written_off, notes)
values
(1, (select location_key from dbo.Location where location_key = 1),'DA','HPE','SQL - MYOB AE','1950 48G','AV1231312WF','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 1'),
(2, (select location_key from dbo.Location where location_key = 1),'FT','APC','Domain Controller','ABC30','ABC31231V2WF','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 2'),
(3, (select location_key from dbo.Location where location_key = 1),'EG','APC','RD Management Server','1950 48G','AB4314QT09S','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 3'),
(4, (select location_key from dbo.Location where location_key = 1),'GGR','APC','RD Server','ABC30','a5BTfafaw09S','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 4'),
(5, (select location_key from dbo.Location where location_key = 1),'GGR','APC','RD Server','ABC30','aawCT09S','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 5'),
(6, (select location_key from dbo.Location where location_key = 1),'GGR','APC','RD Server','ABC30','adBTcacwc09S','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 6'),
(7, (select location_key from dbo.Location where location_key = 2),'GGR','APC','RD Server','ABC30','ABC214616T09S','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 7'),
(8, (select location_key from dbo.Location where location_key = 1),'GGR','APC','RD Server','ABC30','ABC09S','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 8'),
(9, (select location_key from dbo.Location where location_key = 1),'GGR','APC','RD Server','ABC30','daABCdawd09S','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 9'),
(10, (select location_key from dbo.Location where location_key = 2),'FGH','HPE','SQL - OfficeTech','1950 48G','ABCGR5','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 10'),
(11, (select location_key from dbo.Location where location_key = 1),'FG','APC','Domain Controller','ABC30','23BGR5','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 11'),
(12, (select location_key from dbo.Location where location_key = 1),'DA','HPE','Remote Desktop Server','1950 48G','ABGR5','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 12'),
(13, (select location_key from dbo.Location where location_key = 1),'WE','APC','Legacy Application Server','1950 48G','ABCBGPG','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 13'),
(14, (select location_key from dbo.Location where location_key = 1),'VER','APC','SonicWall','ABC30','ABPG','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 14'),
(15, (select location_key from dbo.Location where location_key = 2),'ERR','APC','Advanced Rack','ABC30','AdaBBdaGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 15'),
(16, (select location_key from dbo.Location where location_key = 2),'ERR','APC','Advanced Rack','ABC30','ABCdadac543BGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 16'),
(17, (select location_key from dbo.Location where location_key = 2),'TVR','APC','OfficeConnect','1950 48G','ABC3-acfaw61002','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 17'),
(18, (select location_key from dbo.Location where location_key = 2),'EFR','HPE','OfficeConnect','ABC30','AB63-61002','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 18'),
(19,(select location_key from dbo.Location where location_key = 2),'FGY','HP','Spare','1950 48G','A13120B1R','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 19'),
(20, (select location_key from dbo.Location where location_key = 2),'EFE','HP','Spare','ABC30','A0B1R','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 20'),
(21, (select location_key from dbo.Location where location_key = 1),'FAE','HP','SQL - MYOB AE','1950 48G','gse213gse24V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 21'),
(22, (select location_key from dbo.Location where location_key = 3),'FAE','HP','SQL - MYOB AE','1950 48G','ABa4V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 22'),
(23, (select location_key from dbo.Location where location_key = 3),'FAE','HP','SQL - MYOB AE','1950 48G','ABsgd634V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 23'),
(24, (select location_key from dbo.Location where location_key = 3),'FAE','HP','SQL - MYOB AE','1950 48G','6422334V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 24'),
(25, (select location_key from dbo.Location where location_key = 4),'FAE','HP','SQL - MYOB AE','1950 48G','A23B4wV2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 25'),
(26, (select location_key from dbo.Location where location_key = 5),'FAE','HP','SQL - MYOB AE','1950 48G','63234V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 26'),
(27, (select location_key from dbo.Location where location_key = 3),'FAE','HP','SQL - MYOB AE','1950 48G','ABC634V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 27'),
(28, (select location_key from dbo.Location where location_key = 4),'FAE','HP','SQL - MYOB AE','1950 48G','AB4V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 28'),
(29, (select location_key from dbo.Location where location_key = 4),'FAE','HP','SQL - MYOB AE','1950 48G','A23BCVaadw2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 29'),
(30, (select location_key from dbo.Location where location_key = 4),'FAE','HP','SQL - MYOB AE','1950 48G','A23BCV2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 30'),
(31, (select location_key from dbo.Location where location_key = 5),'ERR','APC','Advanced Rack','ABC30','ABdhC72fhdBGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 31'),
(32, (select location_key from dbo.Location where location_key = 5),'ERR','APC','Advanced Rack','ABC30','ABC7gs23BGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 32'),
(33, (select location_key from dbo.Location where location_key = 5),'ERR','APC','Advanced Rack','ABC30','723BGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 33'),
(34, (select location_key from dbo.Location where location_key = 5),'ERR','APC','Advanced Rack','ABC30','ABC723BGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 34'),
(35, (select location_key from dbo.Location where location_key = 5),'ERR','APC','Advanced Rack','ABC30','721231233BGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 35'),
(36, (select location_key from dbo.Location where location_key = 5),'ERR','APC','Advanced Rack','ABC30','ABC723213GPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 36');

insert into License([license_key], [location_key], [license_code], [license_category], [product_description], [subscription_type], [pack_cores], [quantity], [licenses_purchased],
[licenses_allocated], [vendor_allocated_key], [date_purchased], [expiry_date], [quote_reference], [ticket_number], [notes])
values
(1, (select location_key from dbo.Location where location_key = 2),'244','UUYJI','Windows Server 2012 R2','19G','123','123','88','4','54','01-01-2018', '01-01-2018', 'DFF', '211', 'license 1'),
(2, (select location_key from dbo.Location where location_key = 1),'232','UUYJI','Windows Server 2012 R2','AB30','133','456','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2131', 'license 1'),
(3, (select location_key from dbo.Location where location_key = 3),'346','UUYJI','Windows Server 2012 R2','198G','50','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2131', 'license 1'),
(4, (select location_key from dbo.Location where location_key = 1),'232','UUYJI','Windows Server 2012 R2','198G','50','123','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2131', 'license 1'),
(5, (select location_key from dbo.Location where location_key = 1),'232','UUYJI','Windows Server 2012 R2','195G','50','123','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2131', 'license 1'),
(6, (select location_key from dbo.Location where location_key = 1),'232','UUYJI','Windows Server 2012 R2','198G','50','123','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2131', 'license 1'),
(7, (select location_key from dbo.Location where location_key = 2),'232','UUYJI','Windows Server 2012 R2','48G','50','123','88','4','674','01-01-2018', '01-01-2018', 'DFFF', '2131', 'license 1'),
(8, (select location_key from dbo.Location where location_key = 1),'232','UUYJI','Windows Server 2012 R2','48G','50','123','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(9, (select location_key from dbo.Location where location_key = 1),'233','UUYJI','Windows Server 2012 R2','48G','50','123','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(10, (select location_key from dbo.Location where location_key = 2),'123','UUYJI','Windows Server 2012 Remote','48G','77','77','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(11, (select location_key from dbo.Location where location_key = 1),'123','UUYJI','Windows Server 2012 Remote','A30','50','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(12, (select location_key from dbo.Location where location_key = 4),'123','UUYJI','Windows Server 2012 Remote','198G','50','123','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(13, (select location_key from dbo.Location where location_key = 1),'123','UUYJI','Windows Server 2012 Remote','148G','50','456','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(14, (select location_key from dbo.Location where location_key = 1),'123','UUYJI','Windows Server 2012 Remote','AB0','50','789','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(15, (select location_key from dbo.Location where location_key = 2),'123','UUYJI','Windows Server 2012 Remote','A30','20','123','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(16, (select location_key from dbo.Location where location_key = 1),'123','UUYJI','SQL Server Standard 2016','AB0','20','123','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(17, (select location_key from dbo.Location where location_key = 2),'123','UUYJI','SQL Server Standard 2016','198G','20','456','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(18, (select location_key from dbo.Location where location_key = 2),'123','UUYJI','SQL Server Standard 2016','A0','5','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(19,(select location_key from dbo.Location where location_key = 2),'123','UUYJI','SQL Server Standard 2016','19G','8','123','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(20, (select location_key from dbo.Location where location_key = 2),'123','UUYJI','SQL Server Standard 2016 - 2 Core','AB0','5','456','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(21, (select location_key from dbo.Location where location_key = 2),'123','UUYJI','MYOB','19','3','789','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(22, (select location_key from dbo.Location where location_key = 3),'123','UUYJI','Webroot','195G','5','789','88','4','74','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(23, (select location_key from dbo.Location where location_key = 3),'123','AAGHY','MYOB','195G','8','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(24, (select location_key from dbo.Location where location_key = 3),'123','AAGHY','Webroot','195G','4','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(25, (select location_key from dbo.Location where location_key = 4),'123','AAGHY','MYOB','19G','77','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(26, (select location_key from dbo.Location where location_key = 5),'123','AAGHY','MYOB','198G','77','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(27, (select location_key from dbo.Location where location_key = 3),'123','AAGHY','MYOB','19G','77','789','88','4','54','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(28, (select location_key from dbo.Location where location_key = 4),'123','AAGHY','Veeam','195G','77','789','88','4','5','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(29, (select location_key from dbo.Location where location_key = 4),'123','AAGHY','Veeam','195G','77','789','88','4','4','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(30, (select location_key from dbo.Location where location_key = 5),'123','AAGHY','LabTech','18G','77','789','88','4','4','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(31, (select location_key from dbo.Location where location_key = 5),'123','AAGHY','LabTech','AB0','77','123','88','4','5','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(32, (select location_key from dbo.Location where location_key = 5),'123','AAGHY','LabTech','AB30','77','123','88','4','6','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(33, (select location_key from dbo.Location where location_key = 5),'123','AAGHY','Symantec.Cloud','A30','77','123','88','4','564','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(34, (select location_key from dbo.Location where location_key = 4),'123','AAGHY','Symantec.Cloud','A30','77','123','88','4','574','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(35, (select location_key from dbo.Location where location_key = 4),'123','AAGHY','Symantec.Cloud','A30','77','123','88','4','574','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1'),
(36, (select location_key from dbo.Location where location_key = 5),'123','AAGHY','Symantec.Cloud','AB0','77','123','88','4','564','01-01-2018', '01-01-2018', 'DFFF', '2132131', 'license 1');

insert into Support_Agreement([agreement_key],[location_key],[agreement_description],[status],[commencement_date],[expiry_date],[notes])
values
(1, (select location_key from dbo.Location where location_key = 1), 'Managed Service', '1', '01-01-2018','01-01-2018', 'SA1'),
(2, (select location_key from dbo.Location where location_key = 2), 'Managed Service', '1', '01-01-2018','01-01-2018', 'SA2'),
(3, (select location_key from dbo.Location where location_key = 3), 'Managed Service', '0', '01-01-2018','01-01-2018', 'SA3'),
(4, (select location_key from dbo.Location where location_key = 4), 'Managed Service', '1', '01-01-2018','01-01-2018', 'SA4'),
(5, (select location_key from dbo.Location where location_key = 5), 'Managed Service', '1', '01-01-2018','01-01-2018', 'SA5'),
(6, (select location_key from dbo.Location where location_key = 2), 'On Demand Support', '1', '01-01-2018','01-01-2018', 'SA6'),
(7, (select location_key from dbo.Location where location_key = 3), 'On Demand Support', '0', '01-01-2018','01-01-2018', 'SA7');

insert into Communication_Link([communication_link_key],[location_key],[communication_vendor],[link_type],[speed],[connectivity_agreement],[commencement_date],[term_months],[expiry_date],[notes])
values
(1, (select location_key from dbo.Location where location_key = 1), 'Vcs', 'Fibre', '100 Mbps', 1, '01-01-2018', 36, '01-01-2018', 'comm note'),
(2, (select location_key from dbo.Location where location_key = 2), 'Vcs', 'Fibre', '100 Mbps', 1, '01-01-2018', 36, '01-01-2018', 'comm note'),
(3, (select location_key from dbo.Location where location_key = 3), 'Vcs', 'Fibre', '100 Mbps', 1, '01-01-2018', 36, '01-01-2018', 'comm note'),
(4, (select location_key from dbo.Location where location_key = 4), 'Vcs', 'Fibre', '100 Mbps', 1, '01-01-2018', 36, '01-01-2018', 'comm note'),
(5, (select location_key from dbo.Location where location_key = 5), 'Vcs', 'Fibre', '100 Mbps', 1, '01-01-2018', 36, '01-01-2018', 'comm note');

insert into Warranty([warranty_key],[location_key],[warranty_type],[status_1],[start_date],[expiry_date],[quote_reference],[ticket_number],[notes])
values
(1, (select location_key from dbo.Location where location_key = 1), 'PS', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(2, (select location_key from dbo.Location where location_key = 1), 'PS', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(3, (select location_key from dbo.Location where location_key = 2), 'PS', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(4, (select location_key from dbo.Location where location_key = 3), 'WAP', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(5, (select location_key from dbo.Location where location_key = 2), 'EXT', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(6, (select location_key from dbo.Location where location_key = 3), 'EXT', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(7, (select location_key from dbo.Location where location_key = 3), 'EXT', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(8, (select location_key from dbo.Location where location_key = 4), 'WAP', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(9, (select location_key from dbo.Location where location_key = 5), 'FIR', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(10, (select location_key from dbo.Location where location_key = 5), 'FIR', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1'),
(11, (select location_key from dbo.Location where location_key = 5), 'FIR', 1, '01-01-2018', '01-01-2018', 'ABC', '123', 'warranty 1');

insert into Email_Address([email_key],[location_key],[email_address],[mailbox_type],[notes])
values
(1, (select location_key from dbo.Location where location_key = 1),'amanda@xyz.com.au', 'UM', 'email'),
(2, (select location_key from dbo.Location where location_key = 1),'lisa@xyz.com.au', 'UM', 'email'),
(3, (select location_key from dbo.Location where location_key = 1),'catherine@xyz.com.au', 'UM', 'email'),
(4, (select location_key from dbo.Location where location_key = 1),'farnk@xyz.com.au', 'UM', 'email'),
(5, (select location_key from dbo.Location where location_key = 1),'ostella@xyz.com.au', 'UM', 'email'),
(6, (select location_key from dbo.Location where location_key = 1),'info@xyz.com.au', 'UM', 'email'),
(7, (select location_key from dbo.Location where location_key = 1),'info@xyz.com.au', 'UM', 'email'),
(8, (select location_key from dbo.Location where location_key = 1),'info@xyz.com.au', 'UM', 'email'),
(9, (select location_key from dbo.Location where location_key = 1),'info@xyz.com.au', 'UM', 'email'),
(10, (select location_key from dbo.Location where location_key = 1),'info@xyz.com.au', 'UM', 'email'),
(12,(select location_key from dbo.Location where location_key = 2),'list@xyz.com.au', 'UM', 'email'),
(13, (select location_key from dbo.Location where location_key = 2),'list@xyz.com.au', 'UM', 'email'),
(14, (select location_key from dbo.Location where location_key = 2),'list@xyz.com.au', 'UM', 'email'),
(15, (select location_key from dbo.Location where location_key = 2),'amanda@xyz.com.au', 'UM', 'email'),
(16, (select location_key from dbo.Location where location_key = 2),'list@xyz.com.au', 'UM', 'email'),
(17, (select location_key from dbo.Location where location_key = 2),'231@xyz.com.au', 'UM', 'email'),
(18, (select location_key from dbo.Location where location_key = 2),'325215@xyz.com.au', 'UM', 'email'),
(19, (select location_key from dbo.Location where location_key = 2),'fafaw@xyz.com.au', 'UM', 'email'),
(20, (select location_key from dbo.Location where location_key = 2),'ama2352135nda@xyz.com.au', 'SM', 'email'),
(21, (select location_key from dbo.Location where location_key = 2),'ama1451nda@xyz.com.au', 'SM', 'email'),
(22, (select location_key from dbo.Location where location_key = 2),'15251@xyz.com.au', 'SM', 'email'),
(23, (select location_key from dbo.Location where location_key = 2),'wed232@xyz.com.au', 'SM', 'email'),
(24, (select location_key from dbo.Location where location_key = 3),'1515@xyz.com.au', 'SM', 'email'),
(25, (select location_key from dbo.Location where location_key = 3),'ama135nda@xyz.com.au', 'SM', 'email'),
(26, (select location_key from dbo.Location where location_key = 3),'315@xyz.com.au', 'SM', 'email'),
(27, (select location_key from dbo.Location where location_key = 3),'135135@xyz.com.au', 'SM', 'email'),
(28, (select location_key from dbo.Location where location_key = 4),'amanda@xyz.com.au', 'DG', 'email'),
(29, (select location_key from dbo.Location where location_key = 4),'list@xyz.com.au', 'DG', 'email'),
(30, (select location_key from dbo.Location where location_key = 5),'wed232@xyz.com.au', 'DG', 'email'),
(31, (select location_key from dbo.Location where location_key = 5),'wed232@xyz.com.au', 'DG', 'email'),
(32, (select location_key from dbo.Location where location_key = 5),'wed232@xyz.com.au', 'DG', 'email'),
(33, (select location_key from dbo.Location where location_key = 5),'wed232@xyz.com.au', 'DG', 'email'),
(34, (select location_key from dbo.Location where location_key = 5),'wed232@xyz.com.au', 'DG', 'email'),
(35, (select location_key from dbo.Location where location_key = 5),'list@xyz.com.au', 'DG', 'email');

insert into [User]([user_key],[location_key],[surname],[firstname],[commencement_date],[termination_date],[suspend_date],[notes])
values
(1, (select location_key from dbo.Location where location_key = 1),'Alley', 'Smith', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(2, (select location_key from dbo.Location where location_key = 1),'Anita', 'Williams', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(3, (select location_key from dbo.Location where location_key = 1),'Andie', 'Sharpe', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(4, (select location_key from dbo.Location where location_key = 1),'Billy', 'Bob', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(5, (select location_key from dbo.Location where location_key = 1),'Brenton', 'Baker', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(6, (select location_key from dbo.Location where location_key = 1),'Carley', 'Grey', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(7, (select location_key from dbo.Location where location_key = 1),'Dexton', 'Day', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(8, (select location_key from dbo.Location where location_key = 2),'Gill', 'Binne', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(9, (select location_key from dbo.Location where location_key = 2),'Harry', 'Hayes', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(10, (select location_key from dbo.Location where location_key = 2),'Peter', 'Pap', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(11, (select location_key from dbo.Location where location_key = 3),'Sally', 'Green', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(12, (select location_key from dbo.Location where location_key = 3),'Voilet', 'Smith', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(13, (select location_key from dbo.Location where location_key = 3),'Terry', 'Kosh', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(14, (select location_key from dbo.Location where location_key = 3),'Natalie', 'Nello', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(15, (select location_key from dbo.Location where location_key = 4),'Kyle', 'Ken', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(16, (select location_key from dbo.Location where location_key = 4),'Emma', 'Barton', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(17, (select location_key from dbo.Location where location_key = 4),'Tanya', 'Telkco', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(18, (select location_key from dbo.Location where location_key = 4),'Joseph', 'Jetto', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(19, (select location_key from dbo.Location where location_key = 5),'Amanda', 'Rossi', '01-01-2018', '01-01-2018', '01-01-2018', 'user'),
(20, (select location_key from dbo.Location where location_key = 5),'Kiron', 'Moretti', '01-01-2018', '01-01-2018', '01-01-2018', 'user');