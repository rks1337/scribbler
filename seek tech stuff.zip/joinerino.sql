select h.device_name from Hardware as h
join Location as l
on l.location_key = h.location_key
join Client as c
on c.client_key = l.client_key
where c.client_key = 1 and l.location_description = 'Adelaide';