insert into client (client_key, business_name, street, suburb, state, postcode, billing_name, status, notes)
values
(1, 'SeekTech', '123 fake street', 'Adelaide', 'SA', 5000,'billing address here', 1,'business 1'),
(2, 'Apple', '123 fake street', 'Reynella', 'SA', 5161,'billing address here', 1,'business 2'),
(3, 'Microsoft', '123 fake street', 'Glenelg', 'SA', 5843,'billing address here', 1,'business 3');

set identity_insert dbo.Location off
insert into dbo.Location (location_key, client_key, location_description, environment, notes)
values
(1, (select client_key from dbo.Client where business_name = 'SeekTech'), 'Adelaide', 'cold', 'business one'),
(2, (select client_key from dbo.Client where business_name = 'SeekTech'), 'Shanghai', 'cold', 'business one'),
(3, (select client_key from dbo.Client where business_name = 'SeekTech'), 'Florida', 'hot', 'business one'),
(4, (select client_key from dbo.Client where business_name = 'Apple'), 'USA', 'hot', 'business two'),
(5, (select client_key from dbo.Client where business_name = 'Apple'), 'China', 'cold', 'business two'),
(6, (select client_key from dbo.Client where business_name = 'Microsoft'), 'USA', 'hot', 'business three');

set identity_insert dbo.Hardware on
insert into hardware (hardware_key, location_key, category_code, vendor, device_name, model, serial_number,
client_asset_number, date_purchased, warranty_expiry, date_written_off, notes)
values
(1, (select location_key from dbo.Location where location_key = 1),'DA','HPE','SQL - MYOB AE','1950 48G','ABC634V2WF','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 1'),
(2, (select location_key from dbo.Location where location_key = 1),'FT','APC','Domain Controller','ABC30','ABC634V2WF','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 2'),
(3, (select location_key from dbo.Location where location_key = 1),'EG','APC','RD Management Server','1950 48G','ABC68GQT09S','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 3'),
(4, (select location_key from dbo.Location where location_key = 1),'GGR','APC','RD Server','ABC30','ABC68GQT09S','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 4'),
(5, (select location_key from dbo.Location where location_key = 1),'FGH','HPE','SQL - OfficeTech','1950 48G','ABC723BGR5','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 5'),
(6, (select location_key from dbo.Location where location_key = 2),'FG','APC','Domain Controller','ABC30','ABC723BGR5','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 6'),
(7, (select location_key from dbo.Location where location_key = 2),'DA','HPE','Remote Desktop Server','1950 48G','ABC723BGR5','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 7'),
(8, (select location_key from dbo.Location where location_key = 2),'WE','APC','Legacy Application Server','1950 48G','ABC723BGPG','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 8'),
(9, (select location_key from dbo.Location where location_key = 3),'VER','APC','SonicWall','ABC30','ABC723BGPG','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 9'),
(10, (select location_key from dbo.Location where location_key = 3),'ERR','APC','Advanced Rack','ABC30','ABC723BGPG','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 10'),
(11, (select location_key from dbo.Location where location_key = 4),'TVR','APC','OfficeConnect','1950 48G','ABC063-61002','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 11'),
(12, (select location_key from dbo.Location where location_key = 5),'EFR','HPE','OfficeConnect','ABC30','ABC063-61002','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 12'),
(13,(select location_key from dbo.Location where location_key = 5),'FGY','HP','Spare','1950 48G','ABCD6310B1R','123','01-01-2018','01-01-2018','01-01-2018', 'hardware 13'),
(14, (select location_key from dbo.Location where location_key = 5),'EFE','HP','Spare','ABC30','ABCD6310B1R','456','01-01-2018','01-01-2018','01-01-2018', 'hardware 14'),
(15, (select location_key from dbo.Location where location_key = 6),'FAE','HP','SQL - MYOB AE','1950 48G','ABC634V2WF','789','01-01-2018','01-01-2018','01-01-2018', 'hardware 15');
