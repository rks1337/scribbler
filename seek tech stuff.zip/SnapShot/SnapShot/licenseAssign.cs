﻿using System;
using System.Windows.Forms;

namespace SnapShot
{
    public partial class licenseAssign : Form
    {
        private int licenseKey;
        private int locationKey;
        private int clientKey;
        private string assignTo;

        public licenseAssign(int licenseKey, int locationKey, int clientKey, string assignTo)
        {
            this.clientKey = clientKey;
            this.licenseKey = licenseKey;
            this.locationKey = locationKey;
            this.assignTo = assignTo;
            InitializeComponent();
        }

        #region general window functions

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void normal_max_button_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
                this.normal_max_button.Text = "□";
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                this.normal_max_button.Text = "■";
            }
        }

        private void minimize_button_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        #endregion general window functions

        /** assigns the license to the selected asset
        */

        private void assignLicenseButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (licenseAssigndataGridView.SelectedRows.Count > 0)
                {
                    int allocated = int.Parse(assignedLicenseCountlabel.Text.ToString());
                    int maxLicenses = int.Parse(totalLicenseCountLabel.Text.ToString());
                    if (allocated < maxLicenses) {
                        if (licenseAssigndataGridView.DataSource == userBindingSource)
                        {
                            //create assignment to user instance in database
                        }
                        else if (licenseAssigndataGridView.DataSource == hardwareBindingSource)
                        {
                            //create assignment to hardware instance in database
                        }

                        licenseTableAdapter1.ChangeLicenseAllocatedValue((allocated + 1), licenseKey);
                        this.setLicenseNumberCounts();
                        MessageBox.Show("assignment succeeded");
                    }
                    else
                    {
                        throw new Exception("Assignment Failed \nMax number of assignable license reached");
                    }
                }
                else
                {
                    throw new Exception("Assignment Failed \nMust select an asset before clicking assign");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void setDisplay()
        {
            try
            {
                //this.setLicenseNumberCounts();
                if (assignTo.Equals("Hardware"))
                {
                    //set datagrid
                    this.licenseAssigndataGridView.AutoGenerateColumns = true;
                    this.licenseAssigndataGridView.DataSource = hardwareBindingSource;
                    this.hardwareTableAdapter.Fill(this.snapShot_DBDataSet.Hardware, clientKey);
                    //show
                    this.licenseAssigndataGridView.Columns[1].Visible = true;
                    this.licenseAssigndataGridView.Columns[3].Visible = true;
                    this.licenseAssigndataGridView.Columns[4].Visible = true;
                    this.licenseAssigndataGridView.Columns[5].Visible = true;

                    //hide
                    this.licenseAssigndataGridView.Columns[0].Visible = false;
                    this.licenseAssigndataGridView.Columns[2].Visible = false;
                    this.licenseAssigndataGridView.Columns[6].Visible = false;
                    this.licenseAssigndataGridView.Columns[7].Visible = false;
                    this.licenseAssigndataGridView.Columns[8].Visible = false;
                    this.licenseAssigndataGridView.Columns[9].Visible = false;
                    this.licenseAssigndataGridView.Columns[10].Visible = false;
                    this.licenseAssigndataGridView.Columns[11].Visible = false;

                    //set full detail display
                    this.licenseAssigntoFullDetailstabControl.SelectTab(1);
                }
                else if (assignTo.Equals("User"))
                {
                    //set datagrid
                    this.licenseAssigndataGridView.DataSource = true;
                    this.licenseAssigndataGridView.DataSource = userBindingSource;
                    this.userTableAdapter.Fill(this.snapShot_DBDataSet.User, clientKey);
                    //show
                    this.licenseAssigndataGridView.Columns[1].Visible = true;
                    this.licenseAssigndataGridView.Columns[2].Visible = true;

                    //hide
                    this.licenseAssigndataGridView.Columns[0].Visible = false;
                    this.licenseAssigndataGridView.Columns[3].Visible = false;
                    this.licenseAssigndataGridView.Columns[4].Visible = false;
                    this.licenseAssigndataGridView.Columns[5].Visible = false;
                    this.licenseAssigndataGridView.Columns[6].Visible = false;

                    //set full detail display
                    this.licenseAssigntoFullDetailstabControl.SelectTab(0);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void setLicenseNumberCounts()
        {
            int assigned = -1;
            int totalNumberLicense = -1;
            if (int.TryParse(licenseTableAdapter1.GetLicenseAssigned(licenseKey).ToString(), out assigned))
            {
                assignedLicenseCountlabel.Text = assigned.ToString();
            }
            if (int.TryParse(licenseTableAdapter1.GetLicensesPurchased(clientKey, licenseKey).ToString(), out totalNumberLicense))
            {
                totalLicenseCountLabel.Text = totalNumberLicense.ToString();
            }
            if ((assigned >= 0) && (totalNumberLicense >= 0))
            {
                unassignLicenseCountLabel.Text = (totalNumberLicense - assigned).ToString();
            }
        }

        private void licenseAssign_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'snapShot_DBDataSet.User' table. You can move, or remove it, as needed.
            this.setDisplay();
        }

        private void licenseAssigndataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (licenseAssigndataGridView.SelectedRows.Count > 0)
            {
                if (this.licenseAssigndataGridView.DataSource == hardwareBindingSource)
                {
                    hwCategoryCodeTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[1].Value.ToString();
                    hwVendorTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[2].Value.ToString();
                    hwDeviceNameTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[3].Value.ToString();
                    hwModelTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[4].Value.ToString();
                    hwSerialNumTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[5].Value.ToString();
                    hwClientAssestTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[6].Value.ToString();
                    hwDatePurchasedPicker.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[7].Value.ToString();
                    hwWarrantyExpPicker.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[8].Value.ToString();
                    hwDateWrittenOffPicker.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[9].Value.ToString();
                    hwNotesTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[10].Value.ToString();
                }
                else if (this.licenseAssigndataGridView.DataSource == userBindingSource)
                {
                    userSurnameTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[1].Value.ToString();
                    userFirstNameTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[2].Value.ToString();
                    userCommenceDatePicker.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[3].Value.ToString();
                    userTerminationDatePicker.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[4].Value.ToString();
                    userSuspendDatePicker.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[5].Value.ToString();
                    userNotesTxtBox.Text = this.licenseAssigndataGridView.SelectedRows[0].Cells[6].Value.ToString();
                }
            }
        }
    }
}