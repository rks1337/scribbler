﻿namespace SnapShot
{
    partial class licenseAssign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.skinny_horizontal_bar = new System.Windows.Forms.FlowLayoutPanel();
            this.exit_button = new System.Windows.Forms.Button();
            this.normal_max_button = new System.Windows.Forms.Button();
            this.minimize_button = new System.Windows.Forms.Button();
            this.licenseAssignmentCountPanel = new System.Windows.Forms.Panel();
            this.totalLicenseCountLabel = new System.Windows.Forms.Label();
            this.unassignLicenseCountLabel = new System.Windows.Forms.Label();
            this.assignedLicenseCountlabel = new System.Windows.Forms.Label();
            this.totalLicenseslabel = new System.Windows.Forms.Label();
            this.unassignedlabel = new System.Windows.Forms.Label();
            this.assignedlabel = new System.Windows.Forms.Label();
            this.licenseAssigndataGridView = new System.Windows.Forms.DataGridView();
            this.licenseAssigntoFullDetailstabControl = new System.Windows.Forms.TabControl();
            this.licenseToUserAssignPanel = new System.Windows.Forms.TabPage();
            this.userSuspendDatePicker = new System.Windows.Forms.DateTimePicker();
            this.userNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.userTerminationDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label30 = new System.Windows.Forms.Label();
            this.userCommenceDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label31 = new System.Windows.Forms.Label();
            this.userFirstNameTxtBox = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.userSurnameTxtBox = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.userToHardwareAssignPage = new System.Windows.Forms.TabPage();
            this.hwDateWrittenOffPicker = new System.Windows.Forms.DateTimePicker();
            this.hwWarrantyExpPicker = new System.Windows.Forms.DateTimePicker();
            this.hwDatePurchasedPicker = new System.Windows.Forms.DateTimePicker();
            this.hwNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.hwClientAssestTxtBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.hwSerialNumTxtBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.hwModelTxtBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.hwDeviceNameTxtBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.hwVendorTxtBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.hwCategoryCodeTxtBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.assignButtonPanel = new System.Windows.Forms.Panel();
            this.assignLicenseButton = new System.Windows.Forms.Button();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.snapShot_DBDataSet = new SnapShot.SnapShot_DBDataSet();
            this.hardwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hardwareTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.HardwareTableAdapter();
            this.userTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.UserTableAdapter();
            this.licenseTableAdapter1 = new SnapShot.SnapShot_DBDataSetTableAdapters.LicenseTableAdapter();
            this.licenseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.skinny_horizontal_bar.SuspendLayout();
            this.licenseAssignmentCountPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licenseAssigndataGridView)).BeginInit();
            this.licenseAssigntoFullDetailstabControl.SuspendLayout();
            this.licenseToUserAssignPanel.SuspendLayout();
            this.userToHardwareAssignPage.SuspendLayout();
            this.assignButtonPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // skinny_horizontal_bar
            // 
            this.skinny_horizontal_bar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.skinny_horizontal_bar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.skinny_horizontal_bar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.skinny_horizontal_bar.Controls.Add(this.exit_button);
            this.skinny_horizontal_bar.Controls.Add(this.normal_max_button);
            this.skinny_horizontal_bar.Controls.Add(this.minimize_button);
            this.skinny_horizontal_bar.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.skinny_horizontal_bar.Location = new System.Drawing.Point(0, 0);
            this.skinny_horizontal_bar.Name = "skinny_horizontal_bar";
            this.skinny_horizontal_bar.Size = new System.Drawing.Size(884, 36);
            this.skinny_horizontal_bar.TabIndex = 3;
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.Transparent;
            this.exit_button.FlatAppearance.BorderSize = 0;
            this.exit_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(15)))), ((int)(((byte)(29)))));
            this.exit_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(17)))), ((int)(((byte)(35)))));
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.ForeColor = System.Drawing.Color.Gray;
            this.exit_button.Location = new System.Drawing.Point(843, 3);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(36, 31);
            this.exit_button.TabIndex = 0;
            this.exit_button.Text = "x";
            this.exit_button.UseCompatibleTextRendering = true;
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // normal_max_button
            // 
            this.normal_max_button.BackColor = System.Drawing.Color.Transparent;
            this.normal_max_button.FlatAppearance.BorderSize = 0;
            this.normal_max_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.normal_max_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.normal_max_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.normal_max_button.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.normal_max_button.ForeColor = System.Drawing.Color.Gray;
            this.normal_max_button.Location = new System.Drawing.Point(801, 3);
            this.normal_max_button.Name = "normal_max_button";
            this.normal_max_button.Padding = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.normal_max_button.Size = new System.Drawing.Size(36, 31);
            this.normal_max_button.TabIndex = 1;
            this.normal_max_button.Text = "■";
            this.normal_max_button.UseCompatibleTextRendering = true;
            this.normal_max_button.UseVisualStyleBackColor = false;
            this.normal_max_button.Click += new System.EventHandler(this.normal_max_button_Click);
            // 
            // minimize_button
            // 
            this.minimize_button.BackColor = System.Drawing.Color.Transparent;
            this.minimize_button.FlatAppearance.BorderSize = 0;
            this.minimize_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.minimize_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.minimize_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimize_button.ForeColor = System.Drawing.Color.Gray;
            this.minimize_button.Location = new System.Drawing.Point(759, 3);
            this.minimize_button.Name = "minimize_button";
            this.minimize_button.Size = new System.Drawing.Size(36, 31);
            this.minimize_button.TabIndex = 2;
            this.minimize_button.Text = "-";
            this.minimize_button.UseCompatibleTextRendering = true;
            this.minimize_button.UseVisualStyleBackColor = false;
            this.minimize_button.Click += new System.EventHandler(this.minimize_button_Click);
            // 
            // licenseAssignmentCountPanel
            // 
            this.licenseAssignmentCountPanel.BackColor = System.Drawing.Color.White;
            this.licenseAssignmentCountPanel.Controls.Add(this.totalLicenseCountLabel);
            this.licenseAssignmentCountPanel.Controls.Add(this.unassignLicenseCountLabel);
            this.licenseAssignmentCountPanel.Controls.Add(this.assignedLicenseCountlabel);
            this.licenseAssignmentCountPanel.Controls.Add(this.totalLicenseslabel);
            this.licenseAssignmentCountPanel.Controls.Add(this.unassignedlabel);
            this.licenseAssignmentCountPanel.Controls.Add(this.assignedlabel);
            this.licenseAssignmentCountPanel.Location = new System.Drawing.Point(0, 37);
            this.licenseAssignmentCountPanel.Name = "licenseAssignmentCountPanel";
            this.licenseAssignmentCountPanel.Size = new System.Drawing.Size(136, 307);
            this.licenseAssignmentCountPanel.TabIndex = 4;
            // 
            // totalLicenseCountLabel
            // 
            this.totalLicenseCountLabel.AutoSize = true;
            this.totalLicenseCountLabel.Location = new System.Drawing.Point(3, 102);
            this.totalLicenseCountLabel.Name = "totalLicenseCountLabel";
            this.totalLicenseCountLabel.Size = new System.Drawing.Size(13, 13);
            this.totalLicenseCountLabel.TabIndex = 8;
            this.totalLicenseCountLabel.Text = "0";
            // 
            // unassignLicenseCountLabel
            // 
            this.unassignLicenseCountLabel.AutoSize = true;
            this.unassignLicenseCountLabel.Location = new System.Drawing.Point(3, 62);
            this.unassignLicenseCountLabel.Name = "unassignLicenseCountLabel";
            this.unassignLicenseCountLabel.Size = new System.Drawing.Size(13, 13);
            this.unassignLicenseCountLabel.TabIndex = 7;
            this.unassignLicenseCountLabel.Text = "0";
            // 
            // assignedLicenseCountlabel
            // 
            this.assignedLicenseCountlabel.AutoSize = true;
            this.assignedLicenseCountlabel.Location = new System.Drawing.Point(3, 22);
            this.assignedLicenseCountlabel.Name = "assignedLicenseCountlabel";
            this.assignedLicenseCountlabel.Size = new System.Drawing.Size(13, 13);
            this.assignedLicenseCountlabel.TabIndex = 5;
            this.assignedLicenseCountlabel.Text = "0";
            // 
            // totalLicenseslabel
            // 
            this.totalLicenseslabel.AutoSize = true;
            this.totalLicenseslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLicenseslabel.Location = new System.Drawing.Point(3, 82);
            this.totalLicenseslabel.Name = "totalLicenseslabel";
            this.totalLicenseslabel.Size = new System.Drawing.Size(100, 17);
            this.totalLicenseslabel.TabIndex = 6;
            this.totalLicenseslabel.Text = "Total Licenses";
            // 
            // unassignedlabel
            // 
            this.unassignedlabel.AutoSize = true;
            this.unassignedlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unassignedlabel.Location = new System.Drawing.Point(3, 42);
            this.unassignedlabel.Name = "unassignedlabel";
            this.unassignedlabel.Size = new System.Drawing.Size(88, 17);
            this.unassignedlabel.TabIndex = 5;
            this.unassignedlabel.Text = "Un-assigned";
            // 
            // assignedlabel
            // 
            this.assignedlabel.AutoSize = true;
            this.assignedlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assignedlabel.Location = new System.Drawing.Point(3, 2);
            this.assignedlabel.Name = "assignedlabel";
            this.assignedlabel.Size = new System.Drawing.Size(66, 17);
            this.assignedlabel.TabIndex = 0;
            this.assignedlabel.Text = "Assigned";
            // 
            // licenseAssigndataGridView
            // 
            this.licenseAssigndataGridView.AllowUserToAddRows = false;
            this.licenseAssigndataGridView.AllowUserToDeleteRows = false;
            this.licenseAssigndataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.licenseAssigndataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.licenseAssigndataGridView.BackgroundColor = System.Drawing.Color.White;
            this.licenseAssigndataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.licenseAssigndataGridView.Location = new System.Drawing.Point(136, 37);
            this.licenseAssigndataGridView.Name = "licenseAssigndataGridView";
            this.licenseAssigndataGridView.ReadOnly = true;
            this.licenseAssigndataGridView.Size = new System.Drawing.Size(447, 307);
            this.licenseAssigndataGridView.TabIndex = 5;
            this.licenseAssigndataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.licenseAssigndataGridView_CellContentClick);
            // 
            // licenseAssigntoFullDetailstabControl
            // 
            this.licenseAssigntoFullDetailstabControl.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.licenseAssigntoFullDetailstabControl.Controls.Add(this.licenseToUserAssignPanel);
            this.licenseAssigntoFullDetailstabControl.Controls.Add(this.userToHardwareAssignPage);
            this.licenseAssigntoFullDetailstabControl.Cursor = System.Windows.Forms.Cursors.Default;
            this.licenseAssigntoFullDetailstabControl.Location = new System.Drawing.Point(589, 42);
            this.licenseAssigntoFullDetailstabControl.Name = "licenseAssigntoFullDetailstabControl";
            this.licenseAssigntoFullDetailstabControl.SelectedIndex = 0;
            this.licenseAssigntoFullDetailstabControl.Size = new System.Drawing.Size(295, 266);
            this.licenseAssigntoFullDetailstabControl.TabIndex = 6;
            this.licenseAssigntoFullDetailstabControl.TabStop = false;
            // 
            // licenseToUserAssignPanel
            // 
            this.licenseToUserAssignPanel.AutoScroll = true;
            this.licenseToUserAssignPanel.Controls.Add(this.userSuspendDatePicker);
            this.licenseToUserAssignPanel.Controls.Add(this.userNotesTxtBox);
            this.licenseToUserAssignPanel.Controls.Add(this.label27);
            this.licenseToUserAssignPanel.Controls.Add(this.label29);
            this.licenseToUserAssignPanel.Controls.Add(this.userTerminationDatePicker);
            this.licenseToUserAssignPanel.Controls.Add(this.label30);
            this.licenseToUserAssignPanel.Controls.Add(this.userCommenceDatePicker);
            this.licenseToUserAssignPanel.Controls.Add(this.label31);
            this.licenseToUserAssignPanel.Controls.Add(this.userFirstNameTxtBox);
            this.licenseToUserAssignPanel.Controls.Add(this.label38);
            this.licenseToUserAssignPanel.Controls.Add(this.userSurnameTxtBox);
            this.licenseToUserAssignPanel.Controls.Add(this.label39);
            this.licenseToUserAssignPanel.Location = new System.Drawing.Point(4, 25);
            this.licenseToUserAssignPanel.Name = "licenseToUserAssignPanel";
            this.licenseToUserAssignPanel.Padding = new System.Windows.Forms.Padding(3);
            this.licenseToUserAssignPanel.Size = new System.Drawing.Size(287, 237);
            this.licenseToUserAssignPanel.TabIndex = 0;
            // 
            // userSuspendDatePicker
            // 
            this.userSuspendDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.userSuspendDatePicker.Location = new System.Drawing.Point(123, 132);
            this.userSuspendDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.userSuspendDatePicker.Name = "userSuspendDatePicker";
            this.userSuspendDatePicker.Size = new System.Drawing.Size(146, 20);
            this.userSuspendDatePicker.TabIndex = 36;
            // 
            // userNotesTxtBox
            // 
            this.userNotesTxtBox.Location = new System.Drawing.Point(123, 163);
            this.userNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.userNotesTxtBox.Name = "userNotesTxtBox";
            this.userNotesTxtBox.ReadOnly = true;
            this.userNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.userNotesTxtBox.TabIndex = 37;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(5, 166);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(35, 13);
            this.label27.TabIndex = 41;
            this.label27.Text = "Notes";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(5, 136);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 13);
            this.label29.TabIndex = 40;
            this.label29.Text = "Suspend Date";
            // 
            // userTerminationDatePicker
            // 
            this.userTerminationDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.userTerminationDatePicker.Location = new System.Drawing.Point(123, 104);
            this.userTerminationDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.userTerminationDatePicker.Name = "userTerminationDatePicker";
            this.userTerminationDatePicker.Size = new System.Drawing.Size(146, 20);
            this.userTerminationDatePicker.TabIndex = 35;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(5, 108);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(88, 13);
            this.label30.TabIndex = 39;
            this.label30.Text = "Termination Date";
            // 
            // userCommenceDatePicker
            // 
            this.userCommenceDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.userCommenceDatePicker.Location = new System.Drawing.Point(123, 74);
            this.userCommenceDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.userCommenceDatePicker.Name = "userCommenceDatePicker";
            this.userCommenceDatePicker.Size = new System.Drawing.Size(146, 20);
            this.userCommenceDatePicker.TabIndex = 34;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(5, 78);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(109, 13);
            this.label31.TabIndex = 38;
            this.label31.Text = "Commencement Date";
            // 
            // userFirstNameTxtBox
            // 
            this.userFirstNameTxtBox.Location = new System.Drawing.Point(123, 41);
            this.userFirstNameTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.userFirstNameTxtBox.Name = "userFirstNameTxtBox";
            this.userFirstNameTxtBox.ReadOnly = true;
            this.userFirstNameTxtBox.Size = new System.Drawing.Size(146, 20);
            this.userFirstNameTxtBox.TabIndex = 32;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(5, 44);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(82, 13);
            this.label38.TabIndex = 33;
            this.label38.Text = "User First Name";
            // 
            // userSurnameTxtBox
            // 
            this.userSurnameTxtBox.Location = new System.Drawing.Point(123, 13);
            this.userSurnameTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.userSurnameTxtBox.Name = "userSurnameTxtBox";
            this.userSurnameTxtBox.ReadOnly = true;
            this.userSurnameTxtBox.Size = new System.Drawing.Size(146, 20);
            this.userSurnameTxtBox.TabIndex = 31;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(5, 15);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(74, 13);
            this.label39.TabIndex = 30;
            this.label39.Text = "User Surname";
            // 
            // userToHardwareAssignPage
            // 
            this.userToHardwareAssignPage.AutoScroll = true;
            this.userToHardwareAssignPage.Controls.Add(this.hwDateWrittenOffPicker);
            this.userToHardwareAssignPage.Controls.Add(this.hwWarrantyExpPicker);
            this.userToHardwareAssignPage.Controls.Add(this.hwDatePurchasedPicker);
            this.userToHardwareAssignPage.Controls.Add(this.hwNotesTxtBox);
            this.userToHardwareAssignPage.Controls.Add(this.label11);
            this.userToHardwareAssignPage.Controls.Add(this.label10);
            this.userToHardwareAssignPage.Controls.Add(this.label9);
            this.userToHardwareAssignPage.Controls.Add(this.label8);
            this.userToHardwareAssignPage.Controls.Add(this.hwClientAssestTxtBox);
            this.userToHardwareAssignPage.Controls.Add(this.label7);
            this.userToHardwareAssignPage.Controls.Add(this.hwSerialNumTxtBox);
            this.userToHardwareAssignPage.Controls.Add(this.label6);
            this.userToHardwareAssignPage.Controls.Add(this.hwModelTxtBox);
            this.userToHardwareAssignPage.Controls.Add(this.label5);
            this.userToHardwareAssignPage.Controls.Add(this.hwDeviceNameTxtBox);
            this.userToHardwareAssignPage.Controls.Add(this.label4);
            this.userToHardwareAssignPage.Controls.Add(this.hwVendorTxtBox);
            this.userToHardwareAssignPage.Controls.Add(this.label3);
            this.userToHardwareAssignPage.Controls.Add(this.hwCategoryCodeTxtBox);
            this.userToHardwareAssignPage.Controls.Add(this.label2);
            this.userToHardwareAssignPage.Location = new System.Drawing.Point(4, 25);
            this.userToHardwareAssignPage.Name = "userToHardwareAssignPage";
            this.userToHardwareAssignPage.Padding = new System.Windows.Forms.Padding(3);
            this.userToHardwareAssignPage.Size = new System.Drawing.Size(287, 237);
            this.userToHardwareAssignPage.TabIndex = 1;
            // 
            // hwDateWrittenOffPicker
            // 
            this.hwDateWrittenOffPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.hwDateWrittenOffPicker.Location = new System.Drawing.Point(123, 231);
            this.hwDateWrittenOffPicker.Margin = new System.Windows.Forms.Padding(2);
            this.hwDateWrittenOffPicker.Name = "hwDateWrittenOffPicker";
            this.hwDateWrittenOffPicker.Size = new System.Drawing.Size(146, 20);
            this.hwDateWrittenOffPicker.TabIndex = 32;
            // 
            // hwWarrantyExpPicker
            // 
            this.hwWarrantyExpPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.hwWarrantyExpPicker.Location = new System.Drawing.Point(123, 201);
            this.hwWarrantyExpPicker.Margin = new System.Windows.Forms.Padding(2);
            this.hwWarrantyExpPicker.Name = "hwWarrantyExpPicker";
            this.hwWarrantyExpPicker.Size = new System.Drawing.Size(146, 20);
            this.hwWarrantyExpPicker.TabIndex = 30;
            // 
            // hwDatePurchasedPicker
            // 
            this.hwDatePurchasedPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.hwDatePurchasedPicker.Location = new System.Drawing.Point(123, 171);
            this.hwDatePurchasedPicker.Margin = new System.Windows.Forms.Padding(2);
            this.hwDatePurchasedPicker.Name = "hwDatePurchasedPicker";
            this.hwDatePurchasedPicker.Size = new System.Drawing.Size(146, 20);
            this.hwDatePurchasedPicker.TabIndex = 29;
            // 
            // hwNotesTxtBox
            // 
            this.hwNotesTxtBox.Location = new System.Drawing.Point(123, 260);
            this.hwNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwNotesTxtBox.Name = "hwNotesTxtBox";
            this.hwNotesTxtBox.ReadOnly = true;
            this.hwNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwNotesTxtBox.TabIndex = 33;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 263);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 38;
            this.label11.Text = "Notes";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 235);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 13);
            this.label10.TabIndex = 37;
            this.label10.Text = "Date Written-Off";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 205);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "Warranty Expiry";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 175);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 13);
            this.label8.TabIndex = 35;
            this.label8.Text = "Date Purchased";
            // 
            // hwClientAssestTxtBox
            // 
            this.hwClientAssestTxtBox.Location = new System.Drawing.Point(123, 140);
            this.hwClientAssestTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwClientAssestTxtBox.Name = "hwClientAssestTxtBox";
            this.hwClientAssestTxtBox.ReadOnly = true;
            this.hwClientAssestTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwClientAssestTxtBox.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 142);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 13);
            this.label7.TabIndex = 34;
            this.label7.Text = "Client Assest Number";
            // 
            // hwSerialNumTxtBox
            // 
            this.hwSerialNumTxtBox.Location = new System.Drawing.Point(123, 110);
            this.hwSerialNumTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwSerialNumTxtBox.Name = "hwSerialNumTxtBox";
            this.hwSerialNumTxtBox.ReadOnly = true;
            this.hwSerialNumTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwSerialNumTxtBox.TabIndex = 26;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 112);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "Serial Number";
            // 
            // hwModelTxtBox
            // 
            this.hwModelTxtBox.Location = new System.Drawing.Point(123, 82);
            this.hwModelTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwModelTxtBox.Name = "hwModelTxtBox";
            this.hwModelTxtBox.ReadOnly = true;
            this.hwModelTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwModelTxtBox.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 85);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "Model";
            // 
            // hwDeviceNameTxtBox
            // 
            this.hwDeviceNameTxtBox.Location = new System.Drawing.Point(123, 56);
            this.hwDeviceNameTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwDeviceNameTxtBox.Name = "hwDeviceNameTxtBox";
            this.hwDeviceNameTxtBox.ReadOnly = true;
            this.hwDeviceNameTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwDeviceNameTxtBox.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 59);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Device Name";
            // 
            // hwVendorTxtBox
            // 
            this.hwVendorTxtBox.Location = new System.Drawing.Point(123, 29);
            this.hwVendorTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwVendorTxtBox.Name = "hwVendorTxtBox";
            this.hwVendorTxtBox.ReadOnly = true;
            this.hwVendorTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwVendorTxtBox.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 32);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Vendor";
            // 
            // hwCategoryCodeTxtBox
            // 
            this.hwCategoryCodeTxtBox.Location = new System.Drawing.Point(123, 1);
            this.hwCategoryCodeTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwCategoryCodeTxtBox.Name = "hwCategoryCodeTxtBox";
            this.hwCategoryCodeTxtBox.ReadOnly = true;
            this.hwCategoryCodeTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwCategoryCodeTxtBox.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Category Code";
            // 
            // assignButtonPanel
            // 
            this.assignButtonPanel.BackColor = System.Drawing.Color.White;
            this.assignButtonPanel.Controls.Add(this.assignLicenseButton);
            this.assignButtonPanel.Location = new System.Drawing.Point(589, 310);
            this.assignButtonPanel.Name = "assignButtonPanel";
            this.assignButtonPanel.Size = new System.Drawing.Size(295, 33);
            this.assignButtonPanel.TabIndex = 7;
            // 
            // assignLicenseButton
            // 
            this.assignLicenseButton.BackColor = System.Drawing.Color.White;
            this.assignLicenseButton.Location = new System.Drawing.Point(8, 4);
            this.assignLicenseButton.Name = "assignLicenseButton";
            this.assignLicenseButton.Size = new System.Drawing.Size(75, 23);
            this.assignLicenseButton.TabIndex = 0;
            this.assignLicenseButton.Text = "Assign";
            this.assignLicenseButton.UseVisualStyleBackColor = false;
            this.assignLicenseButton.Click += new System.EventHandler(this.assignLicenseButton_Click);
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataMember = "User";
            this.userBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // snapShot_DBDataSet
            // 
            this.snapShot_DBDataSet.DataSetName = "SnapShot_DBDataSet";
            this.snapShot_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // hardwareBindingSource
            // 
            this.hardwareBindingSource.DataMember = "Hardware";
            this.hardwareBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // hardwareTableAdapter
            // 
            this.hardwareTableAdapter.ClearBeforeFill = true;
            // 
            // userTableAdapter
            // 
            this.userTableAdapter.ClearBeforeFill = true;
            // 
            // licenseTableAdapter1
            // 
            this.licenseTableAdapter1.ClearBeforeFill = true;
            // 
            // licenseBindingSource
            // 
            this.licenseBindingSource.DataMember = "License";
            this.licenseBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // licenseAssign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(884, 344);
            this.Controls.Add(this.assignButtonPanel);
            this.Controls.Add(this.licenseAssigntoFullDetailstabControl);
            this.Controls.Add(this.licenseAssigndataGridView);
            this.Controls.Add(this.licenseAssignmentCountPanel);
            this.Controls.Add(this.skinny_horizontal_bar);
            this.Name = "licenseAssign";
            this.Text = "licenseAssign";
            this.Load += new System.EventHandler(this.licenseAssign_Load);
            this.skinny_horizontal_bar.ResumeLayout(false);
            this.licenseAssignmentCountPanel.ResumeLayout(false);
            this.licenseAssignmentCountPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licenseAssigndataGridView)).EndInit();
            this.licenseAssigntoFullDetailstabControl.ResumeLayout(false);
            this.licenseToUserAssignPanel.ResumeLayout(false);
            this.licenseToUserAssignPanel.PerformLayout();
            this.userToHardwareAssignPage.ResumeLayout(false);
            this.userToHardwareAssignPage.PerformLayout();
            this.assignButtonPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel skinny_horizontal_bar;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button normal_max_button;
        private System.Windows.Forms.Button minimize_button;
        private System.Windows.Forms.Panel licenseAssignmentCountPanel;
        private System.Windows.Forms.Label unassignedlabel;
        private System.Windows.Forms.Label assignedlabel;
        private System.Windows.Forms.Label totalLicenseslabel;
        private System.Windows.Forms.Label assignedLicenseCountlabel;
        private System.Windows.Forms.Label totalLicenseCountLabel;
        private System.Windows.Forms.Label unassignLicenseCountLabel;
        private System.Windows.Forms.DataGridView licenseAssigndataGridView;
        private System.Windows.Forms.TabControl licenseAssigntoFullDetailstabControl;
        private System.Windows.Forms.TabPage licenseToUserAssignPanel;
        private System.Windows.Forms.TabPage userToHardwareAssignPage;
        private System.Windows.Forms.DateTimePicker userSuspendDatePicker;
        private System.Windows.Forms.TextBox userNotesTxtBox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DateTimePicker userTerminationDatePicker;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.DateTimePicker userCommenceDatePicker;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox userFirstNameTxtBox;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox userSurnameTxtBox;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel assignButtonPanel;
        private System.Windows.Forms.Button assignLicenseButton;
        private System.Windows.Forms.BindingSource hardwareBindingSource;
        private SnapShot_DBDataSet snapShot_DBDataSet;
        private SnapShot_DBDataSetTableAdapters.HardwareTableAdapter hardwareTableAdapter;
        private System.Windows.Forms.BindingSource userBindingSource;
        private SnapShot_DBDataSetTableAdapters.UserTableAdapter userTableAdapter;
        private SnapShot_DBDataSetTableAdapters.LicenseTableAdapter licenseTableAdapter1;
        private System.Windows.Forms.BindingSource licenseBindingSource;
        private System.Windows.Forms.DateTimePicker hwDateWrittenOffPicker;
        private System.Windows.Forms.DateTimePicker hwWarrantyExpPicker;
        private System.Windows.Forms.DateTimePicker hwDatePurchasedPicker;
        private System.Windows.Forms.TextBox hwNotesTxtBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox hwClientAssestTxtBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox hwSerialNumTxtBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox hwModelTxtBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox hwDeviceNameTxtBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox hwVendorTxtBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox hwCategoryCodeTxtBox;
        private System.Windows.Forms.Label label2;
    }
}