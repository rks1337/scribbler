﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SnapShot
{
    public partial class MainScreen : Form
    {
        private List<Button> assetButtonList;
        private const int HT_CAPTION = 0x2;
        private const int WM_NCHITTEST = 0x84;
        private const int WM_NCCALCSIZE = 0x83;
        private const int WM_NCLBUTTONDOWN = 0xA1;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public bool selected_client = false;
        public int client_key = 0;
        public int locationKey = 0;
        public string asset_selector = "";

        public MainScreen()
        {
            // init
            InitializeComponent();

            //to store the assest buttons into list
            assetButtonList = new List<Button>();
            assetButtonList.Add(select_hardware);
            assetButtonList.Add(select_licenses);
            assetButtonList.Add(selectSupportAgreements);
            assetButtonList.Add(selectCommunicationLinks);
            assetButtonList.Add(selectWarranty);
            assetButtonList.Add(selectEmail);
            assetButtonList.Add(select_user);

            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            // remove border for primary button tab controller
            tab_control_main.Appearance = TabAppearance.FlatButtons;
            tab_control_main.ItemSize = new Size(0, 1);
            tab_control_main.SizeMode = TabSizeMode.Fixed;

            // remove border for tab_function_control tab controller
            tab_function_control.Appearance = TabAppearance.FlatButtons;
            tab_function_control.ItemSize = new Size(0, 1);
            tab_function_control.SizeMode = TabSizeMode.Fixed;

            // display system time
            system_time_label.Text = DateTime.Now.ToString();

            // tab_control_main.SelectedIndex = 1;
            // selected_client = true;
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'snapShot_DBDataSet11.User' table. You can move, or remove it, as needed.
        }

        #region mouseDown event methods for moving the screen around

        private void MainScreen_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void fat_horizontal_bar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void side_bar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void skinny_horizontal_bar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void thin_bottom_bar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void tabControl_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void tabPage1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void tabPage2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        #endregion mouseDown event methods for moving the screen around

        #region function to catch window messages to modify the main screen window

        protected override void WndProc(ref Message m)
        {
            // drag adjust main screen size
            if (m.Msg == 0x84)
            {
                Point point = new Point(m.LParam.ToInt32());
                point = this.PointToClient(point);
                if (point.Y < 32)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (point.X >= this.ClientSize.Width - 16 && point.Y >= this.ClientSize.Height - 16)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        #endregion function to catch window messages to modify the main screen window

        #region minimize, maximize, exit click methods

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void normal_max_button_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
                normal_max_button.Text = "□";
            }
            else
            {
                WindowState = FormWindowState.Normal;
                normal_max_button.Text = "■";
            }
        }

        private void minimize_button_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        #endregion minimize, maximize, exit click methods

        #region main button click events

        private void button_home_Click(object sender, EventArgs e)
        {
            tab_control_main.SelectedIndex = 0;
        }

        private void button_client_Click(object sender, EventArgs e)
        {
            if (!selected_client)
            {
                tab_control_main.SelectedIndex = 2;
            }
            else
            {
                tab_control_main.SelectedIndex = 1;
            }
        }

        private void home_button_label_Click(object sender, EventArgs e)
        {
            tab_control_main.SelectedIndex = 0;
        }

        private void client_button_label_Click(object sender, EventArgs e)
        {
            var client_selection_pop_up = new client_select();
            client_selection_pop_up.ShowDialog(this);
        }

        #endregion main button click events

        #region home panel mouse over events

        private void home_panel_MouseEnter(object sender, EventArgs e)
        {
            home_panel.BackColor = Color.FromArgb(47, 54, 61);
            // home_button_label.BackColor = Color.FromArgb(47, 54, 61);
        }

        private void home_panel_MouseLeave(object sender, EventArgs e)
        {
            home_panel.BackColor = Color.FromArgb(36, 41, 46);
            // home_button_label.BackColor = Color.FromArgb(36, 41, 46);
        }

        private void button_home_MouseEnter(object sender, EventArgs e)
        {
            home_panel.BackColor = Color.FromArgb(47, 54, 61);
            // home_button_label.BackColor = Color.FromArgb(47, 54, 61);
        }

        private void button_home_MouseLeave(object sender, EventArgs e)
        {
            home_panel.BackColor = Color.FromArgb(36, 41, 46);
            // home_button_label.BackColor = Color.FromArgb(36, 41, 46);
        }

        private void home_button_label_MouseEnter(object sender, EventArgs e)
        {
            home_panel.BackColor = Color.FromArgb(47, 54, 61);
            // home_button_label.BackColor = Color.FromArgb(47, 54, 61);
        }

        private void home_button_label_MouseLeave(object sender, EventArgs e)
        {
            home_panel.BackColor = Color.FromArgb(36, 41, 46);
            // home_button_label.BackColor = Color.FromArgb(36, 41, 46);
        }

        #endregion home panel mouse over events

        #region client panel mouse over events

        private void client_panel_MouseEnter(object sender, EventArgs e)
        {
            client_panel.BackColor = Color.FromArgb(47, 54, 61);
            client_button_label.BackColor = Color.FromArgb(47, 54, 61);
        }

        private void client_panel_MouseLeave(object sender, EventArgs e)
        {
            client_panel.BackColor = Color.FromArgb(36, 41, 46);
            client_button_label.BackColor = Color.FromArgb(36, 41, 46);
        }

        private void button_client_MouseEnter(object sender, EventArgs e)
        {
            client_panel.BackColor = Color.FromArgb(47, 54, 61);
            client_button_label.BackColor = Color.FromArgb(47, 54, 61);
        }

        private void button_client_MouseLeave(object sender, EventArgs e)
        {
            client_panel.BackColor = Color.FromArgb(36, 41, 46);
            client_button_label.BackColor = Color.FromArgb(36, 41, 46);
        }

        private void client_button_label_MouseEnter(object sender, EventArgs e)
        {
            client_panel.BackColor = Color.FromArgb(47, 54, 61);
            client_button_label.BackColor = Color.FromArgb(47, 54, 61);
        }

        private void client_button_label_MouseLeave(object sender, EventArgs e)
        {
            client_panel.BackColor = Color.FromArgb(36, 41, 46);
            client_button_label.BackColor = Color.FromArgb(36, 41, 46);
        }

        #endregion client panel mouse over events

        #region top bar button mouse over event animations (colorization)

        private void exit_button_MouseEnter(object sender, EventArgs e)
        {
            exit_button.ForeColor = Color.White;
        }

        private void exit_button_MouseLeave(object sender, EventArgs e)
        {
            exit_button.ForeColor = Color.Gray;
        }

        private void normal_max_button_MouseEnter(object sender, EventArgs e)
        {
            normal_max_button.ForeColor = Color.White;
        }

        private void normal_max_button_MouseLeave(object sender, EventArgs e)
        {
            normal_max_button.ForeColor = Color.Gray;
        }

        private void minimize_button_MouseEnter(object sender, EventArgs e)
        {
            minimize_button.ForeColor = Color.White;
        }

        private void minimize_button_MouseLeave(object sender, EventArgs e)
        {
            minimize_button.ForeColor = Color.Gray;
        }

        private void refresh_button_MouseEnter(object sender, EventArgs e)
        {
            refresh_button.ForeColor = Color.White;
        }

        private void refresh_button_MouseLeave(object sender, EventArgs e)
        {
            refresh_button.ForeColor = Color.Gray;
        }

        #endregion top bar button mouse over event animations (colorization)

        #region asset selection button click events

        /**
         * when called this method cuases the datagridviewMain to change its data source and columns
         * to show the data for hardware
         */

        private void select_hardware_Click(object sender, EventArgs e)
        {
            asset_selector = "hardware";
            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = hardwareBindingSource;

            if (!(locationComboBox.Text == "All Locations"))
            {
                this.hardwareTableAdapter.FillByLocation(this.snapShot_DBDataSet.Hardware, client_key, locationComboBox.Text);
            }
            else
            {
                this.hardwareTableAdapter.Fill(this.snapShot_DBDataSet.Hardware, client_key);
            }

            // show
            dataGridViewMain.Columns[3].Visible = true;
            dataGridViewMain.Columns[3].HeaderText = "Device Name";
            dataGridViewMain.Columns[5].Visible = true;
            dataGridViewMain.Columns[5].HeaderText = "Serial Number";
            dataGridViewMain.Columns[10].Visible = true;
            dataGridViewMain.Columns[10].HeaderText = "Notes";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[1].Visible = false;
            dataGridViewMain.Columns[2].Visible = false;
            dataGridViewMain.Columns[4].Visible = false;
            dataGridViewMain.Columns[6].Visible = false;
            dataGridViewMain.Columns[7].Visible = false;
            dataGridViewMain.Columns[8].Visible = false;
            dataGridViewMain.Columns[9].Visible = false;
            dataGridViewMain.Columns[11].Visible = false;

            changeSelectedAsestButtonBackColour(select_hardware.Name);
        }

        /**
         * when called this method cuases the datagridviewMain to change its data source and columns
         * to show the data for licneses
         */

        private void select_licenses_Click(object sender, EventArgs e)
        {
            asset_selector = "license";
            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = licenseBindingSource;

            if (!(locationComboBox.Text == "All Locations"))
            {
                this.licenseTableAdapter.FillByLocation(this.snapShot_DBDataSet.License, client_key, locationComboBox.Text);
            }
            else
            {
                this.licenseTableAdapter.Fill(this.snapShot_DBDataSet.License, client_key);
            }

            // show
            dataGridViewMain.Columns[3].Visible = true;
            dataGridViewMain.Columns[6].Visible = true;
            dataGridViewMain.Columns[8].Visible = true;
            dataGridViewMain.Columns[14].Visible = true;
            dataGridViewMain.Columns[3].HeaderText = "Product Description";
            dataGridViewMain.Columns[6].HeaderText = "Quantity";
            dataGridViewMain.Columns[8].HeaderText = "Allocated";
            dataGridViewMain.Columns[14].HeaderText = "Notes";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[1].Visible = false;
            dataGridViewMain.Columns[2].Visible = false;
            dataGridViewMain.Columns[4].Visible = false;
            dataGridViewMain.Columns[5].Visible = false;
            dataGridViewMain.Columns[7].Visible = false;
            dataGridViewMain.Columns[9].Visible = false;
            dataGridViewMain.Columns[10].Visible = false;
            dataGridViewMain.Columns[11].Visible = false;
            dataGridViewMain.Columns[12].Visible = false;
            dataGridViewMain.Columns[13].Visible = false;
            dataGridViewMain.Columns[14].Visible = false;

            changeSelectedAsestButtonBackColour(select_licenses.Name);
        }

        /**
         * when called this method cuases the datagridviewMain to change its data source and columns
         * to show the data for users
         */

        private void select_user_Click(object sender, EventArgs e)
        {
            asset_selector = "user";
            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = userBindingSource;

            if (!(locationComboBox.Text == "All Locations"))
            {
                this.userTableAdapter.FillByLocation(this.snapShot_DBDataSet.User, client_key, locationComboBox.Text);
            }
            else
            {
                this.userTableAdapter.Fill(this.snapShot_DBDataSet.User, client_key);
            }

            // show
            dataGridViewMain.Columns[1].HeaderText = "Surname";
            dataGridViewMain.Columns[2].HeaderText = "Firstname";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[3].Visible = false;
            dataGridViewMain.Columns[4].Visible = false;
            dataGridViewMain.Columns[5].Visible = false;
            dataGridViewMain.Columns[6].Visible = false;

            changeSelectedAsestButtonBackColour(select_user.Name);
        }

        /**
        * when called this method cuases the datagridviewMain to change its data source and columns
        * to show the data for email addresses
         */

        private void selectEmail_Click(object sender, EventArgs e)
        {
            asset_selector = "email";
            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = emailAddressBindingSource;

            if (!(locationComboBox.Text.Equals("All Locations")))
            {
                this.email_AddressTableAdapter.FillByLocation(this.snapShot_DBDataSet.Email_Address, client_key, locationComboBox.Text);
            }
            else
            {
                this.email_AddressTableAdapter.Fill(this.snapShot_DBDataSet.Email_Address, client_key);
            }

            // show
            dataGridViewMain.Columns[1].HeaderText = "Email Address";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[2].Visible = false;
            dataGridViewMain.Columns[3].Visible = false;

            changeSelectedAsestButtonBackColour(selectEmail.Name);
        }

        /**
         * when called this method cuases the datagridviewMain to change its data source and columns
         * to show the data for support agreements
         */

        private void selectSupportAgreements_Click(object sender, EventArgs e)
        {
            asset_selector = "support_agreement";
            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = supportAgreementBindingSource;

            if (!(locationComboBox.Text.Equals("All Locations")))
            {
                this.support_AgreementTableAdapter.FillByLocation(this.snapShot_DBDataSet.Support_Agreement, client_key, locationComboBox.Text);
            }
            else
            {
                this.support_AgreementTableAdapter.Fill(this.snapShot_DBDataSet.Support_Agreement, client_key);
            }

            // show
            dataGridViewMain.Columns[1].HeaderText = "Description";
            dataGridViewMain.Columns[2].HeaderText = "Status";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[3].Visible = false;
            dataGridViewMain.Columns[4].Visible = false;
            dataGridViewMain.Columns[5].Visible = false;

            changeSelectedAsestButtonBackColour(selectSupportAgreements.Name);
        }

        private void selectWarranty_Click(object sender, EventArgs e)
        {
            asset_selector = "warranty";
            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = warrantyBindingSource;

            if (!(locationComboBox.Text == "All Locations"))
            {
                this.warrantyTableAdapter.FillByLocation(this.snapShot_DBDataSet.Warranty, client_key, locationComboBox.Text);
            }
            else
            {
                this.warrantyTableAdapter.Fill(this.snapShot_DBDataSet.Warranty, client_key);
            }

            // show
            dataGridViewMain.Columns[1].HeaderText = "Warranty Type";
            dataGridViewMain.Columns[5].HeaderText = "Quote Ref";
            dataGridViewMain.Columns[6].HeaderText = "Ticket Number";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[2].Visible = false;
            dataGridViewMain.Columns[3].Visible = false;
            dataGridViewMain.Columns[4].Visible = false;
            dataGridViewMain.Columns[7].Visible = false;

            changeSelectedAsestButtonBackColour(selectWarranty.Name);
        }

        private void selectCommunicationLinks_Click(object sender, EventArgs e)
        {
            asset_selector = "communication_link";
            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = communicationLinkBindingSource;

            if (!(locationComboBox.Text.Equals("All Locations")))
            {
                this.communication_LinkTableAdapter.FillByLocation(this.snapShot_DBDataSet.Communication_Link, client_key, locationComboBox.Text);
            }
            else
            {
                this.communication_LinkTableAdapter.Fill(this.snapShot_DBDataSet.Communication_Link, client_key);
            }

            // show
            dataGridViewMain.Columns[1].HeaderText = "Vendor";
            dataGridViewMain.Columns[2].HeaderText = "Link Type";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[3].Visible = false;
            dataGridViewMain.Columns[4].Visible = false;
            dataGridViewMain.Columns[5].Visible = false;
            dataGridViewMain.Columns[6].Visible = false;
            dataGridViewMain.Columns[7].Visible = false;
            dataGridViewMain.Columns[8].Visible = false;

            changeSelectedAsestButtonBackColour(selectCommunicationLinks.Name);
        }

        #endregion asset selection button click events

        #region change the back colour of the selected asset button

        public void changeSelectedAsestButtonBackColour(String buttonName)
        {
            foreach (Button b in assetButtonList)
            {
                if (b.Name.Equals(buttonName))
                {
                    b.BackColor = Color.FromArgb(160, 254, 163);
                }
                else
                {
                    b.BackColor = Color.White;
                }
            }
        }

        #endregion change the back colour of the selected asset button

        #region misc events

        private void refresh_button_Click(object sender, EventArgs e)
        {
            this.Refresh();
            //testing license assin code

            //end license test assign code
        }

        private void client_tab_select_button_Click(object sender, EventArgs e)
        {
            var client_selection_pop_up = new client_select();
            client_selection_pop_up.ShowDialog(this);
        }

        public void set_client_label(string text)
        {
            client_button_label.Text = text;
        }

        public void set_client_tab_view(int key)
        {
      
            changeSelectedAsestButtonBackColour("Hardware");
            select_hardware.BackColor = Color.FromArgb(160, 254, 163);

            // disable location combobox data source temporarliy as client data changes
            locationComboBox.DataSource = null;

            // store client record primary key locally
            this.client_key = key;

            // swap data source
            this.dataGridViewMain.AutoGenerateColumns = true;
            this.dataGridViewMain.DataSource = hardwareBindingSource;
            this.hardwareTableAdapter.Fill(this.snapShot_DBDataSet.Hardware, client_key);

            // display detailed hardware data on the right
            hwCategoryCodeTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();
            hwVendorTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString();
            hwDeviceNameTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
            hwModelTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[4].Value.ToString();
            hwSerialNumTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[5].Value.ToString();
            hwClientAssestTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[6].Value.ToString();
            hwDatePurchasedPicker.Text = dataGridViewMain.SelectedRows[0].Cells[7].Value.ToString();
            hwWarrantyExpPicker.Text = dataGridViewMain.SelectedRows[0].Cells[8].Value.ToString();
            hwDateWrittenOffPicker.Text = dataGridViewMain.SelectedRows[0].Cells[9].Value.ToString();
            hwNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[10].Value.ToString();

            // show
            dataGridViewMain.Columns[3].Visible = true;
            dataGridViewMain.Columns[3].HeaderText = "Device Name";
            dataGridViewMain.Columns[5].Visible = true;
            dataGridViewMain.Columns[5].HeaderText = "Serial Number";
            dataGridViewMain.Columns[10].Visible = true;
            dataGridViewMain.Columns[10].HeaderText = "Notes";

            //hide
            dataGridViewMain.Columns[0].Visible = false;
            dataGridViewMain.Columns[1].Visible = false;
            dataGridViewMain.Columns[2].Visible = false;
            dataGridViewMain.Columns[4].Visible = false;
            dataGridViewMain.Columns[6].Visible = false;
            dataGridViewMain.Columns[7].Visible = false;
            dataGridViewMain.Columns[8].Visible = false;
            dataGridViewMain.Columns[9].Visible = false;
            dataGridViewMain.Columns[11].Visible = false;

            tab_control_main.SelectedIndex = 1;
            tab_function_control.SelectedIndex = 0;
            selected_client = true;

            // add temp item to location combobox to tell the user all locations are selected
            if (!locationComboBox.Items.Contains("All Locations"))
            {
                locationComboBox.Items.Add("All Locations");
            }
            locationComboBox.Text = "All Locations";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            system_time_label.Text = DateTime.Now.ToString();
            system_timer.Start();
        }

        private void function_select_Click(object sender, EventArgs e)
        {
            tab_function_control.SelectedIndex = 0;
        }

        #endregion misc events

        #region dataGridView cell click event

        /**
         * When one of the row is selected, it will display all the data for
         * the selected row
         */

        private void dataGridViewMain_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!(e.RowIndex < 0))
            {
                if (dataGridViewMain.DataSource == hardwareBindingSource)
                {
                    tab_function_control.SelectedIndex = 0;

                    hwCategoryCodeTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();
                    hwVendorTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString();
                    hwDeviceNameTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
                    hwModelTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[4].Value.ToString();
                    hwSerialNumTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[5].Value.ToString();
                    hwClientAssestTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[6].Value.ToString();
                    hwDatePurchasedPicker.Text = dataGridViewMain.SelectedRows[0].Cells[7].Value.ToString();
                    hwWarrantyExpPicker.Text = dataGridViewMain.SelectedRows[0].Cells[8].Value.ToString();
                    hwDateWrittenOffPicker.Text = dataGridViewMain.SelectedRows[0].Cells[9].Value.ToString();
                    hwNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[10].Value.ToString();
                }
                else if (dataGridViewMain.DataSource == licenseBindingSource)
                {
                    tab_function_control.SelectedIndex = 1;

                    licenseCodeOffsetTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();
                    licenseCategoryTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString();
                    licenseProductDescTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
                    licenseSubscriptionTyTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[4].Value.ToString();
                    licensePackOrCoresNumeric.Text = dataGridViewMain.SelectedRows[0].Cells[5].Value.ToString();
                    licenseQuantityNumeric.Text = dataGridViewMain.SelectedRows[0].Cells[6].Value.ToString();
                    licensePurchasedNumeric.Text = dataGridViewMain.SelectedRows[0].Cells[7].Value.ToString();
                    licensesAllocatedNumeric.Text = dataGridViewMain.SelectedRows[0].Cells[8].Value.ToString();
                    licenseVendorAllocatedKeyTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[9].Value.ToString();
                    licenseDatePurchasedPicker.Text = dataGridViewMain.SelectedRows[0].Cells[10].Value.ToString();
                    licenseExpDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[11].Value.ToString();
                    licenseQuoteRefTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[12].Value.ToString();
                    licenseTicketNumberNumeric.Text = dataGridViewMain.SelectedRows[0].Cells[13].Value.ToString();
                    licenseNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[14].Value.ToString();
                }
                else if (dataGridViewMain.DataSource == userBindingSource)
                {
                    tab_function_control.SelectedIndex = 2;

                    userSurnameTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();
                    userFirstNameTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString();
                    userCommenceDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
                    userTerminationDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[4].Value.ToString();
                    userSuspendDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[5].Value.ToString();
                    userNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[6].Value.ToString();
                }
                else if (dataGridViewMain.DataSource == locationBindingSource)
                {
                    tab_function_control.SelectedIndex = 3;

                    locationDescTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();
                    locationEnvironmentTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString();
                    locationNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
                }
                else if (dataGridViewMain.DataSource == emailAddressBindingSource)
                {
                    tab_function_control.SelectedIndex = 4;

                    emailAddressTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();
                    emailAddressMailboxTyTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString();
                    emailAddressNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
                }
                else if (dataGridViewMain.DataSource == supportAgreementBindingSource)
                {
                    tab_function_control.SelectedIndex = 5;

                    supportAgreementDescTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();

                    switch (dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString())
                    {
                        case "True":
                            supportAgreeActiveRadioBtn.Checked = true;
                            break;

                        case "False":
                            supportAgreeInactiveRadioBtn.Checked = true;
                            break;
                    }

                    supportAgreeCommenDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
                    supportAgreeExpDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[4].Value.ToString();
                    supportAgreeNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[5].Value.ToString();
                }
                else if (dataGridViewMain.DataSource == warrantyBindingSource)
                {
                    tab_function_control.SelectedIndex = 6;

                    warrantyTypeTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();

                    switch (dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString())
                    {
                        case "True":
                            warrantyActiveRadioBtn.Checked = true;
                            break;

                        case "False":
                            warrantyInactiveRadioBtn.Checked = true;
                            break;
                    }

                    warrantyStartDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();
                    warrantyExpDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[4].Value.ToString();
                    warrantyQuoteRefTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[5].Value.ToString();
                    warrantyTicketNumberTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[6].Value.ToString();
                    warrantyNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[7].Value.ToString();
                }
                else if (dataGridViewMain.DataSource == communicationLinkBindingSource)
                {
                    tab_function_control.SelectedIndex = 7;

                    communicationLinkVendorTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[1].Value.ToString();
                    communiLinkTypeTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[2].Value.ToString();
                    communiLinkSpeedTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[3].Value.ToString();

                    switch (dataGridViewMain.SelectedRows[0].Cells[4].Value.ToString())
                    {
                        case "True":
                            communiLinkConnectAgreementComboBox.SelectedIndex = 0;
                            break;

                        case "False":
                            communiLinkConnectAgreementComboBox.SelectedIndex = 1;
                            break;
                    }

                    communiLinkCommenceDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[5].Value.ToString();
                    communiLinkTermMonthNumeric.Text = dataGridViewMain.SelectedRows[0].Cells[6].Value.ToString();
                    communicationLinkExpDatePicker.Text = dataGridViewMain.SelectedRows[0].Cells[7].Value.ToString();
                    communicationLinkNotesTxtBox.Text = dataGridViewMain.SelectedRows[0].Cells[8].Value.ToString();
                }
            }
        }

        #endregion dataGridView cell click event

        #region clear asset fields

        /**
         * deselects selected asset and resets the assets view field to defualt values when called,
         * so that a new asset entry can be created by subsequencly clicking save.
         */

        private void createDataButton_Click(object sender, EventArgs e)
        {
            if (locationComboBox.Text == "All Locations")
            {
                MessageBox.Show("Please select a location first!");
                return;
            }

            this.dataGridViewMain.ClearSelection();
            if (dataGridViewMain.DataSource == hardwareBindingSource)
            {
                tab_function_control.SelectedIndex = 0;
                hwCategoryCodeTxtBox.ResetText();
                hwVendorTxtBox.ResetText();
                hwDeviceNameTxtBox.ResetText();
                hwModelTxtBox.ResetText();
                hwSerialNumTxtBox.ResetText();
                hwClientAssestTxtBox.ResetText();
                hwDatePurchasedPicker.ResetText();
                hwWarrantyExpPicker.ResetText();
                hwDateWrittenOffPicker.ResetText();
                hwNotesTxtBox.ResetText();
            }
            else if (dataGridViewMain.DataSource == licenseBindingSource)
            {
                tab_function_control.SelectedIndex = 1;
                licenseCodeOffsetTxtBox.ResetText();
                licenseCategoryTxtBox.ResetText();
                licenseProductDescTxtBox.ResetText();
                licenseSubscriptionTyTxtBox.ResetText();
                licensePackOrCoresNumeric.ResetText();
                licenseQuantityNumeric.ResetText();
                licensePurchasedNumeric.ResetText();
                licensesAllocatedNumeric.ResetText();
                licenseVendorAllocatedKeyTxtBox.ResetText();
                licenseDatePurchasedPicker.ResetText();
                licenseExpDatePicker.ResetText();
                licenseQuoteRefTxtBox.ResetText();
                licenseTicketNumberNumeric.ResetText();
                licenseNotesTxtBox.ResetText();
            }
            else if (dataGridViewMain.DataSource == userBindingSource)
            {
                tab_function_control.SelectedIndex = 2;
                userSurnameTxtBox.ResetText();
                userFirstNameTxtBox.ResetText();
                userCommenceDatePicker.ResetText();
                userTerminationDatePicker.ResetText();
                userSuspendDatePicker.ResetText();
                userNotesTxtBox.ResetText();
            }
            else if (dataGridViewMain.DataSource == locationBindingSource)
            {
                tab_function_control.SelectedIndex = 3;
                locationDescTxtBox.ResetText();
                locationEnvironmentTxtBox.ResetText();
                locationNotesTxtBox.ResetText();
            }
            else if (dataGridViewMain.DataSource == emailAddressBindingSource)
            {
                tab_function_control.SelectedIndex = 4;
                emailAddressTxtBox.ResetText();
                emailAddressMailboxTyTxtBox.ResetText();
                emailAddressNotesTxtBox.ResetText();
            }
            else if (dataGridViewMain.DataSource == supportAgreementBindingSource)
            {
                tab_function_control.SelectedIndex = 5;
                supportAgreementDescTxtBox.ResetText();
                supportAgreeActiveRadioBtn.Checked = true;
                supportAgreeInactiveRadioBtn.Checked = false;
                supportAgreeCommenDatePicker.ResetText();
                supportAgreeExpDatePicker.ResetText();
                supportAgreeNotesTxtBox.ResetText();
            }
            else if (dataGridViewMain.DataSource == warrantyBindingSource)
            {
                tab_function_control.SelectedIndex = 6;
                warrantyTypeTxtBox.ResetText();
                warrantyActiveRadioBtn.Checked = true;
                warrantyInactiveRadioBtn.Checked = false;
                warrantyStartDatePicker.ResetText();
                warrantyExpDatePicker.ResetText();
                warrantyQuoteRefTxtBox.ResetText();
                warrantyTicketNumberTxtBox.ResetText();
                warrantyNotesTxtBox.ResetText();
            }
            else if (dataGridViewMain.DataSource == communicationLinkBindingSource)
            {
                tab_function_control.SelectedIndex = 7;
                communicationLinkVendorTxtBox.ResetText();
                communiLinkTypeTxtBox.ResetText();
                communiLinkSpeedTxtBox.ResetText();
                communiLinkConnectAgreementComboBox.SelectedIndex = 0;
                communiLinkCommenceDatePicker.ResetText();
                communiLinkTermMonthNumeric.ResetText();
                communicationLinkExpDatePicker.ResetText();
                communicationLinkNotesTxtBox.ResetText();
            }
        }

        #endregion clear asset fields
        /**
        * creates a new database table entry from data given in the details view,
        * depending on what data source is being viewed, when called
        */
        private void saveNewDataEntry(object sender, EventArgs e)
        {
            int newAssetKey = 0;
            if (dataGridViewMain.DataSource == hardwareBindingSource)
            {                
                try
                {
                    if(!int.TryParse(this.hardwareTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }
                    this.hardwareTableAdapter.Insert1( 
                        newAssetKey,
                        locationKey,
                        hwCategoryCodeTxtBox.Text.ToString(),
                    hwVendorTxtBox.Text.ToString(),
                    hwDeviceNameTxtBox.Text.ToString(),
                    hwModelTxtBox.Text.ToString(),
                    hwSerialNumTxtBox.Text.ToString(),
                    hwClientAssestTxtBox.Text.ToString(),
                    hwDatePurchasedPicker.Value.ToString(),
                    hwWarrantyExpPicker.Value.ToString(),
                    hwDateWrittenOffPicker.Value.ToString(),
                    hwNotesTxtBox.Text.ToString());
                    this.Validate();
                    this.hardwareBindingSource.EndEdit();
                    this.hardwareTableAdapter.FillByLocation(this.snapShot_DBDataSet.Hardware, client_key, locationComboBox.Text);
                        MessageBox.Show("Hardware Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hardware Creation Failed" + "\n" + ex.Message);
                }
            }
            else if (dataGridViewMain.DataSource == licenseBindingSource)
            {
                try
                {
                    if (!int.TryParse(this.licenseTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }
                    licenseTableAdapter.Insert1(
                        newAssetKey,
                        locationKey,
                        licenseCodeOffsetTxtBox.Text.ToString(),
                        licenseCategoryTxtBox.Text.ToString(),
                        licenseProductDescTxtBox.Text.ToString(),
                        licenseSubscriptionTyTxtBox.Text.ToString(),
                        (int)licensePackOrCoresNumeric.Value,
                        (int)licenseQuantityNumeric.Value,
                        (int)licensePurchasedNumeric.Value,
                        (int)licensesAllocatedNumeric.Value,
                        licenseVendorAllocatedKeyTxtBox.Text.ToString(),
                        licenseDatePurchasedPicker.Value.ToString(),
                        licenseExpDatePicker.Value.ToString(),
                        licenseQuoteRefTxtBox.Text.ToString(),
                        (int)licenseTicketNumberNumeric.Value,
                        licenseNotesTxtBox.Text.ToString());
                    this.Validate();
                    this.licenseBindingSource.EndEdit();
                    this.licenseTableAdapter.FillByLocation(this.snapShot_DBDataSet.License, client_key, locationComboBox.Text);
                    MessageBox.Show("License Support Agreement Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("License Creation Failed" + "\n" + ex.Message);
                }
            }
            else if (dataGridViewMain.DataSource == userBindingSource)
            {                
                try
                {
                    
                    if (!int.TryParse(this.userTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }
                    this.userTableAdapter.Insert1(
                        newAssetKey,
                        locationKey,
                        userSurnameTxtBox.Text.ToString(),
                        userFirstNameTxtBox.Text.ToString(),
                        userCommenceDatePicker.Value.ToString(),
                        userTerminationDatePicker.Value.ToString(),
                        userSuspendDatePicker.Value.ToString(),
                        userNotesTxtBox.Text.ToString());
                    this.Validate();
                   this.userBindingSource.EndEdit();
                    this.userTableAdapter.FillByLocation(this.snapShot_DBDataSet.User, client_key, locationComboBox.Text);
                    MessageBox.Show("User Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("User Creation Failed" + "\n" + ex.Message);
                }
            }
            else if (dataGridViewMain.DataSource == locationBindingSource)
            {
                try
                {
                    if (!int.TryParse(this.locationTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }
                    this.locationTableAdapter.Insert1(
                        newAssetKey,
                        locationKey,
                        locationDescTxtBox.Text.ToString(),
                        locationEnvironmentTxtBox.Text.ToString(),
                        locationNotesTxtBox.Text.ToString());
                    this.Validate();
                    this.locationBindingSource.EndEdit();
                    this.locationTableAdapter.Fill(this.snapShot_DBDataSet.Location, client_key);
                    MessageBox.Show("Location Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Location Creation Failed" + "\n" + ex.Message);
                }
            }
            else if (dataGridViewMain.DataSource == emailAddressBindingSource)
            {
                try
                {

                    if (!int.TryParse(this.email_AddressTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }
                    this.email_AddressTableAdapter.Insert1(
                        newAssetKey,
                        locationKey,                        
                        emailAddressTxtBox.Text.ToString(),
                        emailAddressMailboxTyTxtBox.Text.ToString(),
                        emailAddressNotesTxtBox.Text.ToString());
                    this.Validate();
                    this.emailAddressBindingSource.EndEdit();
                    this.email_AddressTableAdapter.FillByLocation(this.snapShot_DBDataSet.Email_Address, client_key, locationComboBox.Text);
                    MessageBox.Show("Email Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Email Address Creation Failed" + "\n" + ex.Message);
                }
            }
            else if (dataGridViewMain.DataSource == supportAgreementBindingSource)
            {
                try
                {
                    if (!int.TryParse(this.support_AgreementTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }
                    this.support_AgreementTableAdapter.Insert1(
                        newAssetKey,
                        locationKey,
                        supportAgreementDescTxtBox.Text.ToString(),
                        supportAgreeActiveRadioBtn.Checked,
                        supportAgreeCommenDatePicker.Value.ToString(),
                        supportAgreeExpDatePicker.Value.ToString(),
                        supportAgreeNotesTxtBox.Text.ToString());
                    this.Validate();
                    this.supportAgreementBindingSource.EndEdit();
                    this.support_AgreementTableAdapter.FillByLocation(this.snapShot_DBDataSet.Support_Agreement, client_key, locationComboBox.Text);
                    MessageBox.Show("Support Agreement Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Support Agreement Creation Failed" + "\n" + ex.Message);
                }
            }
            else if (dataGridViewMain.DataSource == warrantyBindingSource)
            {
                try
                {
                    if (!int.TryParse(this.warrantyTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }
                    this.warrantyTableAdapter.Insert1(
                        newAssetKey,
                        locationKey,
                        warrantyTypeTxtBox.Text.ToString(),
                        warrantyActiveRadioBtn.Checked,
                        warrantyStartDatePicker.Value.ToString(),
                        warrantyExpDatePicker.Value.ToString(),
                        warrantyQuoteRefTxtBox.Text.ToString(),
                        warrantyTicketNumberTxtBox.Text.ToString(),
                        warrantyNotesTxtBox.Text.ToString());
                    this.Validate();
                    this.warrantyBindingSource.EndEdit();
                    this.warrantyTableAdapter.FillByLocation(this.snapShot_DBDataSet.Warranty, client_key, locationComboBox.Text);
                    MessageBox.Show("Warranty Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Warranty Creation Failed" + "\n" + ex.Message);
                }
            }
            else if (dataGridViewMain.DataSource == communicationLinkBindingSource)
            {
                try
                {
                    
                    bool agree = false;

                    if (!int.TryParse(this.communication_LinkTableAdapter.GetNextKey().ToString(), out newAssetKey))
                    {
                        newAssetKey = 0;
                    }

                    if (communiLinkConnectAgreementComboBox.SelectedIndex == 0)
                    {
                        agree = true;
                    }
                    else
                    {
                        agree = false;
                    }

                    this.communication_LinkTableAdapter.Insert1(
                        newAssetKey,
                        locationKey,                        
                        communicationLinkVendorTxtBox.Text.ToString(),
                        communiLinkTypeTxtBox.Text.ToString(),
                        communiLinkSpeedTxtBox.Text.ToString(),
                        agree,
                        communiLinkCommenceDatePicker.Value.ToString(),
                        (int)communiLinkTermMonthNumeric.Value,
                        communicationLinkExpDatePicker.Value.ToString(),
                        communicationLinkNotesTxtBox.Text.ToString());
                    this.Validate();
                    this.communicationLinkBindingSource.EndEdit();
                    this.communication_LinkTableAdapter.FillByLocation(this.snapShot_DBDataSet.Communication_Link, client_key, locationComboBox.Text);
                    MessageBox.Show("Communication Link Creation Succeeded");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("communication link creation failed" + "\n" + ex.Message);
                }
            }
        }

        #region save modification button

        private void modifyButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewMain.SelectedRows.Count > 0)
                {
                    int index = dataGridViewMain.CurrentRow.Index;
                    int key = (int)dataGridViewMain.SelectedRows[0].Cells[0].Value;

                    if (dataGridViewMain.DataSource == hardwareBindingSource)
                    {
                        this.hardwareTableAdapter.UpdateQuery(
                            hwCategoryCodeTxtBox.Text.ToString(),
                            hwVendorTxtBox.Text.ToString(),
                            hwDeviceNameTxtBox.Text.ToString(),
                            hwModelTxtBox.Text.ToString(),
                            hwSerialNumTxtBox.Text.ToString(),
                            hwClientAssestTxtBox.Text.ToString(),
                            hwDatePurchasedPicker.Value.ToString(),
                            hwWarrantyExpPicker.Value.ToString(),
                            hwDateWrittenOffPicker.Value.ToString(),
                            hwNotesTxtBox.Text.ToString(),
                            key);
                        this.Validate();

                        if (!(locationComboBox.Text == "All Locations"))
                        {
                            this.hardwareTableAdapter.FillByLocation(this.snapShot_DBDataSet.Hardware, client_key, locationComboBox.Text);
                        }
                        else
                        {
                            this.hardwareTableAdapter.Fill(this.snapShot_DBDataSet.Hardware, client_key);
                        }
                    }
                    else if (dataGridViewMain.DataSource == licenseBindingSource)
                    {
                        this.licenseTableAdapter.UpdateQuery(licenseCodeOffsetTxtBox.Text.ToString(), licenseCategoryTxtBox.Text.ToString(),
                            licenseProductDescTxtBox.Text.ToString(), licenseSubscriptionTyTxtBox.Text.ToString(), (int)licensePackOrCoresNumeric.Value,
                            (int)licenseQuantityNumeric.Value, (int)licensePurchasedNumeric.Value, (int)licensesAllocatedNumeric.Value, licenseVendorAllocatedKeyTxtBox.Text.ToString(),
                            licenseDatePurchasedPicker.Value.ToString(), licenseExpDatePicker.Value.ToString(), licenseQuoteRefTxtBox.Text.ToString(),
                            (int)licenseTicketNumberNumeric.Value, licenseNotesTxtBox.Text.ToString(), key);
                        this.Validate();

                        if (!(locationComboBox.Text == "All Locations"))
                        {
                            this.licenseTableAdapter.FillByLocation(this.snapShot_DBDataSet.License, client_key, locationComboBox.Text);
                        }
                        else
                        {
                            this.licenseTableAdapter.Fill(this.snapShot_DBDataSet.License, client_key);
                        }
                    }
                    else if (dataGridViewMain.DataSource == userBindingSource)
                    {
                        this.userTableAdapter.UpdateQuery(
                            userSurnameTxtBox.Text.ToString(),
                            userFirstNameTxtBox.Text.ToString(),
                            userCommenceDatePicker.Value.ToString(),
                            userTerminationDatePicker.Value.ToString(),
                            userSuspendDatePicker.Value.ToString(),
                            userNotesTxtBox.Text.ToString(), key);
                        this.Validate();

                        if (!(locationComboBox.Text == "All Locations"))
                        {
                            this.userTableAdapter.FillByLocation(this.snapShot_DBDataSet.User, client_key, locationComboBox.Text);
                        }
                        else
                        {
                            this.userTableAdapter.Fill(this.snapShot_DBDataSet.User, client_key);
                        }
                    }
                    else if (dataGridViewMain.DataSource == emailAddressBindingSource)
                    {
                        this.email_AddressTableAdapter.UpdateQuery(emailAddressTxtBox.Text.ToString(), emailAddressMailboxTyTxtBox.Text.ToString(),
                            emailAddressNotesTxtBox.Text.ToString(), key);
                        this.Validate();

                        if (!(locationComboBox.Text == "All Locations"))
                        {
                            this.email_AddressTableAdapter.FillByLocation(this.snapShot_DBDataSet.Email_Address, client_key, locationComboBox.Text);
                        }
                        else
                        {
                            this.email_AddressTableAdapter.Fill(this.snapShot_DBDataSet.Email_Address, client_key);
                        }
                    }
                    else if (dataGridViewMain.DataSource == supportAgreementBindingSource)
                    {
                        bool status = false;

                        if (supportAgreeActiveRadioBtn.Checked)
                        {
                            status = true;
                        }
                        this.support_AgreementTableAdapter.UpdateQuery(supportAgreementDescTxtBox.Text.ToString(), status,
                            supportAgreeCommenDatePicker.Value.ToString(), supportAgreeExpDatePicker.Value.ToString(), supportAgreeNotesTxtBox.Text.ToString(),
                            key);
                        this.Validate();

                        if (!(locationComboBox.Text == "All Locations"))
                        {
                            this.support_AgreementTableAdapter.FillByLocation(this.snapShot_DBDataSet.Support_Agreement, client_key, locationComboBox.Text);
                        }
                        else
                        {
                            this.support_AgreementTableAdapter.Fill(this.snapShot_DBDataSet.Support_Agreement, client_key);
                        }
                    }
                    else if (dataGridViewMain.DataSource == warrantyBindingSource)
                    {
                        bool status = false;

                        if (warrantyActiveRadioBtn.Checked)
                        {
                            status = true;
                        }
                        this.warrantyTableAdapter.UpdateQuery(warrantyTypeTxtBox.Text.ToString(), status, warrantyStartDatePicker.Value.ToString(),
                            warrantyExpDatePicker.Value.ToString(), warrantyQuoteRefTxtBox.Text.ToString(), warrantyTicketNumberTxtBox.Text.ToString(),
                            warrantyNotesTxtBox.Text.ToString(), key);
                        this.Validate();

                        if (!(locationComboBox.Text == "All Locations"))
                        {
                            this.warrantyTableAdapter.FillByLocation(this.snapShot_DBDataSet.Warranty, client_key, locationComboBox.Text);
                        }
                        else
                        {
                            this.warrantyTableAdapter.Fill(this.snapShot_DBDataSet.Warranty, client_key);
                        }
                    }
                    else if (dataGridViewMain.DataSource == communicationLinkBindingSource)
                    {
                        bool connectivityAgreement = false;

                        if (communiLinkConnectAgreementComboBox.SelectedIndex == 0)
                        {
                            connectivityAgreement = true;
                        }

                        this.communication_LinkTableAdapter.UpdateQuery(communicationLinkVendorTxtBox.Text.ToString(), communiLinkTypeTxtBox.Text.ToString(),
                            communiLinkSpeedTxtBox.Text.ToString(), connectivityAgreement, communiLinkCommenceDatePicker.Value.ToString(),
                            (int)communiLinkTermMonthNumeric.Value, communicationLinkExpDatePicker.Value.ToString(), communicationLinkNotesTxtBox.Text.ToString(), key);
                        this.Validate();

                        if (!(locationComboBox.Text == "All Locations"))
                        {
                            this.communication_LinkTableAdapter.FillByLocation(this.snapShot_DBDataSet.Communication_Link, client_key, locationComboBox.Text);
                        }
                        else
                        {
                            this.communication_LinkTableAdapter.Fill(this.snapShot_DBDataSet.Communication_Link, client_key);
                        }
                    }
                    dataGridViewMain.ClearSelection();
                    dataGridViewMain.Rows[index].Selected = true;
                    MessageBox.Show("Success update the selected record");
                }
                else
                {
                    this.saveNewDataEntry(sender, e);
                }
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("Please select a record! \n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to update the selected record\n" + ex.Message);
            }
        }

        #endregion save modification button

        private void locationComboBox_DropDown(object sender, EventArgs e)
        {
            locationComboBox.DataSource = locationBindingSource;
            locationComboBox.DisplayMember = "location_description";
            this.locationTableAdapter.Fill(this.snapShot_DBDataSet.Location, client_key);
        }

        private void locationComboBox_DropDownClosed(object sender, EventArgs e)
        {
            if (int.TryParse(locationTableAdapter.GetLocationKeyByDescription(locationComboBox.Text.ToString(), client_key).ToString(), out locationKey))
            {

            }

            // select appropriate client asset from desired location
            if (asset_selector == "")
            {
                this.hardwareTableAdapter.FillByLocation(this.snapShot_DBDataSet.Hardware, client_key, locationComboBox.Text);
            }
            if (asset_selector == "hardware")
            {
                this.hardwareTableAdapter.FillByLocation(this.snapShot_DBDataSet.Hardware, client_key, locationComboBox.Text);
            }
            if (asset_selector == "license")
            {
                this.licenseTableAdapter.FillByLocation(this.snapShot_DBDataSet.License, client_key, locationComboBox.Text);
            }
            if (asset_selector == "user")
            {
                this.userTableAdapter.FillByLocation(this.snapShot_DBDataSet.User, client_key, locationComboBox.Text);
            }
            if (asset_selector == "email")
            {
                this.email_AddressTableAdapter.FillByLocation(this.snapShot_DBDataSet.Email_Address, client_key, locationComboBox.Text);
            }
            if (asset_selector == "support_agreement")
            {
                this.support_AgreementTableAdapter.FillByLocation(this.snapShot_DBDataSet.Support_Agreement, client_key, locationComboBox.Text);
            }
            if (asset_selector == "warranty")
            {
                this.warrantyTableAdapter.FillByLocation(this.snapShot_DBDataSet.Warranty, client_key, locationComboBox.Text);
            }
            if (asset_selector == "communication_link")
            {
                this.communication_LinkTableAdapter.FillByLocation(this.snapShot_DBDataSet.Communication_Link, client_key, locationComboBox.Text);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //run assign button as assign license if licenses are being view and a licesne is selected
            if ((dataGridViewMain.DataSource == licenseBindingSource) && (dataGridViewMain.SelectedRows.Count == 1))
            {
                //ask what to assign the license to or tell system user license can't be assigned to none existent assets
                this.assignLicenseToMessages(client_key, locationKey, (int)dataGridViewMain.SelectedRows[0].Cells[0].Value);
            }
        }

        /**
         * when called askes a series of questions to determine what the user wishes to assign license to or
         * if no assignabloe assets exists, tells the user assignment can't be done
         */
        private void assignLicenseToMessages(int clientKey, int locationKey, int licenseKey)
        {
            DialogResult assignLicenseToHardware = DialogResult.No;
            DialogResult assignLicenseToUser = DialogResult.No;
            bool assignable = false;
            if (hardwareTableAdapter.CountNumberOfHardwareAtLocation(locationKey) > 0)
            {
                assignable = true;
                assignLicenseToHardware = MessageBox.Show("Assign License to Hardware?", "",
                                    MessageBoxButtons.YesNoCancel);
                if (assignLicenseToHardware == DialogResult.Yes)
                {
                    licenseAssign assignLicense = new licenseAssign(clientKey, locationKey, licenseKey, "Hardware");
                    assignLicense.Show();
                }
            }
            if (userTableAdapter.CountUsersAtLocation(locationKey) > 0)
            {
                assignable = true;
                assignLicenseToUser = MessageBox.Show("Assign License to User?",
                                    "", MessageBoxButtons.YesNoCancel);
                if ((assignLicenseToHardware == DialogResult.No) && (assignLicenseToUser == DialogResult.Yes))
                {
                    licenseAssign assignLicense = new licenseAssign(clientKey, locationKey, licenseKey, "User");
                    assignLicense.Show();
                }
            }
            if (!assignable)
            {
                MessageBox.Show("License has no assignable assets that exist at this moment in time");
            }
        }

        private void locationComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }
    }
}