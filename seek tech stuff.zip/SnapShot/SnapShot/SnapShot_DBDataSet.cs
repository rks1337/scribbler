﻿namespace SnapShot
{


    partial class SnapShot_DBDataSet
    {
        partial class WarrantyDataTable
        {
        }
    }
}

namespace SnapShot.SnapShot_DBDataSetTableAdapters
{
}
