﻿namespace SnapShot
{
    partial class client_select
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewClientSelection = new System.Windows.Forms.DataGridView();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.snapShot_DBDataSet = new SnapShot.SnapShot_DBDataSet();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.exit_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.clientTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.ClientTableAdapter();
            this.client_key_column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.businessnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientSelection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewClientSelection
            // 
            this.dataGridViewClientSelection.AllowUserToAddRows = false;
            this.dataGridViewClientSelection.AllowUserToDeleteRows = false;
            this.dataGridViewClientSelection.AllowUserToOrderColumns = true;
            this.dataGridViewClientSelection.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewClientSelection.AutoGenerateColumns = false;
            this.dataGridViewClientSelection.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewClientSelection.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewClientSelection.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewClientSelection.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal;
            this.dataGridViewClientSelection.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewClientSelection.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewClientSelection.ColumnHeadersHeight = 35;
            this.dataGridViewClientSelection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewClientSelection.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.client_key_column,
            this.businessnameDataGridViewTextBoxColumn,
            this.location});
            this.dataGridViewClientSelection.DataSource = this.clientBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewClientSelection.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewClientSelection.EnableHeadersVisualStyles = false;
            this.dataGridViewClientSelection.GridColor = System.Drawing.Color.White;
            this.dataGridViewClientSelection.Location = new System.Drawing.Point(12, 34);
            this.dataGridViewClientSelection.Name = "dataGridViewClientSelection";
            this.dataGridViewClientSelection.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewClientSelection.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewClientSelection.RowHeadersVisible = false;
            this.dataGridViewClientSelection.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.dataGridViewClientSelection.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewClientSelection.RowTemplate.Height = 30;
            this.dataGridViewClientSelection.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewClientSelection.Size = new System.Drawing.Size(499, 227);
            this.dataGridViewClientSelection.TabIndex = 1;
            this.dataGridViewClientSelection.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewClientSelection_CellMouseClick);
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // snapShot_DBDataSet
            // 
            this.snapShot_DBDataSet.DataSetName = "SnapShot_DBDataSet";
            this.snapShot_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(96, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(182, 20);
            this.textBox1.TabIndex = 2;
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.Transparent;
            this.exit_button.FlatAppearance.BorderSize = 0;
            this.exit_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.exit_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.ForeColor = System.Drawing.Color.Transparent;
            this.exit_button.Location = new System.Drawing.Point(491, 1);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(36, 31);
            this.exit_button.TabIndex = 4;
            this.exit_button.Text = "x";
            this.exit_button.UseCompatibleTextRendering = true;
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arimo", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "select client";
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // client_key_column
            // 
            this.client_key_column.DataPropertyName = "client_key";
            this.client_key_column.HeaderText = "CLIENT_KEY";
            this.client_key_column.Name = "client_key_column";
            this.client_key_column.ReadOnly = true;
            // 
            // businessnameDataGridViewTextBoxColumn
            // 
            this.businessnameDataGridViewTextBoxColumn.DataPropertyName = "business_name";
            this.businessnameDataGridViewTextBoxColumn.HeaderText = "Business name";
            this.businessnameDataGridViewTextBoxColumn.Name = "businessnameDataGridViewTextBoxColumn";
            this.businessnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // location
            // 
            this.location.DataPropertyName = "Location";
            this.location.HeaderText = "Location";
            this.location.Name = "location";
            this.location.ReadOnly = true;
            // 
            // client_select
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(523, 273);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridViewClientSelection);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "client_select";
            this.Text = "client_select";
            this.Load += new System.EventHandler(this.client_select_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.client_select_MouseDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientSelection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private SnapShot_DBDataSet snapShot_DBDataSet;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private SnapShot_DBDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.DataGridView dataGridViewClientSelection;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn client_key_column;
        private System.Windows.Forms.DataGridViewTextBoxColumn businessnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn location;
    }
}