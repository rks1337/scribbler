﻿namespace SnapShot
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button_home = new System.Windows.Forms.Button();
            this.button_client = new System.Windows.Forms.Button();
            this.button_location = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.normal_max_button = new System.Windows.Forms.Button();
            this.minimize_button = new System.Windows.Forms.Button();
            this.client_panel = new System.Windows.Forms.Panel();
            this.client_button_label = new System.Windows.Forms.Button();
            this.snap_panel = new System.Windows.Forms.Panel();
            this.locationComboBox = new System.Windows.Forms.ComboBox();
            this.home_panel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.client_tab_select_button = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.selectCommunicationLinks = new System.Windows.Forms.Button();
            this.tab_function_control = new System.Windows.Forms.TabControl();
            this.hardwareTabPage = new System.Windows.Forms.TabPage();
            this.hardwarePanel = new System.Windows.Forms.Panel();
            this.hwDateWrittenOffPicker = new System.Windows.Forms.DateTimePicker();
            this.hwWarrantyExpPicker = new System.Windows.Forms.DateTimePicker();
            this.hwDatePurchasedPicker = new System.Windows.Forms.DateTimePicker();
            this.hwNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.hwClientAssestTxtBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.hwSerialNumTxtBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.hwModelTxtBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.hwDeviceNameTxtBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.hwVendorTxtBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.hwCategoryCodeTxtBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.licensesTabPage = new System.Windows.Forms.TabPage();
            this.licensesPanel = new System.Windows.Forms.Panel();
            this.licenseTicketNumberNumeric = new System.Windows.Forms.NumericUpDown();
            this.licensePackOrCoresNumeric = new System.Windows.Forms.NumericUpDown();
            this.licenseVendorAllocatedKeyTxtBox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.licenseNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.licenseQuoteRefTxtBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.licenseExpDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.licensesAllocatedNumeric = new System.Windows.Forms.NumericUpDown();
            this.licensePurchasedNumeric = new System.Windows.Forms.NumericUpDown();
            this.licenseQuantityNumeric = new System.Windows.Forms.NumericUpDown();
            this.licenseDatePurchasedPicker = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.licenseSubscriptionTyTxtBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.licenseProductDescTxtBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.licenseCategoryTxtBox = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.licenseCodeOffsetTxtBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.usersTabPage = new System.Windows.Forms.TabPage();
            this.userPanel = new System.Windows.Forms.Panel();
            this.userSuspendDatePicker = new System.Windows.Forms.DateTimePicker();
            this.userNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.userTerminationDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label30 = new System.Windows.Forms.Label();
            this.userCommenceDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label31 = new System.Windows.Forms.Label();
            this.userFirstNameTxtBox = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.userSurnameTxtBox = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.locationTabPage = new System.Windows.Forms.TabPage();
            this.locationPanel = new System.Windows.Forms.Panel();
            this.locationNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.locationEnvironmentTxtBox = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.locationDescTxtBox = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.emailTabPage = new System.Windows.Forms.TabPage();
            this.emailPanel = new System.Windows.Forms.Panel();
            this.emailAddressNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.emailAddressMailboxTyTxtBox = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.emailAddressTxtBox = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.supportAgreementTabPage = new System.Windows.Forms.TabPage();
            this.supportAgreementPanel = new System.Windows.Forms.Panel();
            this.supportAgreeInactiveRadioBtn = new System.Windows.Forms.RadioButton();
            this.supportAgreeActiveRadioBtn = new System.Windows.Forms.RadioButton();
            this.supportAgreeNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.supportAgreeExpDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label35 = new System.Windows.Forms.Label();
            this.supportAgreeCommenDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label36 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.supportAgreementDescTxtBox = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.warrantyTabPage = new System.Windows.Forms.TabPage();
            this.warrantyPanel = new System.Windows.Forms.Panel();
            this.warrantyInactiveRadioBtn = new System.Windows.Forms.RadioButton();
            this.warrantyActiveRadioBtn = new System.Windows.Forms.RadioButton();
            this.label53 = new System.Windows.Forms.Label();
            this.warrantyExpDatePicker = new System.Windows.Forms.DateTimePicker();
            this.warrantyStartDatePicker = new System.Windows.Forms.DateTimePicker();
            this.warrantyQuoteRefTxtBox = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.warrantyNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.warrantyTicketNumberTxtBox = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.warrantyTypeTxtBox = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.communicationLinkTabPage = new System.Windows.Forms.TabPage();
            this.communicationLinkPanel = new System.Windows.Forms.Panel();
            this.communiLinkConnectAgreementComboBox = new System.Windows.Forms.ComboBox();
            this.communiLinkTermMonthNumeric = new System.Windows.Forms.NumericUpDown();
            this.communiLinkCommenceDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label49 = new System.Windows.Forms.Label();
            this.communicationLinkExpDatePicker = new System.Windows.Forms.DateTimePicker();
            this.communicationLinkNotesTxtBox = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.communiLinkSpeedTxtBox = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.communiLinkTypeTxtBox = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.communicationLinkVendorTxtBox = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.select_licenses = new System.Windows.Forms.Button();
            this.selectEmail = new System.Windows.Forms.Button();
            this.dataGridViewMain = new System.Windows.Forms.DataGridView();
            this.selectWarranty = new System.Windows.Forms.Button();
            this.function_box = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.createDataButton = new System.Windows.Forms.Button();
            this.modifyButton = new System.Windows.Forms.Button();
            this.selectSupportAgreements = new System.Windows.Forms.Button();
            this.select_user = new System.Windows.Forms.Button();
            this.select_hardware = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tab_control_main = new System.Windows.Forms.TabControl();
            this.system_time_label = new System.Windows.Forms.Label();
            this.skinny_horizontal_bar = new System.Windows.Forms.FlowLayoutPanel();
            this.refresh_button = new System.Windows.Forms.Button();
            this.system_timer = new System.Windows.Forms.Timer(this.components);
            this.locationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.snapShot_DBDataSet = new SnapShot.SnapShot_DBDataSet();
            this.userkeyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commencementdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.terminationdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suspenddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.licenseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.snapShot_DBDataSet1 = new SnapShot.SnapShot_DBDataSet();
            this.hardwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.ClientTableAdapter();
            this.clientTableAdapter1 = new SnapShot.SnapShot_DBDataSetTableAdapters.ClientTableAdapter();
            this.hardwareTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.HardwareTableAdapter();
            this.licenseTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.LicenseTableAdapter();
            this.emailAddressBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.email_AddressTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.Email_AddressTableAdapter();
            this.supportAgreementBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.support_AgreementTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.Support_AgreementTableAdapter();
            this.warrantyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.warrantyTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.WarrantyTableAdapter();
            this.communicationLinkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.communication_LinkTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.Communication_LinkTableAdapter();
            this.locationTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.LocationTableAdapter();
            this.userTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.UserTableAdapter();
            this.client_panel.SuspendLayout();
            this.snap_panel.SuspendLayout();
            this.home_panel.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tab_function_control.SuspendLayout();
            this.hardwareTabPage.SuspendLayout();
            this.hardwarePanel.SuspendLayout();
            this.licensesTabPage.SuspendLayout();
            this.licensesPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licenseTicketNumberNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensePackOrCoresNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensesAllocatedNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensePurchasedNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseQuantityNumeric)).BeginInit();
            this.usersTabPage.SuspendLayout();
            this.userPanel.SuspendLayout();
            this.locationTabPage.SuspendLayout();
            this.locationPanel.SuspendLayout();
            this.emailTabPage.SuspendLayout();
            this.emailPanel.SuspendLayout();
            this.supportAgreementTabPage.SuspendLayout();
            this.supportAgreementPanel.SuspendLayout();
            this.warrantyTabPage.SuspendLayout();
            this.warrantyPanel.SuspendLayout();
            this.communicationLinkTabPage.SuspendLayout();
            this.communicationLinkPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.communiLinkTermMonthNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMain)).BeginInit();
            this.function_box.SuspendLayout();
            this.tab_control_main.SuspendLayout();
            this.skinny_horizontal_bar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailAddressBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supportAgreementBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.warrantyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.communicationLinkBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button_home
            // 
            this.button_home.FlatAppearance.BorderSize = 0;
            this.button_home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_home.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.button_home.ForeColor = System.Drawing.Color.White;
            this.button_home.Location = new System.Drawing.Point(1, 3);
            this.button_home.Name = "button_home";
            this.button_home.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_home.Size = new System.Drawing.Size(176, 46);
            this.button_home.TabIndex = 8;
            this.button_home.Text = "Home";
            this.button_home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_home.UseVisualStyleBackColor = true;
            this.button_home.Click += new System.EventHandler(this.button_home_Click);
            this.button_home.MouseEnter += new System.EventHandler(this.button_home_MouseEnter);
            this.button_home.MouseLeave += new System.EventHandler(this.button_home_MouseLeave);
            // 
            // button_client
            // 
            this.button_client.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button_client.FlatAppearance.BorderSize = 0;
            this.button_client.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_client.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button_client.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_client.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_client.ForeColor = System.Drawing.Color.White;
            this.button_client.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_client.Location = new System.Drawing.Point(2, 3);
            this.button_client.Name = "button_client";
            this.button_client.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_client.Size = new System.Drawing.Size(53, 46);
            this.button_client.TabIndex = 8;
            this.button_client.Text = "Client:";
            this.button_client.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_client.UseVisualStyleBackColor = true;
            this.button_client.Click += new System.EventHandler(this.button_client_Click);
            this.button_client.MouseEnter += new System.EventHandler(this.button_client_MouseEnter);
            this.button_client.MouseLeave += new System.EventHandler(this.button_client_MouseLeave);
            // 
            // button_location
            // 
            this.button_location.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button_location.FlatAppearance.BorderSize = 0;
            this.button_location.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button_location.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button_location.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_location.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.button_location.ForeColor = System.Drawing.Color.White;
            this.button_location.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_location.Location = new System.Drawing.Point(3, 5);
            this.button_location.Name = "button_location";
            this.button_location.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_location.Size = new System.Drawing.Size(178, 42);
            this.button_location.TabIndex = 12;
            this.button_location.Text = "Location:";
            this.button_location.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_location.UseVisualStyleBackColor = true;
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.Transparent;
            this.exit_button.FlatAppearance.BorderSize = 0;
            this.exit_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(15)))), ((int)(((byte)(29)))));
            this.exit_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(17)))), ((int)(((byte)(35)))));
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.ForeColor = System.Drawing.Color.Gray;
            this.exit_button.Location = new System.Drawing.Point(808, 3);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(36, 31);
            this.exit_button.TabIndex = 0;
            this.exit_button.Text = "x";
            this.exit_button.UseCompatibleTextRendering = true;
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            this.exit_button.MouseEnter += new System.EventHandler(this.exit_button_MouseEnter);
            this.exit_button.MouseLeave += new System.EventHandler(this.exit_button_MouseLeave);
            // 
            // normal_max_button
            // 
            this.normal_max_button.BackColor = System.Drawing.Color.Transparent;
            this.normal_max_button.FlatAppearance.BorderSize = 0;
            this.normal_max_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.normal_max_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.normal_max_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.normal_max_button.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.normal_max_button.ForeColor = System.Drawing.Color.Gray;
            this.normal_max_button.Location = new System.Drawing.Point(766, 3);
            this.normal_max_button.Name = "normal_max_button";
            this.normal_max_button.Padding = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.normal_max_button.Size = new System.Drawing.Size(36, 31);
            this.normal_max_button.TabIndex = 1;
            this.normal_max_button.Text = "■";
            this.normal_max_button.UseCompatibleTextRendering = true;
            this.normal_max_button.UseVisualStyleBackColor = false;
            this.normal_max_button.Click += new System.EventHandler(this.normal_max_button_Click);
            this.normal_max_button.MouseEnter += new System.EventHandler(this.normal_max_button_MouseEnter);
            this.normal_max_button.MouseLeave += new System.EventHandler(this.normal_max_button_MouseLeave);
            // 
            // minimize_button
            // 
            this.minimize_button.BackColor = System.Drawing.Color.Transparent;
            this.minimize_button.FlatAppearance.BorderSize = 0;
            this.minimize_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.minimize_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.minimize_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimize_button.ForeColor = System.Drawing.Color.Gray;
            this.minimize_button.Location = new System.Drawing.Point(724, 3);
            this.minimize_button.Name = "minimize_button";
            this.minimize_button.Size = new System.Drawing.Size(36, 31);
            this.minimize_button.TabIndex = 2;
            this.minimize_button.Text = "-";
            this.minimize_button.UseCompatibleTextRendering = true;
            this.minimize_button.UseVisualStyleBackColor = false;
            this.minimize_button.Click += new System.EventHandler(this.minimize_button_Click);
            this.minimize_button.MouseEnter += new System.EventHandler(this.minimize_button_MouseEnter);
            this.minimize_button.MouseLeave += new System.EventHandler(this.minimize_button_MouseLeave);
            // 
            // client_panel
            // 
            this.client_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.client_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.client_panel.Controls.Add(this.client_button_label);
            this.client_panel.Controls.Add(this.button_client);
            this.client_panel.Location = new System.Drawing.Point(198, 30);
            this.client_panel.Name = "client_panel";
            this.client_panel.Size = new System.Drawing.Size(200, 53);
            this.client_panel.TabIndex = 15;
            this.client_panel.MouseEnter += new System.EventHandler(this.client_panel_MouseEnter);
            this.client_panel.MouseLeave += new System.EventHandler(this.client_panel_MouseLeave);
            // 
            // client_button_label
            // 
            this.client_button_label.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.client_button_label.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.client_button_label.FlatAppearance.BorderSize = 0;
            this.client_button_label.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.client_button_label.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.client_button_label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.client_button_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.client_button_label.ForeColor = System.Drawing.Color.White;
            this.client_button_label.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.client_button_label.Location = new System.Drawing.Point(61, 5);
            this.client_button_label.Name = "client_button_label";
            this.client_button_label.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.client_button_label.Size = new System.Drawing.Size(134, 42);
            this.client_button_label.TabIndex = 10;
            this.client_button_label.Text = "▼";
            this.client_button_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.client_button_label.UseVisualStyleBackColor = false;
            this.client_button_label.Click += new System.EventHandler(this.client_button_label_Click);
            this.client_button_label.MouseEnter += new System.EventHandler(this.client_button_label_MouseEnter);
            this.client_button_label.MouseLeave += new System.EventHandler(this.client_button_label_MouseLeave);
            // 
            // snap_panel
            // 
            this.snap_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.snap_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.snap_panel.Controls.Add(this.locationComboBox);
            this.snap_panel.Controls.Add(this.button_location);
            this.snap_panel.Location = new System.Drawing.Point(397, 30);
            this.snap_panel.Name = "snap_panel";
            this.snap_panel.Size = new System.Drawing.Size(203, 53);
            this.snap_panel.TabIndex = 16;
            // 
            // locationComboBox
            // 
            this.locationComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.locationBindingSource, "location_description", true));
            this.locationComboBox.DisplayMember = "location_description";
            this.locationComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.locationComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.locationComboBox.FormattingEnabled = true;
            this.locationComboBox.Location = new System.Drawing.Point(74, 17);
            this.locationComboBox.Name = "locationComboBox";
            this.locationComboBox.Size = new System.Drawing.Size(121, 21);
            this.locationComboBox.TabIndex = 21;
            this.locationComboBox.ValueMember = "location_description";
            this.locationComboBox.DropDown += new System.EventHandler(this.locationComboBox_DropDown);
            this.locationComboBox.DropDownClosed += new System.EventHandler(this.locationComboBox_DropDownClosed);
            // 
            // home_panel
            // 
            this.home_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.home_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.home_panel.Controls.Add(this.button_home);
            this.home_panel.Location = new System.Drawing.Point(-1, 30);
            this.home_panel.Name = "home_panel";
            this.home_panel.Size = new System.Drawing.Size(200, 53);
            this.home_panel.TabIndex = 14;
            this.home_panel.MouseEnter += new System.EventHandler(this.home_panel_MouseEnter);
            this.home_panel.MouseLeave += new System.EventHandler(this.home_panel_MouseLeave);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(599, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(307, 53);
            this.panel1.TabIndex = 17;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Magenta;
            this.tabPage3.Controls.Add(this.client_tab_select_button);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(895, 442);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            // 
            // client_tab_select_button
            // 
            this.client_tab_select_button.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.client_tab_select_button.BackColor = System.Drawing.Color.Transparent;
            this.client_tab_select_button.FlatAppearance.BorderColor = System.Drawing.Color.Magenta;
            this.client_tab_select_button.FlatAppearance.BorderSize = 0;
            this.client_tab_select_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.client_tab_select_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.client_tab_select_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.client_tab_select_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.client_tab_select_button.ForeColor = System.Drawing.Color.Black;
            this.client_tab_select_button.Location = new System.Drawing.Point(-4, 31);
            this.client_tab_select_button.Name = "client_tab_select_button";
            this.client_tab_select_button.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.client_tab_select_button.Size = new System.Drawing.Size(809, 205);
            this.client_tab_select_button.TabIndex = 8;
            this.client_tab_select_button.Text = "please select a client to begin☺";
            this.client_tab_select_button.UseVisualStyleBackColor = false;
            this.client_tab_select_button.Click += new System.EventHandler(this.client_tab_select_button_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.selectCommunicationLinks);
            this.tabPage2.Controls.Add(this.tab_function_control);
            this.tabPage2.Controls.Add(this.select_licenses);
            this.tabPage2.Controls.Add(this.selectEmail);
            this.tabPage2.Controls.Add(this.dataGridViewMain);
            this.tabPage2.Controls.Add(this.selectWarranty);
            this.tabPage2.Controls.Add(this.function_box);
            this.tabPage2.Controls.Add(this.selectSupportAgreements);
            this.tabPage2.Controls.Add(this.select_user);
            this.tabPage2.Controls.Add(this.select_hardware);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(895, 442);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabPage2_MouseDown);
            // 
            // selectCommunicationLinks
            // 
            this.selectCommunicationLinks.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.selectCommunicationLinks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectCommunicationLinks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectCommunicationLinks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectCommunicationLinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectCommunicationLinks.ForeColor = System.Drawing.Color.Black;
            this.selectCommunicationLinks.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectCommunicationLinks.Location = new System.Drawing.Point(6, 150);
            this.selectCommunicationLinks.Name = "selectCommunicationLinks";
            this.selectCommunicationLinks.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.selectCommunicationLinks.Size = new System.Drawing.Size(81, 42);
            this.selectCommunicationLinks.TabIndex = 19;
            this.selectCommunicationLinks.Text = "Comm-Links";
            this.selectCommunicationLinks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectCommunicationLinks.UseVisualStyleBackColor = true;
            this.selectCommunicationLinks.Click += new System.EventHandler(this.selectCommunicationLinks_Click);
            // 
            // tab_function_control
            // 
            this.tab_function_control.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tab_function_control.Controls.Add(this.hardwareTabPage);
            this.tab_function_control.Controls.Add(this.licensesTabPage);
            this.tab_function_control.Controls.Add(this.usersTabPage);
            this.tab_function_control.Controls.Add(this.locationTabPage);
            this.tab_function_control.Controls.Add(this.emailTabPage);
            this.tab_function_control.Controls.Add(this.supportAgreementTabPage);
            this.tab_function_control.Controls.Add(this.warrantyTabPage);
            this.tab_function_control.Controls.Add(this.communicationLinkTabPage);
            this.tab_function_control.Location = new System.Drawing.Point(606, -15);
            this.tab_function_control.Name = "tab_function_control";
            this.tab_function_control.SelectedIndex = 0;
            this.tab_function_control.Size = new System.Drawing.Size(296, 461);
            this.tab_function_control.TabIndex = 0;
            // 
            // hardwareTabPage
            // 
            this.hardwareTabPage.BackColor = System.Drawing.Color.White;
            this.hardwareTabPage.Controls.Add(this.hardwarePanel);
            this.hardwareTabPage.Location = new System.Drawing.Point(4, 22);
            this.hardwareTabPage.Name = "hardwareTabPage";
            this.hardwareTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.hardwareTabPage.Size = new System.Drawing.Size(288, 435);
            this.hardwareTabPage.TabIndex = 1;
            this.hardwareTabPage.Text = "tabPage5";
            // 
            // hardwarePanel
            // 
            this.hardwarePanel.AutoScroll = true;
            this.hardwarePanel.Controls.Add(this.hwDateWrittenOffPicker);
            this.hardwarePanel.Controls.Add(this.hwWarrantyExpPicker);
            this.hardwarePanel.Controls.Add(this.hwDatePurchasedPicker);
            this.hardwarePanel.Controls.Add(this.hwNotesTxtBox);
            this.hardwarePanel.Controls.Add(this.label11);
            this.hardwarePanel.Controls.Add(this.label10);
            this.hardwarePanel.Controls.Add(this.label9);
            this.hardwarePanel.Controls.Add(this.label8);
            this.hardwarePanel.Controls.Add(this.hwClientAssestTxtBox);
            this.hardwarePanel.Controls.Add(this.label7);
            this.hardwarePanel.Controls.Add(this.hwSerialNumTxtBox);
            this.hardwarePanel.Controls.Add(this.label6);
            this.hardwarePanel.Controls.Add(this.hwModelTxtBox);
            this.hardwarePanel.Controls.Add(this.label5);
            this.hardwarePanel.Controls.Add(this.hwDeviceNameTxtBox);
            this.hardwarePanel.Controls.Add(this.label4);
            this.hardwarePanel.Controls.Add(this.hwVendorTxtBox);
            this.hardwarePanel.Controls.Add(this.label3);
            this.hardwarePanel.Controls.Add(this.hwCategoryCodeTxtBox);
            this.hardwarePanel.Controls.Add(this.label2);
            this.hardwarePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hardwarePanel.Location = new System.Drawing.Point(3, 3);
            this.hardwarePanel.Margin = new System.Windows.Forms.Padding(2);
            this.hardwarePanel.Name = "hardwarePanel";
            this.hardwarePanel.Size = new System.Drawing.Size(282, 429);
            this.hardwarePanel.TabIndex = 0;
            // 
            // hwDateWrittenOffPicker
            // 
            this.hwDateWrittenOffPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.hwDateWrittenOffPicker.Location = new System.Drawing.Point(122, 239);
            this.hwDateWrittenOffPicker.Margin = new System.Windows.Forms.Padding(2);
            this.hwDateWrittenOffPicker.Name = "hwDateWrittenOffPicker";
            this.hwDateWrittenOffPicker.Size = new System.Drawing.Size(146, 20);
            this.hwDateWrittenOffPicker.TabIndex = 9;
            // 
            // hwWarrantyExpPicker
            // 
            this.hwWarrantyExpPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.hwWarrantyExpPicker.Location = new System.Drawing.Point(122, 209);
            this.hwWarrantyExpPicker.Margin = new System.Windows.Forms.Padding(2);
            this.hwWarrantyExpPicker.Name = "hwWarrantyExpPicker";
            this.hwWarrantyExpPicker.Size = new System.Drawing.Size(146, 20);
            this.hwWarrantyExpPicker.TabIndex = 8;
            // 
            // hwDatePurchasedPicker
            // 
            this.hwDatePurchasedPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.hwDatePurchasedPicker.Location = new System.Drawing.Point(122, 179);
            this.hwDatePurchasedPicker.Margin = new System.Windows.Forms.Padding(2);
            this.hwDatePurchasedPicker.Name = "hwDatePurchasedPicker";
            this.hwDatePurchasedPicker.Size = new System.Drawing.Size(146, 20);
            this.hwDatePurchasedPicker.TabIndex = 7;
            // 
            // hwNotesTxtBox
            // 
            this.hwNotesTxtBox.Location = new System.Drawing.Point(122, 268);
            this.hwNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwNotesTxtBox.Name = "hwNotesTxtBox";
            this.hwNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwNotesTxtBox.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 271);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Notes";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 243);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "Date Written-Off";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 213);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Warranty Expiry";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 183);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Date Purchased";
            // 
            // hwClientAssestTxtBox
            // 
            this.hwClientAssestTxtBox.Location = new System.Drawing.Point(122, 148);
            this.hwClientAssestTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwClientAssestTxtBox.Name = "hwClientAssestTxtBox";
            this.hwClientAssestTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwClientAssestTxtBox.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 150);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Client Assest Number";
            // 
            // hwSerialNumTxtBox
            // 
            this.hwSerialNumTxtBox.Location = new System.Drawing.Point(122, 118);
            this.hwSerialNumTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwSerialNumTxtBox.Name = "hwSerialNumTxtBox";
            this.hwSerialNumTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwSerialNumTxtBox.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 120);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Serial Number";
            // 
            // hwModelTxtBox
            // 
            this.hwModelTxtBox.Location = new System.Drawing.Point(122, 90);
            this.hwModelTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwModelTxtBox.Name = "hwModelTxtBox";
            this.hwModelTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwModelTxtBox.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 93);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Model";
            // 
            // hwDeviceNameTxtBox
            // 
            this.hwDeviceNameTxtBox.Location = new System.Drawing.Point(122, 64);
            this.hwDeviceNameTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwDeviceNameTxtBox.Name = "hwDeviceNameTxtBox";
            this.hwDeviceNameTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwDeviceNameTxtBox.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 67);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Device Name";
            // 
            // hwVendorTxtBox
            // 
            this.hwVendorTxtBox.Location = new System.Drawing.Point(122, 37);
            this.hwVendorTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwVendorTxtBox.Name = "hwVendorTxtBox";
            this.hwVendorTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwVendorTxtBox.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 40);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Vendor";
            // 
            // hwCategoryCodeTxtBox
            // 
            this.hwCategoryCodeTxtBox.Location = new System.Drawing.Point(122, 9);
            this.hwCategoryCodeTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.hwCategoryCodeTxtBox.Name = "hwCategoryCodeTxtBox";
            this.hwCategoryCodeTxtBox.Size = new System.Drawing.Size(146, 20);
            this.hwCategoryCodeTxtBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Category Code";
            // 
            // licensesTabPage
            // 
            this.licensesTabPage.Controls.Add(this.licensesPanel);
            this.licensesTabPage.Location = new System.Drawing.Point(4, 22);
            this.licensesTabPage.Margin = new System.Windows.Forms.Padding(2);
            this.licensesTabPage.Name = "licensesTabPage";
            this.licensesTabPage.Padding = new System.Windows.Forms.Padding(2);
            this.licensesTabPage.Size = new System.Drawing.Size(288, 435);
            this.licensesTabPage.TabIndex = 2;
            this.licensesTabPage.Text = "tabPage6";
            this.licensesTabPage.UseVisualStyleBackColor = true;
            // 
            // licensesPanel
            // 
            this.licensesPanel.AutoScroll = true;
            this.licensesPanel.BackColor = System.Drawing.Color.White;
            this.licensesPanel.Controls.Add(this.licenseTicketNumberNumeric);
            this.licensesPanel.Controls.Add(this.licensePackOrCoresNumeric);
            this.licensesPanel.Controls.Add(this.licenseVendorAllocatedKeyTxtBox);
            this.licensesPanel.Controls.Add(this.label25);
            this.licensesPanel.Controls.Add(this.licenseNotesTxtBox);
            this.licensesPanel.Controls.Add(this.label23);
            this.licensesPanel.Controls.Add(this.label22);
            this.licensesPanel.Controls.Add(this.licenseQuoteRefTxtBox);
            this.licensesPanel.Controls.Add(this.label24);
            this.licensesPanel.Controls.Add(this.licenseExpDatePicker);
            this.licensesPanel.Controls.Add(this.label12);
            this.licensesPanel.Controls.Add(this.licensesAllocatedNumeric);
            this.licensesPanel.Controls.Add(this.licensePurchasedNumeric);
            this.licensesPanel.Controls.Add(this.licenseQuantityNumeric);
            this.licensesPanel.Controls.Add(this.licenseDatePurchasedPicker);
            this.licensesPanel.Controls.Add(this.label13);
            this.licensesPanel.Controls.Add(this.label14);
            this.licensesPanel.Controls.Add(this.label15);
            this.licensesPanel.Controls.Add(this.label16);
            this.licensesPanel.Controls.Add(this.label17);
            this.licensesPanel.Controls.Add(this.licenseSubscriptionTyTxtBox);
            this.licensesPanel.Controls.Add(this.label18);
            this.licensesPanel.Controls.Add(this.licenseProductDescTxtBox);
            this.licensesPanel.Controls.Add(this.label19);
            this.licensesPanel.Controls.Add(this.licenseCategoryTxtBox);
            this.licensesPanel.Controls.Add(this.label20);
            this.licensesPanel.Controls.Add(this.licenseCodeOffsetTxtBox);
            this.licensesPanel.Controls.Add(this.label21);
            this.licensesPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.licensesPanel.Location = new System.Drawing.Point(2, 2);
            this.licensesPanel.Margin = new System.Windows.Forms.Padding(2);
            this.licensesPanel.Name = "licensesPanel";
            this.licensesPanel.Size = new System.Drawing.Size(284, 431);
            this.licensesPanel.TabIndex = 1;
            // 
            // licenseTicketNumberNumeric
            // 
            this.licenseTicketNumberNumeric.Location = new System.Drawing.Point(122, 359);
            this.licenseTicketNumberNumeric.Margin = new System.Windows.Forms.Padding(2);
            this.licenseTicketNumberNumeric.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.licenseTicketNumberNumeric.Name = "licenseTicketNumberNumeric";
            this.licenseTicketNumberNumeric.Size = new System.Drawing.Size(145, 20);
            this.licenseTicketNumberNumeric.TabIndex = 13;
            // 
            // licensePackOrCoresNumeric
            // 
            this.licensePackOrCoresNumeric.Location = new System.Drawing.Point(122, 119);
            this.licensePackOrCoresNumeric.Margin = new System.Windows.Forms.Padding(2);
            this.licensePackOrCoresNumeric.Name = "licensePackOrCoresNumeric";
            this.licensePackOrCoresNumeric.Size = new System.Drawing.Size(145, 20);
            this.licensePackOrCoresNumeric.TabIndex = 5;
            // 
            // licenseVendorAllocatedKeyTxtBox
            // 
            this.licenseVendorAllocatedKeyTxtBox.Location = new System.Drawing.Point(122, 240);
            this.licenseVendorAllocatedKeyTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.licenseVendorAllocatedKeyTxtBox.Name = "licenseVendorAllocatedKeyTxtBox";
            this.licenseVendorAllocatedKeyTxtBox.Size = new System.Drawing.Size(146, 20);
            this.licenseVendorAllocatedKeyTxtBox.TabIndex = 9;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(4, 242);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(109, 13);
            this.label25.TabIndex = 31;
            this.label25.Text = "Vendor Allocated Key";
            // 
            // licenseNotesTxtBox
            // 
            this.licenseNotesTxtBox.Location = new System.Drawing.Point(122, 387);
            this.licenseNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.licenseNotesTxtBox.Name = "licenseNotesTxtBox";
            this.licenseNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.licenseNotesTxtBox.TabIndex = 14;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(4, 389);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 13);
            this.label23.TabIndex = 29;
            this.label23.Text = "Notes";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(4, 361);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 13);
            this.label22.TabIndex = 27;
            this.label22.Text = "Ticket Number";
            // 
            // licenseQuoteRefTxtBox
            // 
            this.licenseQuoteRefTxtBox.Location = new System.Drawing.Point(122, 329);
            this.licenseQuoteRefTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.licenseQuoteRefTxtBox.Name = "licenseQuoteRefTxtBox";
            this.licenseQuoteRefTxtBox.Size = new System.Drawing.Size(146, 20);
            this.licenseQuoteRefTxtBox.TabIndex = 12;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(4, 332);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(56, 13);
            this.label24.TabIndex = 25;
            this.label24.Text = "Quote Ref";
            // 
            // licenseExpDatePicker
            // 
            this.licenseExpDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.licenseExpDatePicker.Location = new System.Drawing.Point(122, 299);
            this.licenseExpDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.licenseExpDatePicker.Name = "licenseExpDatePicker";
            this.licenseExpDatePicker.Size = new System.Drawing.Size(146, 20);
            this.licenseExpDatePicker.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 303);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Expiry Date";
            // 
            // licensesAllocatedNumeric
            // 
            this.licensesAllocatedNumeric.Location = new System.Drawing.Point(122, 209);
            this.licensesAllocatedNumeric.Margin = new System.Windows.Forms.Padding(2);
            this.licensesAllocatedNumeric.Name = "licensesAllocatedNumeric";
            this.licensesAllocatedNumeric.Size = new System.Drawing.Size(145, 20);
            this.licensesAllocatedNumeric.TabIndex = 8;
            // 
            // licensePurchasedNumeric
            // 
            this.licensePurchasedNumeric.Location = new System.Drawing.Point(122, 179);
            this.licensePurchasedNumeric.Margin = new System.Windows.Forms.Padding(2);
            this.licensePurchasedNumeric.Name = "licensePurchasedNumeric";
            this.licensePurchasedNumeric.Size = new System.Drawing.Size(145, 20);
            this.licensePurchasedNumeric.TabIndex = 7;
            // 
            // licenseQuantityNumeric
            // 
            this.licenseQuantityNumeric.Location = new System.Drawing.Point(122, 146);
            this.licenseQuantityNumeric.Margin = new System.Windows.Forms.Padding(2);
            this.licenseQuantityNumeric.Name = "licenseQuantityNumeric";
            this.licenseQuantityNumeric.Size = new System.Drawing.Size(145, 20);
            this.licenseQuantityNumeric.TabIndex = 6;
            // 
            // licenseDatePurchasedPicker
            // 
            this.licenseDatePurchasedPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.licenseDatePurchasedPicker.Location = new System.Drawing.Point(122, 269);
            this.licenseDatePurchasedPicker.Margin = new System.Windows.Forms.Padding(2);
            this.licenseDatePurchasedPicker.Name = "licenseDatePurchasedPicker";
            this.licenseDatePurchasedPicker.Size = new System.Drawing.Size(146, 20);
            this.licenseDatePurchasedPicker.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(4, 273);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Date Purchased";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 213);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Licenses Allocated";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(4, 183);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Licenses Purchased";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 150);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 13);
            this.label16.TabIndex = 10;
            this.label16.Text = "Quantity";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(4, 120);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 13);
            this.label17.TabIndex = 8;
            this.label17.Text = "Pack/ Cores";
            // 
            // licenseSubscriptionTyTxtBox
            // 
            this.licenseSubscriptionTyTxtBox.Location = new System.Drawing.Point(122, 90);
            this.licenseSubscriptionTyTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.licenseSubscriptionTyTxtBox.Name = "licenseSubscriptionTyTxtBox";
            this.licenseSubscriptionTyTxtBox.Size = new System.Drawing.Size(146, 20);
            this.licenseSubscriptionTyTxtBox.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(4, 93);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Subscription Type";
            // 
            // licenseProductDescTxtBox
            // 
            this.licenseProductDescTxtBox.Location = new System.Drawing.Point(122, 64);
            this.licenseProductDescTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.licenseProductDescTxtBox.Name = "licenseProductDescTxtBox";
            this.licenseProductDescTxtBox.Size = new System.Drawing.Size(146, 20);
            this.licenseProductDescTxtBox.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(4, 67);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "Product Description";
            // 
            // licenseCategoryTxtBox
            // 
            this.licenseCategoryTxtBox.Location = new System.Drawing.Point(122, 37);
            this.licenseCategoryTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.licenseCategoryTxtBox.Name = "licenseCategoryTxtBox";
            this.licenseCategoryTxtBox.Size = new System.Drawing.Size(146, 20);
            this.licenseCategoryTxtBox.TabIndex = 2;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 40);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(89, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "License Category";
            // 
            // licenseCodeOffsetTxtBox
            // 
            this.licenseCodeOffsetTxtBox.Location = new System.Drawing.Point(122, 9);
            this.licenseCodeOffsetTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.licenseCodeOffsetTxtBox.Name = "licenseCodeOffsetTxtBox";
            this.licenseCodeOffsetTxtBox.Size = new System.Drawing.Size(146, 20);
            this.licenseCodeOffsetTxtBox.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(4, 11);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(108, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "License Code/ Offest";
            // 
            // usersTabPage
            // 
            this.usersTabPage.Controls.Add(this.userPanel);
            this.usersTabPage.Location = new System.Drawing.Point(4, 22);
            this.usersTabPage.Margin = new System.Windows.Forms.Padding(2);
            this.usersTabPage.Name = "usersTabPage";
            this.usersTabPage.Padding = new System.Windows.Forms.Padding(2);
            this.usersTabPage.Size = new System.Drawing.Size(288, 435);
            this.usersTabPage.TabIndex = 3;
            this.usersTabPage.Text = "tabPage7";
            this.usersTabPage.UseVisualStyleBackColor = true;
            // 
            // userPanel
            // 
            this.userPanel.AutoScroll = true;
            this.userPanel.BackColor = System.Drawing.Color.White;
            this.userPanel.Controls.Add(this.userSuspendDatePicker);
            this.userPanel.Controls.Add(this.userNotesTxtBox);
            this.userPanel.Controls.Add(this.label27);
            this.userPanel.Controls.Add(this.label29);
            this.userPanel.Controls.Add(this.userTerminationDatePicker);
            this.userPanel.Controls.Add(this.label30);
            this.userPanel.Controls.Add(this.userCommenceDatePicker);
            this.userPanel.Controls.Add(this.label31);
            this.userPanel.Controls.Add(this.userFirstNameTxtBox);
            this.userPanel.Controls.Add(this.label38);
            this.userPanel.Controls.Add(this.userSurnameTxtBox);
            this.userPanel.Controls.Add(this.label39);
            this.userPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userPanel.Location = new System.Drawing.Point(2, 2);
            this.userPanel.Margin = new System.Windows.Forms.Padding(2);
            this.userPanel.Name = "userPanel";
            this.userPanel.Size = new System.Drawing.Size(284, 431);
            this.userPanel.TabIndex = 2;
            // 
            // userSuspendDatePicker
            // 
            this.userSuspendDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.userSuspendDatePicker.Location = new System.Drawing.Point(122, 128);
            this.userSuspendDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.userSuspendDatePicker.Name = "userSuspendDatePicker";
            this.userSuspendDatePicker.Size = new System.Drawing.Size(146, 20);
            this.userSuspendDatePicker.TabIndex = 5;
            // 
            // userNotesTxtBox
            // 
            this.userNotesTxtBox.Location = new System.Drawing.Point(122, 159);
            this.userNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.userNotesTxtBox.Name = "userNotesTxtBox";
            this.userNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.userNotesTxtBox.TabIndex = 6;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(4, 162);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(35, 13);
            this.label27.TabIndex = 29;
            this.label27.Text = "Notes";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(4, 132);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 13);
            this.label29.TabIndex = 25;
            this.label29.Text = "Suspend Date";
            // 
            // userTerminationDatePicker
            // 
            this.userTerminationDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.userTerminationDatePicker.Location = new System.Drawing.Point(122, 100);
            this.userTerminationDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.userTerminationDatePicker.Name = "userTerminationDatePicker";
            this.userTerminationDatePicker.Size = new System.Drawing.Size(146, 20);
            this.userTerminationDatePicker.TabIndex = 4;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(4, 104);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(88, 13);
            this.label30.TabIndex = 24;
            this.label30.Text = "Termination Date";
            // 
            // userCommenceDatePicker
            // 
            this.userCommenceDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.userCommenceDatePicker.Location = new System.Drawing.Point(122, 70);
            this.userCommenceDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.userCommenceDatePicker.Name = "userCommenceDatePicker";
            this.userCommenceDatePicker.Size = new System.Drawing.Size(146, 20);
            this.userCommenceDatePicker.TabIndex = 3;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(4, 74);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(109, 13);
            this.label31.TabIndex = 16;
            this.label31.Text = "Commencement Date";
            // 
            // userFirstNameTxtBox
            // 
            this.userFirstNameTxtBox.Location = new System.Drawing.Point(122, 37);
            this.userFirstNameTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.userFirstNameTxtBox.Name = "userFirstNameTxtBox";
            this.userFirstNameTxtBox.Size = new System.Drawing.Size(146, 20);
            this.userFirstNameTxtBox.TabIndex = 2;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(4, 40);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(82, 13);
            this.label38.TabIndex = 2;
            this.label38.Text = "User First Name";
            // 
            // userSurnameTxtBox
            // 
            this.userSurnameTxtBox.Location = new System.Drawing.Point(122, 9);
            this.userSurnameTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.userSurnameTxtBox.Name = "userSurnameTxtBox";
            this.userSurnameTxtBox.Size = new System.Drawing.Size(146, 20);
            this.userSurnameTxtBox.TabIndex = 1;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(4, 11);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(74, 13);
            this.label39.TabIndex = 0;
            this.label39.Text = "User Surname";
            // 
            // locationTabPage
            // 
            this.locationTabPage.Controls.Add(this.locationPanel);
            this.locationTabPage.Location = new System.Drawing.Point(4, 22);
            this.locationTabPage.Margin = new System.Windows.Forms.Padding(2);
            this.locationTabPage.Name = "locationTabPage";
            this.locationTabPage.Padding = new System.Windows.Forms.Padding(2);
            this.locationTabPage.Size = new System.Drawing.Size(288, 435);
            this.locationTabPage.TabIndex = 4;
            this.locationTabPage.Text = "tabPage8";
            this.locationTabPage.UseVisualStyleBackColor = true;
            // 
            // locationPanel
            // 
            this.locationPanel.AutoScroll = true;
            this.locationPanel.BackColor = System.Drawing.Color.White;
            this.locationPanel.Controls.Add(this.locationNotesTxtBox);
            this.locationPanel.Controls.Add(this.label37);
            this.locationPanel.Controls.Add(this.locationEnvironmentTxtBox);
            this.locationPanel.Controls.Add(this.label40);
            this.locationPanel.Controls.Add(this.locationDescTxtBox);
            this.locationPanel.Controls.Add(this.label41);
            this.locationPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.locationPanel.Location = new System.Drawing.Point(2, 2);
            this.locationPanel.Margin = new System.Windows.Forms.Padding(2);
            this.locationPanel.Name = "locationPanel";
            this.locationPanel.Size = new System.Drawing.Size(284, 431);
            this.locationPanel.TabIndex = 1;
            // 
            // locationNotesTxtBox
            // 
            this.locationNotesTxtBox.Location = new System.Drawing.Point(122, 64);
            this.locationNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.locationNotesTxtBox.Name = "locationNotesTxtBox";
            this.locationNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.locationNotesTxtBox.TabIndex = 3;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(4, 67);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 13);
            this.label37.TabIndex = 4;
            this.label37.Text = "Notes";
            // 
            // locationEnvironmentTxtBox
            // 
            this.locationEnvironmentTxtBox.Location = new System.Drawing.Point(122, 37);
            this.locationEnvironmentTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.locationEnvironmentTxtBox.Name = "locationEnvironmentTxtBox";
            this.locationEnvironmentTxtBox.Size = new System.Drawing.Size(146, 20);
            this.locationEnvironmentTxtBox.TabIndex = 2;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(4, 40);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(66, 13);
            this.label40.TabIndex = 2;
            this.label40.Text = "Environment";
            // 
            // locationDescTxtBox
            // 
            this.locationDescTxtBox.Location = new System.Drawing.Point(122, 9);
            this.locationDescTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.locationDescTxtBox.Name = "locationDescTxtBox";
            this.locationDescTxtBox.Size = new System.Drawing.Size(146, 20);
            this.locationDescTxtBox.TabIndex = 1;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(4, 11);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(104, 13);
            this.label41.TabIndex = 0;
            this.label41.Text = "Location Description";
            // 
            // emailTabPage
            // 
            this.emailTabPage.Controls.Add(this.emailPanel);
            this.emailTabPage.Location = new System.Drawing.Point(4, 22);
            this.emailTabPage.Margin = new System.Windows.Forms.Padding(2);
            this.emailTabPage.Name = "emailTabPage";
            this.emailTabPage.Padding = new System.Windows.Forms.Padding(2);
            this.emailTabPage.Size = new System.Drawing.Size(288, 435);
            this.emailTabPage.TabIndex = 5;
            this.emailTabPage.Text = "tabPage9";
            this.emailTabPage.UseVisualStyleBackColor = true;
            // 
            // emailPanel
            // 
            this.emailPanel.AutoScroll = true;
            this.emailPanel.BackColor = System.Drawing.Color.White;
            this.emailPanel.Controls.Add(this.emailAddressNotesTxtBox);
            this.emailPanel.Controls.Add(this.label26);
            this.emailPanel.Controls.Add(this.emailAddressMailboxTyTxtBox);
            this.emailPanel.Controls.Add(this.label28);
            this.emailPanel.Controls.Add(this.emailAddressTxtBox);
            this.emailPanel.Controls.Add(this.label32);
            this.emailPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.emailPanel.Location = new System.Drawing.Point(2, 2);
            this.emailPanel.Margin = new System.Windows.Forms.Padding(2);
            this.emailPanel.Name = "emailPanel";
            this.emailPanel.Size = new System.Drawing.Size(284, 431);
            this.emailPanel.TabIndex = 2;
            // 
            // emailAddressNotesTxtBox
            // 
            this.emailAddressNotesTxtBox.Location = new System.Drawing.Point(122, 66);
            this.emailAddressNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.emailAddressNotesTxtBox.Name = "emailAddressNotesTxtBox";
            this.emailAddressNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.emailAddressNotesTxtBox.TabIndex = 3;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(4, 68);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(35, 13);
            this.label26.TabIndex = 4;
            this.label26.Text = "Notes";
            // 
            // emailAddressMailboxTyTxtBox
            // 
            this.emailAddressMailboxTyTxtBox.Location = new System.Drawing.Point(122, 37);
            this.emailAddressMailboxTyTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.emailAddressMailboxTyTxtBox.Name = "emailAddressMailboxTyTxtBox";
            this.emailAddressMailboxTyTxtBox.Size = new System.Drawing.Size(146, 20);
            this.emailAddressMailboxTyTxtBox.TabIndex = 2;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(4, 40);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(70, 13);
            this.label28.TabIndex = 2;
            this.label28.Text = "Mailbox Type";
            // 
            // emailAddressTxtBox
            // 
            this.emailAddressTxtBox.Location = new System.Drawing.Point(122, 9);
            this.emailAddressTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.emailAddressTxtBox.Name = "emailAddressTxtBox";
            this.emailAddressTxtBox.Size = new System.Drawing.Size(146, 20);
            this.emailAddressTxtBox.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(4, 11);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(73, 13);
            this.label32.TabIndex = 0;
            this.label32.Text = "Email Address";
            // 
            // supportAgreementTabPage
            // 
            this.supportAgreementTabPage.Controls.Add(this.supportAgreementPanel);
            this.supportAgreementTabPage.Location = new System.Drawing.Point(4, 22);
            this.supportAgreementTabPage.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreementTabPage.Name = "supportAgreementTabPage";
            this.supportAgreementTabPage.Padding = new System.Windows.Forms.Padding(2);
            this.supportAgreementTabPage.Size = new System.Drawing.Size(288, 435);
            this.supportAgreementTabPage.TabIndex = 6;
            this.supportAgreementTabPage.Text = "tabPage10";
            this.supportAgreementTabPage.UseVisualStyleBackColor = true;
            // 
            // supportAgreementPanel
            // 
            this.supportAgreementPanel.AutoScroll = true;
            this.supportAgreementPanel.BackColor = System.Drawing.Color.White;
            this.supportAgreementPanel.Controls.Add(this.supportAgreeInactiveRadioBtn);
            this.supportAgreementPanel.Controls.Add(this.supportAgreeActiveRadioBtn);
            this.supportAgreementPanel.Controls.Add(this.supportAgreeNotesTxtBox);
            this.supportAgreementPanel.Controls.Add(this.label33);
            this.supportAgreementPanel.Controls.Add(this.supportAgreeExpDatePicker);
            this.supportAgreementPanel.Controls.Add(this.label35);
            this.supportAgreementPanel.Controls.Add(this.supportAgreeCommenDatePicker);
            this.supportAgreementPanel.Controls.Add(this.label36);
            this.supportAgreementPanel.Controls.Add(this.label42);
            this.supportAgreementPanel.Controls.Add(this.supportAgreementDescTxtBox);
            this.supportAgreementPanel.Controls.Add(this.label43);
            this.supportAgreementPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.supportAgreementPanel.Location = new System.Drawing.Point(2, 2);
            this.supportAgreementPanel.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreementPanel.Name = "supportAgreementPanel";
            this.supportAgreementPanel.Size = new System.Drawing.Size(284, 431);
            this.supportAgreementPanel.TabIndex = 3;
            // 
            // supportAgreeInactiveRadioBtn
            // 
            this.supportAgreeInactiveRadioBtn.AutoSize = true;
            this.supportAgreeInactiveRadioBtn.Location = new System.Drawing.Point(208, 37);
            this.supportAgreeInactiveRadioBtn.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreeInactiveRadioBtn.Name = "supportAgreeInactiveRadioBtn";
            this.supportAgreeInactiveRadioBtn.Size = new System.Drawing.Size(63, 17);
            this.supportAgreeInactiveRadioBtn.TabIndex = 3;
            this.supportAgreeInactiveRadioBtn.TabStop = true;
            this.supportAgreeInactiveRadioBtn.Text = "Inactive";
            this.supportAgreeInactiveRadioBtn.UseVisualStyleBackColor = true;
            // 
            // supportAgreeActiveRadioBtn
            // 
            this.supportAgreeActiveRadioBtn.AutoSize = true;
            this.supportAgreeActiveRadioBtn.Location = new System.Drawing.Point(122, 37);
            this.supportAgreeActiveRadioBtn.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreeActiveRadioBtn.Name = "supportAgreeActiveRadioBtn";
            this.supportAgreeActiveRadioBtn.Size = new System.Drawing.Size(55, 17);
            this.supportAgreeActiveRadioBtn.TabIndex = 2;
            this.supportAgreeActiveRadioBtn.TabStop = true;
            this.supportAgreeActiveRadioBtn.Text = "Active";
            this.supportAgreeActiveRadioBtn.UseVisualStyleBackColor = true;
            // 
            // supportAgreeNotesTxtBox
            // 
            this.supportAgreeNotesTxtBox.Location = new System.Drawing.Point(122, 129);
            this.supportAgreeNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreeNotesTxtBox.Name = "supportAgreeNotesTxtBox";
            this.supportAgreeNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.supportAgreeNotesTxtBox.TabIndex = 6;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(4, 132);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(35, 13);
            this.label33.TabIndex = 29;
            this.label33.Text = "Notes";
            // 
            // supportAgreeExpDatePicker
            // 
            this.supportAgreeExpDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.supportAgreeExpDatePicker.Location = new System.Drawing.Point(122, 100);
            this.supportAgreeExpDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreeExpDatePicker.Name = "supportAgreeExpDatePicker";
            this.supportAgreeExpDatePicker.Size = new System.Drawing.Size(146, 20);
            this.supportAgreeExpDatePicker.TabIndex = 5;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(4, 104);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 13);
            this.label35.TabIndex = 24;
            this.label35.Text = "Expiry Date";
            // 
            // supportAgreeCommenDatePicker
            // 
            this.supportAgreeCommenDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.supportAgreeCommenDatePicker.Location = new System.Drawing.Point(122, 70);
            this.supportAgreeCommenDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreeCommenDatePicker.Name = "supportAgreeCommenDatePicker";
            this.supportAgreeCommenDatePicker.Size = new System.Drawing.Size(146, 20);
            this.supportAgreeCommenDatePicker.TabIndex = 4;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(4, 74);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(109, 13);
            this.label36.TabIndex = 16;
            this.label36.Text = "Commencement Date";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(4, 40);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(37, 13);
            this.label42.TabIndex = 2;
            this.label42.Text = "Status";
            // 
            // supportAgreementDescTxtBox
            // 
            this.supportAgreementDescTxtBox.Location = new System.Drawing.Point(122, 9);
            this.supportAgreementDescTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.supportAgreementDescTxtBox.Name = "supportAgreementDescTxtBox";
            this.supportAgreementDescTxtBox.Size = new System.Drawing.Size(146, 20);
            this.supportAgreementDescTxtBox.TabIndex = 1;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(4, 11);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(114, 13);
            this.label43.TabIndex = 0;
            this.label43.Text = "Agreement Description";
            // 
            // warrantyTabPage
            // 
            this.warrantyTabPage.Controls.Add(this.warrantyPanel);
            this.warrantyTabPage.Location = new System.Drawing.Point(4, 22);
            this.warrantyTabPage.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyTabPage.Name = "warrantyTabPage";
            this.warrantyTabPage.Padding = new System.Windows.Forms.Padding(2);
            this.warrantyTabPage.Size = new System.Drawing.Size(288, 435);
            this.warrantyTabPage.TabIndex = 7;
            this.warrantyTabPage.Text = "tabPage11";
            this.warrantyTabPage.UseVisualStyleBackColor = true;
            // 
            // warrantyPanel
            // 
            this.warrantyPanel.AutoScroll = true;
            this.warrantyPanel.BackColor = System.Drawing.Color.White;
            this.warrantyPanel.Controls.Add(this.warrantyInactiveRadioBtn);
            this.warrantyPanel.Controls.Add(this.warrantyActiveRadioBtn);
            this.warrantyPanel.Controls.Add(this.label53);
            this.warrantyPanel.Controls.Add(this.warrantyExpDatePicker);
            this.warrantyPanel.Controls.Add(this.warrantyStartDatePicker);
            this.warrantyPanel.Controls.Add(this.warrantyQuoteRefTxtBox);
            this.warrantyPanel.Controls.Add(this.label34);
            this.warrantyPanel.Controls.Add(this.label45);
            this.warrantyPanel.Controls.Add(this.label46);
            this.warrantyPanel.Controls.Add(this.warrantyNotesTxtBox);
            this.warrantyPanel.Controls.Add(this.label47);
            this.warrantyPanel.Controls.Add(this.warrantyTicketNumberTxtBox);
            this.warrantyPanel.Controls.Add(this.label48);
            this.warrantyPanel.Controls.Add(this.warrantyTypeTxtBox);
            this.warrantyPanel.Controls.Add(this.label52);
            this.warrantyPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.warrantyPanel.Location = new System.Drawing.Point(2, 2);
            this.warrantyPanel.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyPanel.Name = "warrantyPanel";
            this.warrantyPanel.Size = new System.Drawing.Size(284, 431);
            this.warrantyPanel.TabIndex = 1;
            // 
            // warrantyInactiveRadioBtn
            // 
            this.warrantyInactiveRadioBtn.AutoSize = true;
            this.warrantyInactiveRadioBtn.Location = new System.Drawing.Point(208, 41);
            this.warrantyInactiveRadioBtn.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyInactiveRadioBtn.Name = "warrantyInactiveRadioBtn";
            this.warrantyInactiveRadioBtn.Size = new System.Drawing.Size(63, 17);
            this.warrantyInactiveRadioBtn.TabIndex = 3;
            this.warrantyInactiveRadioBtn.TabStop = true;
            this.warrantyInactiveRadioBtn.Text = "Inactive";
            this.warrantyInactiveRadioBtn.UseVisualStyleBackColor = true;
            // 
            // warrantyActiveRadioBtn
            // 
            this.warrantyActiveRadioBtn.AutoSize = true;
            this.warrantyActiveRadioBtn.Location = new System.Drawing.Point(120, 41);
            this.warrantyActiveRadioBtn.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyActiveRadioBtn.Name = "warrantyActiveRadioBtn";
            this.warrantyActiveRadioBtn.Size = new System.Drawing.Size(55, 17);
            this.warrantyActiveRadioBtn.TabIndex = 2;
            this.warrantyActiveRadioBtn.TabStop = true;
            this.warrantyActiveRadioBtn.Text = "Active";
            this.warrantyActiveRadioBtn.UseVisualStyleBackColor = true;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(4, 43);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(37, 13);
            this.label53.TabIndex = 34;
            this.label53.Text = "Status";
            // 
            // warrantyExpDatePicker
            // 
            this.warrantyExpDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.warrantyExpDatePicker.Location = new System.Drawing.Point(122, 102);
            this.warrantyExpDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyExpDatePicker.Name = "warrantyExpDatePicker";
            this.warrantyExpDatePicker.Size = new System.Drawing.Size(146, 20);
            this.warrantyExpDatePicker.TabIndex = 5;
            // 
            // warrantyStartDatePicker
            // 
            this.warrantyStartDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.warrantyStartDatePicker.Location = new System.Drawing.Point(122, 72);
            this.warrantyStartDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyStartDatePicker.Name = "warrantyStartDatePicker";
            this.warrantyStartDatePicker.Size = new System.Drawing.Size(146, 20);
            this.warrantyStartDatePicker.TabIndex = 4;
            // 
            // warrantyQuoteRefTxtBox
            // 
            this.warrantyQuoteRefTxtBox.Location = new System.Drawing.Point(122, 132);
            this.warrantyQuoteRefTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyQuoteRefTxtBox.Name = "warrantyQuoteRefTxtBox";
            this.warrantyQuoteRefTxtBox.Size = new System.Drawing.Size(146, 20);
            this.warrantyQuoteRefTxtBox.TabIndex = 6;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(4, 134);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(56, 13);
            this.label34.TabIndex = 18;
            this.label34.Text = "Quote Ref";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(4, 106);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(61, 13);
            this.label45.TabIndex = 14;
            this.label45.Text = "Expiry Date";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(4, 76);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(55, 13);
            this.label46.TabIndex = 12;
            this.label46.Text = "Start Date";
            // 
            // warrantyNotesTxtBox
            // 
            this.warrantyNotesTxtBox.Location = new System.Drawing.Point(122, 190);
            this.warrantyNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyNotesTxtBox.Name = "warrantyNotesTxtBox";
            this.warrantyNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.warrantyNotesTxtBox.TabIndex = 8;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(2, 193);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(35, 13);
            this.label47.TabIndex = 10;
            this.label47.Text = "Notes";
            // 
            // warrantyTicketNumberTxtBox
            // 
            this.warrantyTicketNumberTxtBox.Location = new System.Drawing.Point(122, 160);
            this.warrantyTicketNumberTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyTicketNumberTxtBox.Name = "warrantyTicketNumberTxtBox";
            this.warrantyTicketNumberTxtBox.Size = new System.Drawing.Size(146, 20);
            this.warrantyTicketNumberTxtBox.TabIndex = 7;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(2, 162);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(77, 13);
            this.label48.TabIndex = 8;
            this.label48.Text = "Ticket Number";
            // 
            // warrantyTypeTxtBox
            // 
            this.warrantyTypeTxtBox.Location = new System.Drawing.Point(122, 9);
            this.warrantyTypeTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.warrantyTypeTxtBox.Name = "warrantyTypeTxtBox";
            this.warrantyTypeTxtBox.Size = new System.Drawing.Size(146, 20);
            this.warrantyTypeTxtBox.TabIndex = 1;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(4, 11);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(77, 13);
            this.label52.TabIndex = 0;
            this.label52.Text = "Warranty Type";
            // 
            // communicationLinkTabPage
            // 
            this.communicationLinkTabPage.Controls.Add(this.communicationLinkPanel);
            this.communicationLinkTabPage.Location = new System.Drawing.Point(4, 22);
            this.communicationLinkTabPage.Margin = new System.Windows.Forms.Padding(2);
            this.communicationLinkTabPage.Name = "communicationLinkTabPage";
            this.communicationLinkTabPage.Padding = new System.Windows.Forms.Padding(2);
            this.communicationLinkTabPage.Size = new System.Drawing.Size(288, 435);
            this.communicationLinkTabPage.TabIndex = 8;
            this.communicationLinkTabPage.Text = "tabPage12";
            this.communicationLinkTabPage.UseVisualStyleBackColor = true;
            // 
            // communicationLinkPanel
            // 
            this.communicationLinkPanel.AutoScroll = true;
            this.communicationLinkPanel.BackColor = System.Drawing.Color.White;
            this.communicationLinkPanel.Controls.Add(this.communiLinkConnectAgreementComboBox);
            this.communicationLinkPanel.Controls.Add(this.communiLinkTermMonthNumeric);
            this.communicationLinkPanel.Controls.Add(this.communiLinkCommenceDatePicker);
            this.communicationLinkPanel.Controls.Add(this.label49);
            this.communicationLinkPanel.Controls.Add(this.communicationLinkExpDatePicker);
            this.communicationLinkPanel.Controls.Add(this.communicationLinkNotesTxtBox);
            this.communicationLinkPanel.Controls.Add(this.label44);
            this.communicationLinkPanel.Controls.Add(this.label54);
            this.communicationLinkPanel.Controls.Add(this.label55);
            this.communicationLinkPanel.Controls.Add(this.label56);
            this.communicationLinkPanel.Controls.Add(this.communiLinkSpeedTxtBox);
            this.communicationLinkPanel.Controls.Add(this.label57);
            this.communicationLinkPanel.Controls.Add(this.communiLinkTypeTxtBox);
            this.communicationLinkPanel.Controls.Add(this.label58);
            this.communicationLinkPanel.Controls.Add(this.communicationLinkVendorTxtBox);
            this.communicationLinkPanel.Controls.Add(this.label59);
            this.communicationLinkPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.communicationLinkPanel.Location = new System.Drawing.Point(2, 2);
            this.communicationLinkPanel.Margin = new System.Windows.Forms.Padding(2);
            this.communicationLinkPanel.Name = "communicationLinkPanel";
            this.communicationLinkPanel.Size = new System.Drawing.Size(284, 431);
            this.communicationLinkPanel.TabIndex = 1;
            // 
            // communiLinkConnectAgreementComboBox
            // 
            this.communiLinkConnectAgreementComboBox.AllowDrop = true;
            this.communiLinkConnectAgreementComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.communiLinkConnectAgreementComboBox.FormattingEnabled = true;
            this.communiLinkConnectAgreementComboBox.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.communiLinkConnectAgreementComboBox.Location = new System.Drawing.Point(122, 90);
            this.communiLinkConnectAgreementComboBox.Margin = new System.Windows.Forms.Padding(2);
            this.communiLinkConnectAgreementComboBox.Name = "communiLinkConnectAgreementComboBox";
            this.communiLinkConnectAgreementComboBox.Size = new System.Drawing.Size(146, 21);
            this.communiLinkConnectAgreementComboBox.TabIndex = 4;
            // 
            // communiLinkTermMonthNumeric
            // 
            this.communiLinkTermMonthNumeric.Location = new System.Drawing.Point(122, 150);
            this.communiLinkTermMonthNumeric.Margin = new System.Windows.Forms.Padding(2);
            this.communiLinkTermMonthNumeric.Name = "communiLinkTermMonthNumeric";
            this.communiLinkTermMonthNumeric.Size = new System.Drawing.Size(145, 20);
            this.communiLinkTermMonthNumeric.TabIndex = 6;
            // 
            // communiLinkCommenceDatePicker
            // 
            this.communiLinkCommenceDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.communiLinkCommenceDatePicker.Location = new System.Drawing.Point(122, 120);
            this.communiLinkCommenceDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.communiLinkCommenceDatePicker.Name = "communiLinkCommenceDatePicker";
            this.communiLinkCommenceDatePicker.Size = new System.Drawing.Size(146, 20);
            this.communiLinkCommenceDatePicker.TabIndex = 5;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(4, 124);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(109, 13);
            this.label49.TabIndex = 21;
            this.label49.Text = "Commencement Date";
            // 
            // communicationLinkExpDatePicker
            // 
            this.communicationLinkExpDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.communicationLinkExpDatePicker.Location = new System.Drawing.Point(122, 178);
            this.communicationLinkExpDatePicker.Margin = new System.Windows.Forms.Padding(2);
            this.communicationLinkExpDatePicker.Name = "communicationLinkExpDatePicker";
            this.communicationLinkExpDatePicker.Size = new System.Drawing.Size(146, 20);
            this.communicationLinkExpDatePicker.TabIndex = 7;
            // 
            // communicationLinkNotesTxtBox
            // 
            this.communicationLinkNotesTxtBox.Location = new System.Drawing.Point(122, 207);
            this.communicationLinkNotesTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.communicationLinkNotesTxtBox.Name = "communicationLinkNotesTxtBox";
            this.communicationLinkNotesTxtBox.Size = new System.Drawing.Size(146, 20);
            this.communicationLinkNotesTxtBox.TabIndex = 8;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(4, 210);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(35, 13);
            this.label44.TabIndex = 18;
            this.label44.Text = "Notes";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(4, 182);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(61, 13);
            this.label54.TabIndex = 10;
            this.label54.Text = "Expiry Date";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(4, 152);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(75, 13);
            this.label55.TabIndex = 8;
            this.label55.Text = "Term (Months)";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(4, 93);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(119, 13);
            this.label56.TabIndex = 6;
            this.label56.Text = "Connectivity Agreement";
            // 
            // communiLinkSpeedTxtBox
            // 
            this.communiLinkSpeedTxtBox.Location = new System.Drawing.Point(122, 64);
            this.communiLinkSpeedTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.communiLinkSpeedTxtBox.Name = "communiLinkSpeedTxtBox";
            this.communiLinkSpeedTxtBox.Size = new System.Drawing.Size(146, 20);
            this.communiLinkSpeedTxtBox.TabIndex = 3;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(4, 67);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(38, 13);
            this.label57.TabIndex = 4;
            this.label57.Text = "Speed";
            // 
            // communiLinkTypeTxtBox
            // 
            this.communiLinkTypeTxtBox.Location = new System.Drawing.Point(122, 37);
            this.communiLinkTypeTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.communiLinkTypeTxtBox.Name = "communiLinkTypeTxtBox";
            this.communiLinkTypeTxtBox.Size = new System.Drawing.Size(146, 20);
            this.communiLinkTypeTxtBox.TabIndex = 2;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(4, 40);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(54, 13);
            this.label58.TabIndex = 2;
            this.label58.Text = "Link Type";
            // 
            // communicationLinkVendorTxtBox
            // 
            this.communicationLinkVendorTxtBox.Location = new System.Drawing.Point(122, 9);
            this.communicationLinkVendorTxtBox.Margin = new System.Windows.Forms.Padding(2);
            this.communicationLinkVendorTxtBox.Name = "communicationLinkVendorTxtBox";
            this.communicationLinkVendorTxtBox.Size = new System.Drawing.Size(146, 20);
            this.communicationLinkVendorTxtBox.TabIndex = 1;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(4, 11);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(116, 13);
            this.label59.TabIndex = 0;
            this.label59.Text = "Communication Vendor";
            // 
            // select_licenses
            // 
            this.select_licenses.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.select_licenses.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.select_licenses.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.select_licenses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.select_licenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.select_licenses.ForeColor = System.Drawing.Color.Black;
            this.select_licenses.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.select_licenses.Location = new System.Drawing.Point(6, 54);
            this.select_licenses.Name = "select_licenses";
            this.select_licenses.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.select_licenses.Size = new System.Drawing.Size(81, 42);
            this.select_licenses.TabIndex = 20;
            this.select_licenses.Text = "Licenses";
            this.select_licenses.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.select_licenses.UseVisualStyleBackColor = true;
            this.select_licenses.Click += new System.EventHandler(this.select_licenses_Click);
            // 
            // selectEmail
            // 
            this.selectEmail.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.selectEmail.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectEmail.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectEmail.ForeColor = System.Drawing.Color.Black;
            this.selectEmail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectEmail.Location = new System.Drawing.Point(6, 246);
            this.selectEmail.Name = "selectEmail";
            this.selectEmail.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.selectEmail.Size = new System.Drawing.Size(81, 42);
            this.selectEmail.TabIndex = 18;
            this.selectEmail.Text = "E-mail";
            this.selectEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectEmail.UseVisualStyleBackColor = true;
            this.selectEmail.Click += new System.EventHandler(this.selectEmail_Click);
            // 
            // dataGridViewMain
            // 
            this.dataGridViewMain.AllowUserToAddRows = false;
            this.dataGridViewMain.AllowUserToDeleteRows = false;
            this.dataGridViewMain.AllowUserToResizeColumns = false;
            this.dataGridViewMain.AllowUserToResizeRows = false;
            this.dataGridViewMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewMain.AutoGenerateColumns = false;
            this.dataGridViewMain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewMain.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewMain.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewMain.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal;
            this.dataGridViewMain.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewMain.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewMain.ColumnHeadersHeight = 35;
            this.dataGridViewMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.userkeyDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.commencementdateDataGridViewTextBoxColumn,
            this.terminationdateDataGridViewTextBoxColumn,
            this.suspenddateDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dataGridViewMain.DataSource = this.userBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewMain.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewMain.EnableHeadersVisualStyles = false;
            this.dataGridViewMain.GridColor = System.Drawing.Color.White;
            this.dataGridViewMain.Location = new System.Drawing.Point(93, 73);
            this.dataGridViewMain.Name = "dataGridViewMain";
            this.dataGridViewMain.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewMain.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewMain.RowHeadersVisible = false;
            this.dataGridViewMain.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.dataGridViewMain.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.dataGridViewMain.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewMain.RowTemplate.Height = 50;
            this.dataGridViewMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewMain.Size = new System.Drawing.Size(503, 366);
            this.dataGridViewMain.TabIndex = 0;
            this.dataGridViewMain.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMain_CellClick);
            // 
            // selectWarranty
            // 
            this.selectWarranty.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.selectWarranty.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectWarranty.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectWarranty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectWarranty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectWarranty.ForeColor = System.Drawing.Color.Black;
            this.selectWarranty.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectWarranty.Location = new System.Drawing.Point(6, 198);
            this.selectWarranty.Name = "selectWarranty";
            this.selectWarranty.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.selectWarranty.Size = new System.Drawing.Size(82, 42);
            this.selectWarranty.TabIndex = 17;
            this.selectWarranty.Text = "Warranty";
            this.selectWarranty.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectWarranty.UseVisualStyleBackColor = true;
            this.selectWarranty.Click += new System.EventHandler(this.selectWarranty_Click);
            // 
            // function_box
            // 
            this.function_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.function_box.Controls.Add(this.button13);
            this.function_box.Controls.Add(this.button12);
            this.function_box.Controls.Add(this.createDataButton);
            this.function_box.Controls.Add(this.modifyButton);
            this.function_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.function_box.Location = new System.Drawing.Point(93, 3);
            this.function_box.Name = "function_box";
            this.function_box.Size = new System.Drawing.Size(503, 64);
            this.function_box.TabIndex = 2;
            this.function_box.TabStop = false;
            this.function_box.Text = "functions ~";
            // 
            // button13
            // 
            this.button13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.Black;
            this.button13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.Location = new System.Drawing.Point(426, 13);
            this.button13.Name = "button13";
            this.button13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button13.Size = new System.Drawing.Size(71, 43);
            this.button13.TabIndex = 20;
            this.button13.Text = "Un-assign";
            this.button13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.Black;
            this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.Location = new System.Drawing.Point(349, 13);
            this.button12.Name = "button12";
            this.button12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button12.Size = new System.Drawing.Size(71, 43);
            this.button12.TabIndex = 19;
            this.button12.Text = "Assign";
            this.button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // createDataButton
            // 
            this.createDataButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.createDataButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.createDataButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.createDataButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.createDataButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.createDataButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createDataButton.ForeColor = System.Drawing.Color.Black;
            this.createDataButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.createDataButton.Location = new System.Drawing.Point(195, 13);
            this.createDataButton.Name = "createDataButton";
            this.createDataButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.createDataButton.Size = new System.Drawing.Size(71, 43);
            this.createDataButton.TabIndex = 16;
            this.createDataButton.Text = "Create New";
            this.createDataButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.createDataButton.UseVisualStyleBackColor = true;
            this.createDataButton.Click += new System.EventHandler(this.createDataButton_Click);
            // 
            // modifyButton
            // 
            this.modifyButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.modifyButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.modifyButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.modifyButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.modifyButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.modifyButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modifyButton.ForeColor = System.Drawing.Color.Black;
            this.modifyButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.modifyButton.Location = new System.Drawing.Point(272, 13);
            this.modifyButton.Name = "modifyButton";
            this.modifyButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.modifyButton.Size = new System.Drawing.Size(71, 43);
            this.modifyButton.TabIndex = 18;
            this.modifyButton.Text = "Save Modify";
            this.modifyButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.modifyButton.UseVisualStyleBackColor = true;
            this.modifyButton.Click += new System.EventHandler(this.modifyButton_Click);
            // 
            // selectSupportAgreements
            // 
            this.selectSupportAgreements.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.selectSupportAgreements.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectSupportAgreements.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.selectSupportAgreements.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.selectSupportAgreements.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectSupportAgreements.ForeColor = System.Drawing.Color.Black;
            this.selectSupportAgreements.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectSupportAgreements.Location = new System.Drawing.Point(6, 102);
            this.selectSupportAgreements.Name = "selectSupportAgreements";
            this.selectSupportAgreements.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.selectSupportAgreements.Size = new System.Drawing.Size(81, 42);
            this.selectSupportAgreements.TabIndex = 14;
            this.selectSupportAgreements.Text = "Support Agreements";
            this.selectSupportAgreements.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.selectSupportAgreements.UseVisualStyleBackColor = true;
            this.selectSupportAgreements.Click += new System.EventHandler(this.selectSupportAgreements_Click);
            // 
            // select_user
            // 
            this.select_user.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.select_user.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.select_user.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.select_user.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.select_user.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.select_user.ForeColor = System.Drawing.Color.Black;
            this.select_user.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.select_user.Location = new System.Drawing.Point(6, 294);
            this.select_user.Name = "select_user";
            this.select_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.select_user.Size = new System.Drawing.Size(81, 42);
            this.select_user.TabIndex = 12;
            this.select_user.Text = "Users";
            this.select_user.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.select_user.UseVisualStyleBackColor = true;
            this.select_user.Click += new System.EventHandler(this.select_user_Click);
            // 
            // select_hardware
            // 
            this.select_hardware.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.select_hardware.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.select_hardware.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(254)))), ((int)(((byte)(163)))));
            this.select_hardware.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.select_hardware.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.select_hardware.ForeColor = System.Drawing.Color.Black;
            this.select_hardware.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.select_hardware.Location = new System.Drawing.Point(6, 6);
            this.select_hardware.Name = "select_hardware";
            this.select_hardware.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.select_hardware.Size = new System.Drawing.Size(81, 42);
            this.select_hardware.TabIndex = 15;
            this.select_hardware.Text = "Hardware";
            this.select_hardware.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.select_hardware.UseVisualStyleBackColor = true;
            this.select_hardware.Click += new System.EventHandler(this.select_hardware_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(895, 442);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabPage1_MouseDown);
            // 
            // tab_control_main
            // 
            this.tab_control_main.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tab_control_main.Controls.Add(this.tabPage1);
            this.tab_control_main.Controls.Add(this.tabPage2);
            this.tab_control_main.Controls.Add(this.tabPage3);
            this.tab_control_main.Location = new System.Drawing.Point(0, 82);
            this.tab_control_main.Name = "tab_control_main";
            this.tab_control_main.Padding = new System.Drawing.Point(3, 3);
            this.tab_control_main.SelectedIndex = 0;
            this.tab_control_main.Size = new System.Drawing.Size(903, 468);
            this.tab_control_main.TabIndex = 6;
            this.tab_control_main.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabControl_MouseDown);
            // 
            // system_time_label
            // 
            this.system_time_label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.system_time_label.AutoSize = true;
            this.system_time_label.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.system_time_label.ForeColor = System.Drawing.Color.White;
            this.system_time_label.Location = new System.Drawing.Point(773, 559);
            this.system_time_label.Name = "system_time_label";
            this.system_time_label.Size = new System.Drawing.Size(73, 13);
            this.system_time_label.TabIndex = 5;
            this.system_time_label.Text = "system time";
            // 
            // skinny_horizontal_bar
            // 
            this.skinny_horizontal_bar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.skinny_horizontal_bar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.skinny_horizontal_bar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.skinny_horizontal_bar.Controls.Add(this.exit_button);
            this.skinny_horizontal_bar.Controls.Add(this.normal_max_button);
            this.skinny_horizontal_bar.Controls.Add(this.minimize_button);
            this.skinny_horizontal_bar.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.skinny_horizontal_bar.Location = new System.Drawing.Point(57, -5);
            this.skinny_horizontal_bar.Name = "skinny_horizontal_bar";
            this.skinny_horizontal_bar.Size = new System.Drawing.Size(849, 36);
            this.skinny_horizontal_bar.TabIndex = 2;
            this.skinny_horizontal_bar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.skinny_horizontal_bar_MouseDown);
            // 
            // refresh_button
            // 
            this.refresh_button.FlatAppearance.BorderSize = 0;
            this.refresh_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.refresh_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.refresh_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.refresh_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refresh_button.ForeColor = System.Drawing.Color.Gray;
            this.refresh_button.Location = new System.Drawing.Point(0, -5);
            this.refresh_button.Name = "refresh_button";
            this.refresh_button.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.refresh_button.Size = new System.Drawing.Size(58, 35);
            this.refresh_button.TabIndex = 3;
            this.refresh_button.Text = "≈";
            this.refresh_button.UseCompatibleTextRendering = true;
            this.refresh_button.UseVisualStyleBackColor = false;
            this.refresh_button.Click += new System.EventHandler(this.refresh_button_Click);
            this.refresh_button.MouseEnter += new System.EventHandler(this.refresh_button_MouseEnter);
            this.refresh_button.MouseLeave += new System.EventHandler(this.refresh_button_MouseLeave);
            // 
            // system_timer
            // 
            this.system_timer.Enabled = true;
            this.system_timer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // locationBindingSource
            // 
            this.locationBindingSource.DataMember = "Location";
            this.locationBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // snapShot_DBDataSet
            // 
            this.snapShot_DBDataSet.DataSetName = "SnapShot_DBDataSet";
            this.snapShot_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userkeyDataGridViewTextBoxColumn
            // 
            this.userkeyDataGridViewTextBoxColumn.DataPropertyName = "user_key";
            this.userkeyDataGridViewTextBoxColumn.HeaderText = "user_key";
            this.userkeyDataGridViewTextBoxColumn.Name = "userkeyDataGridViewTextBoxColumn";
            this.userkeyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "surname";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "firstname";
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            this.firstnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // commencementdateDataGridViewTextBoxColumn
            // 
            this.commencementdateDataGridViewTextBoxColumn.DataPropertyName = "commencement_date";
            this.commencementdateDataGridViewTextBoxColumn.HeaderText = "commencement_date";
            this.commencementdateDataGridViewTextBoxColumn.Name = "commencementdateDataGridViewTextBoxColumn";
            this.commencementdateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // terminationdateDataGridViewTextBoxColumn
            // 
            this.terminationdateDataGridViewTextBoxColumn.DataPropertyName = "termination_date";
            this.terminationdateDataGridViewTextBoxColumn.HeaderText = "termination_date";
            this.terminationdateDataGridViewTextBoxColumn.Name = "terminationdateDataGridViewTextBoxColumn";
            this.terminationdateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // suspenddateDataGridViewTextBoxColumn
            // 
            this.suspenddateDataGridViewTextBoxColumn.DataPropertyName = "suspend_date";
            this.suspenddateDataGridViewTextBoxColumn.HeaderText = "suspend_date";
            this.suspenddateDataGridViewTextBoxColumn.Name = "suspenddateDataGridViewTextBoxColumn";
            this.suspenddateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "notes";
            this.dataGridViewTextBoxColumn1.HeaderText = "notes";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "location_key";
            this.dataGridViewTextBoxColumn2.HeaderText = "location_key";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataMember = "User";
            this.userBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // licenseBindingSource
            // 
            this.licenseBindingSource.DataMember = "License";
            this.licenseBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // snapShot_DBDataSet1
            // 
            this.snapShot_DBDataSet1.DataSetName = "SnapShot_DBDataSet";
            this.snapShot_DBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // hardwareBindingSource
            // 
            this.hardwareBindingSource.DataMember = "Hardware";
            this.hardwareBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // clientTableAdapter1
            // 
            this.clientTableAdapter1.ClearBeforeFill = true;
            // 
            // hardwareTableAdapter
            // 
            this.hardwareTableAdapter.ClearBeforeFill = true;
            // 
            // licenseTableAdapter
            // 
            this.licenseTableAdapter.ClearBeforeFill = true;
            // 
            // emailAddressBindingSource
            // 
            this.emailAddressBindingSource.DataMember = "Email_Address";
            this.emailAddressBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // email_AddressTableAdapter
            // 
            this.email_AddressTableAdapter.ClearBeforeFill = true;
            // 
            // supportAgreementBindingSource
            // 
            this.supportAgreementBindingSource.DataMember = "Support_Agreement";
            this.supportAgreementBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // support_AgreementTableAdapter
            // 
            this.support_AgreementTableAdapter.ClearBeforeFill = true;
            // 
            // warrantyBindingSource
            // 
            this.warrantyBindingSource.DataMember = "Warranty";
            this.warrantyBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // warrantyTableAdapter
            // 
            this.warrantyTableAdapter.ClearBeforeFill = true;
            // 
            // communicationLinkBindingSource
            // 
            this.communicationLinkBindingSource.DataMember = "Communication_Link";
            this.communicationLinkBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // communication_LinkTableAdapter
            // 
            this.communication_LinkTableAdapter.ClearBeforeFill = true;
            // 
            // locationTableAdapter
            // 
            this.locationTableAdapter.ClearBeforeFill = true;
            // 
            // userTableAdapter
            // 
            this.userTableAdapter.ClearBeforeFill = true;
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(903, 581);
            this.ControlBox = false;
            this.Controls.Add(this.system_time_label);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.refresh_button);
            this.Controls.Add(this.snap_panel);
            this.Controls.Add(this.client_panel);
            this.Controls.Add(this.skinny_horizontal_bar);
            this.Controls.Add(this.home_panel);
            this.Controls.Add(this.tab_control_main);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainScreen";
            this.Load += new System.EventHandler(this.MainScreen_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainScreen_MouseDown);
            this.client_panel.ResumeLayout(false);
            this.snap_panel.ResumeLayout(false);
            this.home_panel.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tab_function_control.ResumeLayout(false);
            this.hardwareTabPage.ResumeLayout(false);
            this.hardwarePanel.ResumeLayout(false);
            this.hardwarePanel.PerformLayout();
            this.licensesTabPage.ResumeLayout(false);
            this.licensesPanel.ResumeLayout(false);
            this.licensesPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licenseTicketNumberNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensePackOrCoresNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensesAllocatedNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensePurchasedNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseQuantityNumeric)).EndInit();
            this.usersTabPage.ResumeLayout(false);
            this.userPanel.ResumeLayout(false);
            this.userPanel.PerformLayout();
            this.locationTabPage.ResumeLayout(false);
            this.locationPanel.ResumeLayout(false);
            this.locationPanel.PerformLayout();
            this.emailTabPage.ResumeLayout(false);
            this.emailPanel.ResumeLayout(false);
            this.emailPanel.PerformLayout();
            this.supportAgreementTabPage.ResumeLayout(false);
            this.supportAgreementPanel.ResumeLayout(false);
            this.supportAgreementPanel.PerformLayout();
            this.warrantyTabPage.ResumeLayout(false);
            this.warrantyPanel.ResumeLayout(false);
            this.warrantyPanel.PerformLayout();
            this.communicationLinkTabPage.ResumeLayout(false);
            this.communicationLinkPanel.ResumeLayout(false);
            this.communicationLinkPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.communiLinkTermMonthNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMain)).EndInit();
            this.function_box.ResumeLayout(false);
            this.tab_control_main.ResumeLayout(false);
            this.skinny_horizontal_bar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.locationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailAddressBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supportAgreementBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.warrantyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.communicationLinkBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_home;
        private System.Windows.Forms.Button button_client;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button normal_max_button;
        private SnapShot_DBDataSet snapShot_DBDataSet;
        private System.Windows.Forms.Button minimize_button;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private SnapShot_DBDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.Button button_location;
        private SnapShot_DBDataSetTableAdapters.ClientTableAdapter clientTableAdapter1;
        private System.Windows.Forms.Panel home_panel;
        private System.Windows.Forms.Panel client_panel;
        private System.Windows.Forms.Panel snap_panel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox function_box;
        private System.Windows.Forms.DataGridView dataGridViewMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tab_control_main;
        private System.Windows.Forms.Button client_button_label;
        private System.Windows.Forms.Label system_time_label;
        private System.Windows.Forms.FlowLayoutPanel skinny_horizontal_bar;
        private System.Windows.Forms.Button refresh_button;
        private System.Windows.Forms.Button client_tab_select_button;
        private System.Windows.Forms.Timer system_timer;
        private System.Windows.Forms.TabControl tab_function_control;
        private System.Windows.Forms.TabPage hardwareTabPage;
        private System.Windows.Forms.Button select_hardware;
        private System.Windows.Forms.Button selectSupportAgreements;
        private System.Windows.Forms.Button selectWarranty;
        private System.Windows.Forms.Button selectEmail;
        private System.Windows.Forms.Button selectCommunicationLinks;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button modifyButton;
        private System.Windows.Forms.Button createDataButton;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.BindingSource hardwareBindingSource;
        private SnapShot_DBDataSetTableAdapters.HardwareTableAdapter hardwareTableAdapter;
        private System.Windows.Forms.BindingSource licenseBindingSource;
        private SnapShot_DBDataSetTableAdapters.LicenseTableAdapter licenseTableAdapter;
        private System.Windows.Forms.Button select_licenses;
        private System.Windows.Forms.BindingSource locationBindingSource;
        private System.Windows.Forms.BindingSource emailAddressBindingSource;
        private SnapShot_DBDataSetTableAdapters.Email_AddressTableAdapter email_AddressTableAdapter;
        private System.Windows.Forms.BindingSource supportAgreementBindingSource;
        private SnapShot_DBDataSetTableAdapters.Support_AgreementTableAdapter support_AgreementTableAdapter;
        private System.Windows.Forms.BindingSource warrantyBindingSource;
        private SnapShot_DBDataSetTableAdapters.WarrantyTableAdapter warrantyTableAdapter;
        private System.Windows.Forms.BindingSource communicationLinkBindingSource;
        private SnapShot_DBDataSetTableAdapters.Communication_LinkTableAdapter communication_LinkTableAdapter;
        private System.Windows.Forms.Panel hardwarePanel;
        private System.Windows.Forms.TextBox hwNotesTxtBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox hwClientAssestTxtBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox hwSerialNumTxtBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox hwModelTxtBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox hwDeviceNameTxtBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox hwVendorTxtBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox hwCategoryCodeTxtBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker hwDateWrittenOffPicker;
        private System.Windows.Forms.DateTimePicker hwWarrantyExpPicker;
        private System.Windows.Forms.DateTimePicker hwDatePurchasedPicker;
        private System.Windows.Forms.TabPage licensesTabPage;
        private System.Windows.Forms.Panel licensesPanel;
        private System.Windows.Forms.DateTimePicker licenseDatePurchasedPicker;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox licenseSubscriptionTyTxtBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox licenseProductDescTxtBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox licenseCategoryTxtBox;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox licenseCodeOffsetTxtBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown licenseQuantityNumeric;
        private System.Windows.Forms.NumericUpDown licensePurchasedNumeric;
        private System.Windows.Forms.NumericUpDown licensesAllocatedNumeric;
        private System.Windows.Forms.DateTimePicker licenseExpDatePicker;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox licenseQuoteRefTxtBox;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox licenseNotesTxtBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox licenseVendorAllocatedKeyTxtBox;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage usersTabPage;
        private System.Windows.Forms.Panel userPanel;
        private System.Windows.Forms.TextBox userNotesTxtBox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DateTimePicker userTerminationDatePicker;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.DateTimePicker userCommenceDatePicker;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox userFirstNameTxtBox;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox userSurnameTxtBox;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DateTimePicker userSuspendDatePicker;
        private System.Windows.Forms.TabPage locationTabPage;
        private System.Windows.Forms.Panel locationPanel;
        private System.Windows.Forms.TextBox locationNotesTxtBox;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox locationEnvironmentTxtBox;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox locationDescTxtBox;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TabPage emailTabPage;
        private System.Windows.Forms.Panel emailPanel;
        private System.Windows.Forms.TextBox emailAddressNotesTxtBox;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox emailAddressMailboxTyTxtBox;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox emailAddressTxtBox;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TabPage supportAgreementTabPage;
        private System.Windows.Forms.Panel supportAgreementPanel;
        private System.Windows.Forms.TextBox supportAgreeNotesTxtBox;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker supportAgreeExpDatePicker;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DateTimePicker supportAgreeCommenDatePicker;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox supportAgreementDescTxtBox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.RadioButton supportAgreeActiveRadioBtn;
        private System.Windows.Forms.RadioButton supportAgreeInactiveRadioBtn;
        private System.Windows.Forms.TabPage warrantyTabPage;
        private System.Windows.Forms.Panel warrantyPanel;
        private System.Windows.Forms.DateTimePicker warrantyExpDatePicker;
        private System.Windows.Forms.DateTimePicker warrantyStartDatePicker;
        private System.Windows.Forms.TextBox warrantyQuoteRefTxtBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox warrantyNotesTxtBox;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox warrantyTicketNumberTxtBox;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox warrantyTypeTxtBox;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.RadioButton warrantyInactiveRadioBtn;
        private System.Windows.Forms.RadioButton warrantyActiveRadioBtn;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TabPage communicationLinkTabPage;
        private System.Windows.Forms.Panel communicationLinkPanel;
        private System.Windows.Forms.DateTimePicker communicationLinkExpDatePicker;
        private System.Windows.Forms.TextBox communicationLinkNotesTxtBox;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox communiLinkSpeedTxtBox;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox communiLinkTypeTxtBox;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox communicationLinkVendorTxtBox;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.DateTimePicker communiLinkCommenceDatePicker;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.NumericUpDown licenseTicketNumberNumeric;
        private System.Windows.Forms.NumericUpDown licensePackOrCoresNumeric;
        private System.Windows.Forms.ComboBox communiLinkConnectAgreementComboBox;
        private System.Windows.Forms.NumericUpDown communiLinkTermMonthNumeric;
        private System.Windows.Forms.Button select_user;
        private System.Windows.Forms.ComboBox locationComboBox;
        private SnapShot_DBDataSetTableAdapters.LocationTableAdapter locationTableAdapter;
        private SnapShot_DBDataSet snapShot_DBDataSet1;
        private SnapShot_DBDataSetTableAdapters.UserTableAdapter userTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationkeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn notesDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource userBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn userkeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commencementdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn terminationdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suspenddateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}

