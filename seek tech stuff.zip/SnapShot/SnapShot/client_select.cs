﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnapShot
{
    public partial class client_select : Form
    {
        private const int HT_CAPTION = 0x2;
        private const int WM_NCHITTEST = 0x84;
        private const int WM_NCCALCSIZE = 0x83;
        private const int WM_NCLBUTTONDOWN = 0xA1;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public client_select()
        {
            // init
            InitializeComponent();
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.StartPosition = FormStartPosition.CenterParent;

            dataGridViewClientSelection.Columns[0].Visible = false;
        }

        private void client_select_Load(object sender, EventArgs e)
        {
            this.clientTableAdapter.Fill(this.snapShot_DBDataSet.Client);
        }

        private void client_select_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void dataGridViewClientSelection_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (!(e.RowIndex < 0))
            {
                MainScreen main = (MainScreen)Owner;
                main.set_client_label(dataGridViewClientSelection[1, e.RowIndex].Value.ToString() + " ▼");
                main.set_client_tab_view((int)dataGridViewClientSelection[0, e.RowIndex].Value);
                this.Dispose();
            }
        }
    }
}
