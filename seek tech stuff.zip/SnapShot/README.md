# SnapShot2
Database Management Application
