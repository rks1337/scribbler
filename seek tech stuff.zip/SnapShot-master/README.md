# SnapShot
Database Management Application
