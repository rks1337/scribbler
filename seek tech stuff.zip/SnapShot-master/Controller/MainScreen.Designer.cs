﻿using System;

namespace SnapShot
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainScreen));
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataSelectionTabs = new System.Windows.Forms.TabControl();
            this.clientsTab = new System.Windows.Forms.TabPage();
            this.clientViewPanel = new System.Windows.Forms.Panel();
            this.clientDataGridView = new System.Windows.Forms.DataGridView();
            this.clientkeyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.businessnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.streetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suburbDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.billingnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.notesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.snapShot_DBDataSet = new SnapShot.SnapShot_DBDataSet();
            this.addclientGroupBox = new System.Windows.Forms.GroupBox();
            this.addClientPanel = new System.Windows.Forms.Panel();
            this.clientAddressLine3TextBox = new System.Windows.Forms.TextBox();
            this.saveClientButton = new System.Windows.Forms.Button();
            this.clientBussinessNameLabel = new System.Windows.Forms.Label();
            this.clientNotesTextBox = new System.Windows.Forms.TextBox();
            this.clientBusinessNameTextBox = new System.Windows.Forms.TextBox();
            this.clientNotesLabel = new System.Windows.Forms.Label();
            this.clientAddressLineLabel = new System.Windows.Forms.Label();
            this.clientInactiveStatusRadioButton = new System.Windows.Forms.RadioButton();
            this.clientAddressLine1TextBox = new System.Windows.Forms.TextBox();
            this.clientActiveStatusRadioButton = new System.Windows.Forms.RadioButton();
            this.clientAddressLine2Label = new System.Windows.Forms.Label();
            this.clientStatusLabel = new System.Windows.Forms.Label();
            this.clientAddressLine2TextBox = new System.Windows.Forms.TextBox();
            this.clientBillingNameTextBox = new System.Windows.Forms.TextBox();
            this.clientAddressLine3Label = new System.Windows.Forms.Label();
            this.clientBillingNameLabel = new System.Windows.Forms.Label();
            this.clientAddressLine4Label = new System.Windows.Forms.Label();
            this.clientAddressLine4TextBox = new System.Windows.Forms.TextBox();
            this.clientButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addClientButton = new System.Windows.Forms.Button();
            this.viewClientsButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.fillButton = new System.Windows.Forms.Button();
            this.hardwareTab = new System.Windows.Forms.TabPage();
            this.hardwareViewPanel = new System.Windows.Forms.Panel();
            this.hardwareDataGridView = new System.Windows.Forms.DataGridView();
            this.hardwarekeyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categorycodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.devicenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientassetnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datepurchasedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.warrantyexpiryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datewrittenoffDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.notesDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hardwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.addHardwareGroupBox = new System.Windows.Forms.GroupBox();
            this.addHardwarePanel = new System.Windows.Forms.Panel();
            this.hardwareClientAssetNumberLabel = new System.Windows.Forms.Label();
            this.hardwareDateWrittenOffTextBox = new System.Windows.Forms.TextBox();
            this.hardwareDatePurchasedLabel = new System.Windows.Forms.Label();
            this.hardwareDateWrittenOffLabel = new System.Windows.Forms.Label();
            this.hardwareWarrantyExpiryLabel = new System.Windows.Forms.Label();
            this.hardwareDeviceNameTextBox = new System.Windows.Forms.TextBox();
            this.hardwareNotesLabel = new System.Windows.Forms.Label();
            this.hardwareVendorTextBox = new System.Windows.Forms.TextBox();
            this.hardwareDatePurchasedTextBox = new System.Windows.Forms.TextBox();
            this.hardwareCategoryCodeTextBox = new System.Windows.Forms.TextBox();
            this.hardwareWarrantyExpiryTextBox = new System.Windows.Forms.TextBox();
            this.hardwareDeviceNameLabel = new System.Windows.Forms.Label();
            this.hardwareNotesTextBox = new System.Windows.Forms.TextBox();
            this.hardwareVendorLabel = new System.Windows.Forms.Label();
            this.saveHardwareButton = new System.Windows.Forms.Button();
            this.hardwareCategoryCodeLabel = new System.Windows.Forms.Label();
            this.hardwareModelLabel = new System.Windows.Forms.Label();
            this.hardwareClientAssetNumberTextBox = new System.Windows.Forms.TextBox();
            this.hardwareSerialNumberLabel = new System.Windows.Forms.Label();
            this.hardwareSerialNumberTextBox = new System.Windows.Forms.TextBox();
            this.hardwareModelTextBox = new System.Windows.Forms.TextBox();
            this.hardwareButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addHardwareButton = new System.Windows.Forms.Button();
            this.viewHardwareButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.licenseTab = new System.Windows.Forms.TabPage();
            this.licenseViewPanel = new System.Windows.Forms.Panel();
            this.licensesDataGridView = new System.Windows.Forms.DataGridView();
            this.addLicenseGroupBox = new System.Windows.Forms.GroupBox();
            this.addLicensePanel = new System.Windows.Forms.Panel();
            this.licensesAllocatedNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.licensesPurchasedNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.licenseQuantityNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.licensePackCoreNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.licenseCodeOffsetTextBox = new System.Windows.Forms.TextBox();
            this.licenseTicketNumberTextBox = new System.Windows.Forms.TextBox();
            this.licenseTicketNumberLabel = new System.Windows.Forms.Label();
            this.licensesPurchasedLabel = new System.Windows.Forms.Label();
            this.saveLicenseButton = new System.Windows.Forms.Button();
            this.licenseSubscriptionTypeLabel = new System.Windows.Forms.Label();
            this.licenseNotesTextBox = new System.Windows.Forms.TextBox();
            this.licenseQuoteRefTextBox = new System.Windows.Forms.TextBox();
            this.licenseExpiryDateTextBox = new System.Windows.Forms.TextBox();
            this.licenseDatePurchasedTextBox = new System.Windows.Forms.TextBox();
            this.licensePackCoreLabel = new System.Windows.Forms.Label();
            this.licenseNotesLabel = new System.Windows.Forms.Label();
            this.licenseVendorAllocatedKeyTextBox = new System.Windows.Forms.TextBox();
            this.licenseExpiryDateLabel = new System.Windows.Forms.Label();
            this.licenseQuantityLabel = new System.Windows.Forms.Label();
            this.licenseDatePurchasedLabel = new System.Windows.Forms.Label();
            this.licenseSubscriptionTypeTextBox = new System.Windows.Forms.TextBox();
            this.licenseQuoteRefLabel = new System.Windows.Forms.Label();
            this.licenseVendorAllocatedKeyLabel = new System.Windows.Forms.Label();
            this.licensesAllocatedLabel = new System.Windows.Forms.Label();
            this.licenseCodeOffsetLabel = new System.Windows.Forms.Label();
            this.licenseCategoryLabel = new System.Windows.Forms.Label();
            this.licenseProductDescriptionLabel = new System.Windows.Forms.Label();
            this.licenseCategoryTextBox = new System.Windows.Forms.TextBox();
            this.licenseProductDescriptionTextBox = new System.Windows.Forms.TextBox();
            this.licensesButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addLicenseButton = new System.Windows.Forms.Button();
            this.viewLicensesbutton = new System.Windows.Forms.Button();
            this.usersTab = new System.Windows.Forms.TabPage();
            this.userViewPanel = new System.Windows.Forms.Panel();
            this.usersDataGridView = new System.Windows.Forms.DataGridView();
            this.addUsersGroupBox = new System.Windows.Forms.GroupBox();
            this.addUserPanel = new System.Windows.Forms.Panel();
            this.userSuspendedDateTextBox = new System.Windows.Forms.TextBox();
            this.userSuspendedDateLabel = new System.Windows.Forms.Label();
            this.saveUserButton = new System.Windows.Forms.Button();
            this.userNotesTextBox = new System.Windows.Forms.TextBox();
            this.userTerminationDateTextBox = new System.Windows.Forms.TextBox();
            this.userCommencementDateTextBox = new System.Windows.Forms.TextBox();
            this.user1stNameTextBox = new System.Windows.Forms.TextBox();
            this.userNotesLabel = new System.Windows.Forms.Label();
            this.userSurnameTextBox = new System.Windows.Forms.TextBox();
            this.userCommencementDateLabel = new System.Windows.Forms.Label();
            this.user1stNameLabel = new System.Windows.Forms.Label();
            this.userTerminationDateLabel = new System.Windows.Forms.Label();
            this.userSurnameLabel = new System.Windows.Forms.Label();
            this.userButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addUserButton = new System.Windows.Forms.Button();
            this.viewUsersButton = new System.Windows.Forms.Button();
            this.emailAddressesTab = new System.Windows.Forms.TabPage();
            this.emailAddressViewPanel = new System.Windows.Forms.Panel();
            this.emailAddressesGridView = new System.Windows.Forms.DataGridView();
            this.addEmailAddressGroupBox = new System.Windows.Forms.GroupBox();
            this.addEmailAddressPanel = new System.Windows.Forms.Panel();
            this.saveEmailAddressButton = new System.Windows.Forms.Button();
            this.emailAddressNotesTextBox = new System.Windows.Forms.TextBox();
            this.emailAddressMailboxTypeTextBox = new System.Windows.Forms.TextBox();
            this.emailAddressTextBox = new System.Windows.Forms.TextBox();
            this.emailAddressNotesLabel = new System.Windows.Forms.Label();
            this.emailAddressMailboxTypeLabel = new System.Windows.Forms.Label();
            this.emailAddressLabel = new System.Windows.Forms.Label();
            this.emailAddressesButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addEmailAddressesButton = new System.Windows.Forms.Button();
            this.viewEmailAddressessButton = new System.Windows.Forms.Button();
            this.warrantiesTab = new System.Windows.Forms.TabPage();
            this.warrantyViewPanel = new System.Windows.Forms.Panel();
            this.warrantiesGridView = new System.Windows.Forms.DataGridView();
            this.addWarrantyGroupBox = new System.Windows.Forms.GroupBox();
            this.addWarrantyPanel = new System.Windows.Forms.Panel();
            this.warrantyTypeLabel = new System.Windows.Forms.Label();
            this.warrantyStatusInactiveRadioButton = new System.Windows.Forms.RadioButton();
            this.warrantyStartDateLabel = new System.Windows.Forms.Label();
            this.warrantyStatusActiveRadioButton = new System.Windows.Forms.RadioButton();
            this.warrantyExpiryDateLabel = new System.Windows.Forms.Label();
            this.warrantyStatusLabel = new System.Windows.Forms.Label();
            this.warrantyNotesLabel = new System.Windows.Forms.Label();
            this.warrantyHardwareItemKeyTextBox = new System.Windows.Forms.TextBox();
            this.warrantyStartDateTextBox = new System.Windows.Forms.TextBox();
            this.warrantyTypeTextBox = new System.Windows.Forms.TextBox();
            this.warrantyExpiryDateTextBox = new System.Windows.Forms.TextBox();
            this.warrantyHardwareItemKeyLabel = new System.Windows.Forms.Label();
            this.warrantyNotesTextBox = new System.Windows.Forms.TextBox();
            this.saveWarrantyButton = new System.Windows.Forms.Button();
            this.warrantyTicketNumberTextBox = new System.Windows.Forms.TextBox();
            this.warrantyQuoteRefLabel = new System.Windows.Forms.Label();
            this.warrantyQuoteRefTextBox = new System.Windows.Forms.TextBox();
            this.warrantyTicketNumberLabel = new System.Windows.Forms.Label();
            this.warrantiesButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addWarrantiesButton = new System.Windows.Forms.Button();
            this.viewWarrantiesButton = new System.Windows.Forms.Button();
            this.communicationLinksTab = new System.Windows.Forms.TabPage();
            this.communicationLinkViewPanel = new System.Windows.Forms.Panel();
            this.communicationLinksGridView = new System.Windows.Forms.DataGridView();
            this.addCommunicationsLinkGroupBox = new System.Windows.Forms.GroupBox();
            this.addCommunicationLinkPanel = new System.Windows.Forms.Panel();
            this.communicationLinksVendorTextBox = new System.Windows.Forms.TextBox();
            this.communicationLinksConnectivityAgreementInactiveRadioButton = new System.Windows.Forms.RadioButton();
            this.communicationLinkCommencementDateLabel = new System.Windows.Forms.Label();
            this.communicationLinksConnectivityAgreementActiveRadioButton = new System.Windows.Forms.RadioButton();
            this.communicationLinkTermLabel = new System.Windows.Forms.Label();
            this.communicationLinkTermNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.communicationLinkNotesLabel = new System.Windows.Forms.Label();
            this.communicationLinkExpiryDateTextBox = new System.Windows.Forms.TextBox();
            this.communicationLinkCommencementDateTextBox = new System.Windows.Forms.TextBox();
            this.communicationLinkExpiryDateLabel = new System.Windows.Forms.Label();
            this.communicationLinkNotesTextBox = new System.Windows.Forms.TextBox();
            this.communicationLinksTypeTextBox = new System.Windows.Forms.TextBox();
            this.saveCommunicationLinkButton = new System.Windows.Forms.Button();
            this.communicationLinksSpeedLabel = new System.Windows.Forms.Label();
            this.communicationLinksTypeLabel = new System.Windows.Forms.Label();
            this.communicationLinksHardwareItemKeyLabel = new System.Windows.Forms.Label();
            this.communicationLinksVendorLabel = new System.Windows.Forms.Label();
            this.communicationLinksConnectivityAgreementLabel = new System.Windows.Forms.Label();
            this.communicationLinksHardwareItemKeyTextBox = new System.Windows.Forms.TextBox();
            this.communicationLinksSpeedTextBox = new System.Windows.Forms.TextBox();
            this.communicationLinksButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addCommunicationLinksButton = new System.Windows.Forms.Button();
            this.viewCommunicationLinksButton = new System.Windows.Forms.Button();
            this.supportAgreementsTab = new System.Windows.Forms.TabPage();
            this.supportAgreementViewPanel = new System.Windows.Forms.Panel();
            this.supportAgreementsGridView = new System.Windows.Forms.DataGridView();
            this.addSupportAgreementGroupBox = new System.Windows.Forms.GroupBox();
            this.addSupportAgreementPanel = new System.Windows.Forms.Panel();
            this.supportAgreementDescriptionLabel = new System.Windows.Forms.Label();
            this.supportAgreementDescriptionTextBox = new System.Windows.Forms.TextBox();
            this.supportAgreementStatusLabel = new System.Windows.Forms.Label();
            this.supportAgreementCommencedDateLabel = new System.Windows.Forms.Label();
            this.saveSupportAgreementButton = new System.Windows.Forms.Button();
            this.supportAgreementExpiryDateLabel = new System.Windows.Forms.Label();
            this.supportAgreementNotesTextBox = new System.Windows.Forms.TextBox();
            this.supportAgreementLabel = new System.Windows.Forms.Label();
            this.supportAgreementExpiryDateTextBox = new System.Windows.Forms.TextBox();
            this.supportAgreementActiveRadioButton = new System.Windows.Forms.RadioButton();
            this.supportAgreementCommencementDateTextBox = new System.Windows.Forms.TextBox();
            this.supportAgreementInactiveRadioButton = new System.Windows.Forms.RadioButton();
            this.supportAgreementsButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addSupportAgreementsButton = new System.Windows.Forms.Button();
            this.viewSupportAgreementsButton = new System.Windows.Forms.Button();
            this.locationTab = new System.Windows.Forms.TabPage();
            this.locationViewPanel = new System.Windows.Forms.Panel();
            this.locationsDataGridView = new System.Windows.Forms.DataGridView();
            this.addLocationGroupBox = new System.Windows.Forms.GroupBox();
            this.addLocationPanel = new System.Windows.Forms.Panel();
            this.locationDescriptionLabel = new System.Windows.Forms.Label();
            this.saveLocationButton = new System.Windows.Forms.Button();
            this.locationEnviromentLabel = new System.Windows.Forms.Label();
            this.locationNotesTextBox = new System.Windows.Forms.TextBox();
            this.locationNotesLabel = new System.Windows.Forms.Label();
            this.locationEnviromentTextBox = new System.Windows.Forms.TextBox();
            this.locationDescriptionTextBox = new System.Windows.Forms.TextBox();
            this.locationsButtonflowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addLocationButton = new System.Windows.Forms.Button();
            this.viewLocationsButton = new System.Windows.Forms.Button();
            this.snapshotsTab = new System.Windows.Forms.TabPage();
            this.snapshotViewPanel = new System.Windows.Forms.Panel();
            this.snapshotsDataGridView = new System.Windows.Forms.DataGridView();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateHistoric = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Notes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addSnapshotGroupBox = new System.Windows.Forms.GroupBox();
            this.addSnapshotPanel = new System.Windows.Forms.Panel();
            this.snapshotStatusLabel = new System.Windows.Forms.Label();
            this.snapshotSaveButton = new System.Windows.Forms.Button();
            this.snapshotDateCreatedLabel = new System.Windows.Forms.Label();
            this.snapshotNotesTextBox = new System.Windows.Forms.TextBox();
            this.snapshotDateHistoricLabel = new System.Windows.Forms.Label();
            this.snapshotDateHistoricTextBox = new System.Windows.Forms.TextBox();
            this.snapshotNotesLabel = new System.Windows.Forms.Label();
            this.snapshotDateCreatedTextBox = new System.Windows.Forms.TextBox();
            this.snapshotActiveRadioButton = new System.Windows.Forms.RadioButton();
            this.snapshotInactiveRadioButton = new System.Windows.Forms.RadioButton();
            this.snapshotsButtonFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.addSnapshotsButton = new System.Windows.Forms.Button();
            this.snapshotsViewButton = new System.Windows.Forms.Button();
            this.tabImageList = new System.Windows.Forms.ImageList(this.components);
            this.selectedClientNameBox = new System.Windows.Forms.TextBox();
            this.selectedClientLabel = new System.Windows.Forms.Label();
            this.selectedFlowPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.clientTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.ClientTableAdapter();
            this.hardwareTableAdapter = new SnapShot.SnapShot_DBDataSetTableAdapters.HardwareTableAdapter();
            this.menuStrip.SuspendLayout();
            this.dataSelectionTabs.SuspendLayout();
            this.clientsTab.SuspendLayout();
            this.clientViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).BeginInit();
            this.addclientGroupBox.SuspendLayout();
            this.addClientPanel.SuspendLayout();
            this.clientButtonFlowLayoutPanel.SuspendLayout();
            this.hardwareTab.SuspendLayout();
            this.hardwareViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareBindingSource)).BeginInit();
            this.addHardwareGroupBox.SuspendLayout();
            this.addHardwarePanel.SuspendLayout();
            this.hardwareButtonFlowLayoutPanel.SuspendLayout();
            this.licenseTab.SuspendLayout();
            this.licenseViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licensesDataGridView)).BeginInit();
            this.addLicenseGroupBox.SuspendLayout();
            this.addLicensePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licensesAllocatedNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensesPurchasedNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseQuantityNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensePackCoreNumericUpDown)).BeginInit();
            this.licensesButtonFlowLayoutPanel.SuspendLayout();
            this.usersTab.SuspendLayout();
            this.userViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.usersDataGridView)).BeginInit();
            this.addUsersGroupBox.SuspendLayout();
            this.addUserPanel.SuspendLayout();
            this.userButtonFlowLayoutPanel.SuspendLayout();
            this.emailAddressesTab.SuspendLayout();
            this.emailAddressViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emailAddressesGridView)).BeginInit();
            this.addEmailAddressGroupBox.SuspendLayout();
            this.addEmailAddressPanel.SuspendLayout();
            this.emailAddressesButtonFlowLayoutPanel.SuspendLayout();
            this.warrantiesTab.SuspendLayout();
            this.warrantyViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.warrantiesGridView)).BeginInit();
            this.addWarrantyGroupBox.SuspendLayout();
            this.addWarrantyPanel.SuspendLayout();
            this.warrantiesButtonFlowLayoutPanel.SuspendLayout();
            this.communicationLinksTab.SuspendLayout();
            this.communicationLinkViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.communicationLinksGridView)).BeginInit();
            this.addCommunicationsLinkGroupBox.SuspendLayout();
            this.addCommunicationLinkPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.communicationLinkTermNumericUpDown)).BeginInit();
            this.communicationLinksButtonFlowLayoutPanel.SuspendLayout();
            this.supportAgreementsTab.SuspendLayout();
            this.supportAgreementViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.supportAgreementsGridView)).BeginInit();
            this.addSupportAgreementGroupBox.SuspendLayout();
            this.addSupportAgreementPanel.SuspendLayout();
            this.supportAgreementsButtonFlowLayoutPanel.SuspendLayout();
            this.locationTab.SuspendLayout();
            this.locationViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.locationsDataGridView)).BeginInit();
            this.addLocationGroupBox.SuspendLayout();
            this.addLocationPanel.SuspendLayout();
            this.locationsButtonflowLayoutPanel.SuspendLayout();
            this.snapshotsTab.SuspendLayout();
            this.snapshotViewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.snapshotsDataGridView)).BeginInit();
            this.addSnapshotGroupBox.SuspendLayout();
            this.addSnapshotPanel.SuspendLayout();
            this.snapshotsButtonFlowLayoutPanel.SuspendLayout();
            this.selectedFlowPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem,
            this.openToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(41, 23);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.viewToolStripMenuItem.Text = "New";
            this.viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newClientToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(44, 23);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // newClientToolStripMenuItem
            // 
            this.newClientToolStripMenuItem.Name = "newClientToolStripMenuItem";
            this.newClientToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.newClientToolStripMenuItem.Text = "Cut";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.copyToolStripMenuItem.Text = "Copy";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.pasteToolStripMenuItem.Text = "Paste";
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.deleteToolStripMenuItem.Text = "Delete";
            // 
            // viewToolStripMenuItem1
            // 
            this.viewToolStripMenuItem1.Name = "viewToolStripMenuItem1";
            this.viewToolStripMenuItem1.Size = new System.Drawing.Size(50, 23);
            this.viewToolStripMenuItem1.Text = "View";
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.Color.White;
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem1,
            this.toolsToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1264, 27);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(53, 23);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(70, 23);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // dataSelectionTabs
            // 
            this.dataSelectionTabs.Controls.Add(this.clientsTab);
            this.dataSelectionTabs.Controls.Add(this.hardwareTab);
            this.dataSelectionTabs.Controls.Add(this.licenseTab);
            this.dataSelectionTabs.Controls.Add(this.usersTab);
            this.dataSelectionTabs.Controls.Add(this.emailAddressesTab);
            this.dataSelectionTabs.Controls.Add(this.warrantiesTab);
            this.dataSelectionTabs.Controls.Add(this.communicationLinksTab);
            this.dataSelectionTabs.Controls.Add(this.supportAgreementsTab);
            this.dataSelectionTabs.Controls.Add(this.locationTab);
            this.dataSelectionTabs.Controls.Add(this.snapshotsTab);
            this.dataSelectionTabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataSelectionTabs.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataSelectionTabs.ImageList = this.tabImageList;
            this.dataSelectionTabs.Location = new System.Drawing.Point(0, 27);
            this.dataSelectionTabs.Margin = new System.Windows.Forms.Padding(4);
            this.dataSelectionTabs.Name = "dataSelectionTabs";
            this.dataSelectionTabs.SelectedIndex = 0;
            this.dataSelectionTabs.ShowToolTips = true;
            this.dataSelectionTabs.Size = new System.Drawing.Size(1264, 655);
            this.dataSelectionTabs.TabIndex = 2;
            // 
            // clientsTab
            // 
            this.clientsTab.AutoScroll = true;
            this.clientsTab.Controls.Add(this.clientViewPanel);
            this.clientsTab.Controls.Add(this.addclientGroupBox);
            this.clientsTab.Controls.Add(this.clientButtonFlowLayoutPanel);
            this.clientsTab.ImageIndex = 0;
            this.clientsTab.Location = new System.Drawing.Point(4, 57);
            this.clientsTab.Margin = new System.Windows.Forms.Padding(4);
            this.clientsTab.Name = "clientsTab";
            this.clientsTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.clientsTab.Size = new System.Drawing.Size(1256, 594);
            this.clientsTab.TabIndex = 0;
            this.clientsTab.ToolTipText = "Tab for accessing all data manipulation of a client entry";
            this.clientsTab.UseVisualStyleBackColor = true;
            // 
            // clientViewPanel
            // 
            this.clientViewPanel.Controls.Add(this.clientDataGridView);
            this.clientViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clientViewPanel.Location = new System.Drawing.Point(4, 4);
            this.clientViewPanel.Name = "clientViewPanel";
            this.clientViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.clientViewPanel.TabIndex = 13;
            // 
            // clientDataGridView
            // 
            this.clientDataGridView.AllowUserToOrderColumns = true;
            this.clientDataGridView.AutoGenerateColumns = false;
            this.clientDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.clientDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.clientDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.clientDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clientDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.clientDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clientkeyDataGridViewTextBoxColumn,
            this.businessnameDataGridViewTextBoxColumn,
            this.streetDataGridViewTextBoxColumn,
            this.suburbDataGridViewTextBoxColumn,
            this.stateDataGridViewTextBoxColumn,
            this.postcodeDataGridViewTextBoxColumn,
            this.billingnameDataGridViewTextBoxColumn,
            this.statusDataGridViewCheckBoxColumn,
            this.notesDataGridViewTextBoxColumn});
            this.clientDataGridView.DataSource = this.clientBindingSource;
            this.clientDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clientDataGridView.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.clientDataGridView.Location = new System.Drawing.Point(0, 0);
            this.clientDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.clientDataGridView.MultiSelect = false;
            this.clientDataGridView.Name = "clientDataGridView";
            this.clientDataGridView.Size = new System.Drawing.Size(1248, 501);
            this.clientDataGridView.TabIndex = 3;
            this.clientDataGridView.SelectionChanged += new System.EventHandler(this.ClientDataGridView_SelectionChanged);
            this.clientDataGridView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.clientDataGridView_KeyDown);
            // 
            // clientkeyDataGridViewTextBoxColumn
            // 
            this.clientkeyDataGridViewTextBoxColumn.DataPropertyName = "client_key";
            this.clientkeyDataGridViewTextBoxColumn.HeaderText = "client_key";
            this.clientkeyDataGridViewTextBoxColumn.Name = "clientkeyDataGridViewTextBoxColumn";
            this.clientkeyDataGridViewTextBoxColumn.Width = 96;
            // 
            // businessnameDataGridViewTextBoxColumn
            // 
            this.businessnameDataGridViewTextBoxColumn.DataPropertyName = "business_name";
            this.businessnameDataGridViewTextBoxColumn.HeaderText = "business_name";
            this.businessnameDataGridViewTextBoxColumn.Name = "businessnameDataGridViewTextBoxColumn";
            this.businessnameDataGridViewTextBoxColumn.Width = 132;
            // 
            // streetDataGridViewTextBoxColumn
            // 
            this.streetDataGridViewTextBoxColumn.DataPropertyName = "street";
            this.streetDataGridViewTextBoxColumn.HeaderText = "street";
            this.streetDataGridViewTextBoxColumn.Name = "streetDataGridViewTextBoxColumn";
            this.streetDataGridViewTextBoxColumn.Width = 69;
            // 
            // suburbDataGridViewTextBoxColumn
            // 
            this.suburbDataGridViewTextBoxColumn.DataPropertyName = "suburb";
            this.suburbDataGridViewTextBoxColumn.HeaderText = "suburb";
            this.suburbDataGridViewTextBoxColumn.Name = "suburbDataGridViewTextBoxColumn";
            this.suburbDataGridViewTextBoxColumn.Width = 77;
            // 
            // stateDataGridViewTextBoxColumn
            // 
            this.stateDataGridViewTextBoxColumn.DataPropertyName = "state";
            this.stateDataGridViewTextBoxColumn.HeaderText = "state";
            this.stateDataGridViewTextBoxColumn.Name = "stateDataGridViewTextBoxColumn";
            this.stateDataGridViewTextBoxColumn.Width = 64;
            // 
            // postcodeDataGridViewTextBoxColumn
            // 
            this.postcodeDataGridViewTextBoxColumn.DataPropertyName = "postcode";
            this.postcodeDataGridViewTextBoxColumn.HeaderText = "postcode";
            this.postcodeDataGridViewTextBoxColumn.Name = "postcodeDataGridViewTextBoxColumn";
            this.postcodeDataGridViewTextBoxColumn.Width = 91;
            // 
            // billingnameDataGridViewTextBoxColumn
            // 
            this.billingnameDataGridViewTextBoxColumn.DataPropertyName = "billing_name";
            this.billingnameDataGridViewTextBoxColumn.HeaderText = "billing_name";
            this.billingnameDataGridViewTextBoxColumn.Name = "billingnameDataGridViewTextBoxColumn";
            this.billingnameDataGridViewTextBoxColumn.Width = 112;
            // 
            // statusDataGridViewCheckBoxColumn
            // 
            this.statusDataGridViewCheckBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewCheckBoxColumn.HeaderText = "status";
            this.statusDataGridViewCheckBoxColumn.Name = "statusDataGridViewCheckBoxColumn";
            this.statusDataGridViewCheckBoxColumn.Width = 52;
            // 
            // notesDataGridViewTextBoxColumn
            // 
            this.notesDataGridViewTextBoxColumn.DataPropertyName = "notes";
            this.notesDataGridViewTextBoxColumn.HeaderText = "notes";
            this.notesDataGridViewTextBoxColumn.Name = "notesDataGridViewTextBoxColumn";
            this.notesDataGridViewTextBoxColumn.Width = 68;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // snapShot_DBDataSet
            // 
            this.snapShot_DBDataSet.DataSetName = "SnapShot_DBDataSet";
            this.snapShot_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // addclientGroupBox
            // 
            this.addclientGroupBox.AutoSize = true;
            this.addclientGroupBox.Controls.Add(this.addClientPanel);
            this.addclientGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addclientGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addclientGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addclientGroupBox.Name = "addclientGroupBox";
            this.addclientGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addclientGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addclientGroupBox.TabIndex = 12;
            this.addclientGroupBox.TabStop = false;
            this.addclientGroupBox.Text = "Add Client";
            this.addclientGroupBox.Visible = false;
            // 
            // addClientPanel
            // 
            this.addClientPanel.AutoScroll = true;
            this.addClientPanel.AutoSize = true;
            this.addClientPanel.Controls.Add(this.clientAddressLine3TextBox);
            this.addClientPanel.Controls.Add(this.saveClientButton);
            this.addClientPanel.Controls.Add(this.clientBussinessNameLabel);
            this.addClientPanel.Controls.Add(this.clientNotesTextBox);
            this.addClientPanel.Controls.Add(this.clientBusinessNameTextBox);
            this.addClientPanel.Controls.Add(this.clientNotesLabel);
            this.addClientPanel.Controls.Add(this.clientAddressLineLabel);
            this.addClientPanel.Controls.Add(this.clientInactiveStatusRadioButton);
            this.addClientPanel.Controls.Add(this.clientAddressLine1TextBox);
            this.addClientPanel.Controls.Add(this.clientActiveStatusRadioButton);
            this.addClientPanel.Controls.Add(this.clientAddressLine2Label);
            this.addClientPanel.Controls.Add(this.clientStatusLabel);
            this.addClientPanel.Controls.Add(this.clientAddressLine2TextBox);
            this.addClientPanel.Controls.Add(this.clientBillingNameTextBox);
            this.addClientPanel.Controls.Add(this.clientAddressLine3Label);
            this.addClientPanel.Controls.Add(this.clientBillingNameLabel);
            this.addClientPanel.Controls.Add(this.clientAddressLine4Label);
            this.addClientPanel.Controls.Add(this.clientAddressLine4TextBox);
            this.addClientPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addClientPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addClientPanel.Location = new System.Drawing.Point(4, 20);
            this.addClientPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addClientPanel.Name = "addClientPanel";
            this.addClientPanel.Size = new System.Drawing.Size(1240, 477);
            this.addClientPanel.TabIndex = 36;
            // 
            // clientAddressLine3TextBox
            // 
            this.clientAddressLine3TextBox.Location = new System.Drawing.Point(216, 155);
            this.clientAddressLine3TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientAddressLine3TextBox.MaxLength = 30;
            this.clientAddressLine3TextBox.Name = "clientAddressLine3TextBox";
            this.clientAddressLine3TextBox.Size = new System.Drawing.Size(243, 23);
            this.clientAddressLine3TextBox.TabIndex = 25;
            // 
            // saveClientButton
            // 
            this.saveClientButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveClientButton.Location = new System.Drawing.Point(215, 409);
            this.saveClientButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveClientButton.Name = "saveClientButton";
            this.saveClientButton.Size = new System.Drawing.Size(75, 32);
            this.saveClientButton.TabIndex = 35;
            this.saveClientButton.Text = "Save";
            this.saveClientButton.UseVisualStyleBackColor = false;
            this.saveClientButton.Click += new System.EventHandler(this.saveClientButton_Click);
            // 
            // clientBussinessNameLabel
            // 
            this.clientBussinessNameLabel.AutoSize = true;
            this.clientBussinessNameLabel.Location = new System.Drawing.Point(21, 17);
            this.clientBussinessNameLabel.Name = "clientBussinessNameLabel";
            this.clientBussinessNameLabel.Size = new System.Drawing.Size(106, 17);
            this.clientBussinessNameLabel.TabIndex = 18;
            this.clientBussinessNameLabel.Text = "Business Name";
            // 
            // clientNotesTextBox
            // 
            this.clientNotesTextBox.Location = new System.Drawing.Point(215, 364);
            this.clientNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientNotesTextBox.MaxLength = 50;
            this.clientNotesTextBox.Name = "clientNotesTextBox";
            this.clientNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.clientNotesTextBox.TabIndex = 34;
            // 
            // clientBusinessNameTextBox
            // 
            this.clientBusinessNameTextBox.Location = new System.Drawing.Point(216, 11);
            this.clientBusinessNameTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientBusinessNameTextBox.MaxLength = 30;
            this.clientBusinessNameTextBox.Name = "clientBusinessNameTextBox";
            this.clientBusinessNameTextBox.Size = new System.Drawing.Size(243, 23);
            this.clientBusinessNameTextBox.TabIndex = 19;
            // 
            // clientNotesLabel
            // 
            this.clientNotesLabel.AutoSize = true;
            this.clientNotesLabel.Location = new System.Drawing.Point(20, 372);
            this.clientNotesLabel.Name = "clientNotesLabel";
            this.clientNotesLabel.Size = new System.Drawing.Size(45, 17);
            this.clientNotesLabel.TabIndex = 33;
            this.clientNotesLabel.Text = "Notes";
            // 
            // clientAddressLineLabel
            // 
            this.clientAddressLineLabel.AutoSize = true;
            this.clientAddressLineLabel.Location = new System.Drawing.Point(21, 66);
            this.clientAddressLineLabel.Name = "clientAddressLineLabel";
            this.clientAddressLineLabel.Size = new System.Drawing.Size(103, 17);
            this.clientAddressLineLabel.TabIndex = 20;
            this.clientAddressLineLabel.Text = "Address Line 1";
            // 
            // clientInactiveStatusRadioButton
            // 
            this.clientInactiveStatusRadioButton.AutoSize = true;
            this.clientInactiveStatusRadioButton.Location = new System.Drawing.Point(320, 319);
            this.clientInactiveStatusRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientInactiveStatusRadioButton.Name = "clientInactiveStatusRadioButton";
            this.clientInactiveStatusRadioButton.Size = new System.Drawing.Size(74, 21);
            this.clientInactiveStatusRadioButton.TabIndex = 32;
            this.clientInactiveStatusRadioButton.Text = "Inactive";
            this.clientInactiveStatusRadioButton.UseVisualStyleBackColor = true;
            // 
            // clientAddressLine1TextBox
            // 
            this.clientAddressLine1TextBox.Location = new System.Drawing.Point(216, 59);
            this.clientAddressLine1TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientAddressLine1TextBox.MaxLength = 30;
            this.clientAddressLine1TextBox.Name = "clientAddressLine1TextBox";
            this.clientAddressLine1TextBox.Size = new System.Drawing.Size(243, 23);
            this.clientAddressLine1TextBox.TabIndex = 21;
            // 
            // clientActiveStatusRadioButton
            // 
            this.clientActiveStatusRadioButton.AutoSize = true;
            this.clientActiveStatusRadioButton.Checked = true;
            this.clientActiveStatusRadioButton.Location = new System.Drawing.Point(215, 319);
            this.clientActiveStatusRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientActiveStatusRadioButton.Name = "clientActiveStatusRadioButton";
            this.clientActiveStatusRadioButton.Size = new System.Drawing.Size(64, 21);
            this.clientActiveStatusRadioButton.TabIndex = 31;
            this.clientActiveStatusRadioButton.TabStop = true;
            this.clientActiveStatusRadioButton.Text = "Active";
            this.clientActiveStatusRadioButton.UseVisualStyleBackColor = true;
            // 
            // clientAddressLine2Label
            // 
            this.clientAddressLine2Label.AutoSize = true;
            this.clientAddressLine2Label.Location = new System.Drawing.Point(21, 117);
            this.clientAddressLine2Label.Name = "clientAddressLine2Label";
            this.clientAddressLine2Label.Size = new System.Drawing.Size(103, 17);
            this.clientAddressLine2Label.TabIndex = 22;
            this.clientAddressLine2Label.Text = "Address Line 2";
            // 
            // clientStatusLabel
            // 
            this.clientStatusLabel.AutoSize = true;
            this.clientStatusLabel.Location = new System.Drawing.Point(21, 324);
            this.clientStatusLabel.Name = "clientStatusLabel";
            this.clientStatusLabel.Size = new System.Drawing.Size(48, 17);
            this.clientStatusLabel.TabIndex = 30;
            this.clientStatusLabel.Text = "Status";
            // 
            // clientAddressLine2TextBox
            // 
            this.clientAddressLine2TextBox.Location = new System.Drawing.Point(216, 110);
            this.clientAddressLine2TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientAddressLine2TextBox.MaxLength = 30;
            this.clientAddressLine2TextBox.Name = "clientAddressLine2TextBox";
            this.clientAddressLine2TextBox.Size = new System.Drawing.Size(243, 23);
            this.clientAddressLine2TextBox.TabIndex = 23;
            // 
            // clientBillingNameTextBox
            // 
            this.clientBillingNameTextBox.Location = new System.Drawing.Point(216, 266);
            this.clientBillingNameTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientBillingNameTextBox.MaxLength = 30;
            this.clientBillingNameTextBox.Name = "clientBillingNameTextBox";
            this.clientBillingNameTextBox.Size = new System.Drawing.Size(243, 23);
            this.clientBillingNameTextBox.TabIndex = 29;
            // 
            // clientAddressLine3Label
            // 
            this.clientAddressLine3Label.AutoSize = true;
            this.clientAddressLine3Label.Location = new System.Drawing.Point(21, 162);
            this.clientAddressLine3Label.Name = "clientAddressLine3Label";
            this.clientAddressLine3Label.Size = new System.Drawing.Size(103, 17);
            this.clientAddressLine3Label.TabIndex = 24;
            this.clientAddressLine3Label.Text = "Address Line 3";
            // 
            // clientBillingNameLabel
            // 
            this.clientBillingNameLabel.AutoSize = true;
            this.clientBillingNameLabel.Location = new System.Drawing.Point(21, 273);
            this.clientBillingNameLabel.Name = "clientBillingNameLabel";
            this.clientBillingNameLabel.Size = new System.Drawing.Size(86, 17);
            this.clientBillingNameLabel.TabIndex = 28;
            this.clientBillingNameLabel.Text = "Billing Name";
            // 
            // clientAddressLine4Label
            // 
            this.clientAddressLine4Label.AutoSize = true;
            this.clientAddressLine4Label.Location = new System.Drawing.Point(21, 215);
            this.clientAddressLine4Label.Name = "clientAddressLine4Label";
            this.clientAddressLine4Label.Size = new System.Drawing.Size(103, 17);
            this.clientAddressLine4Label.TabIndex = 26;
            this.clientAddressLine4Label.Text = "Address Line 4";
            // 
            // clientAddressLine4TextBox
            // 
            this.clientAddressLine4TextBox.Location = new System.Drawing.Point(216, 208);
            this.clientAddressLine4TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clientAddressLine4TextBox.MaxLength = 30;
            this.clientAddressLine4TextBox.Name = "clientAddressLine4TextBox";
            this.clientAddressLine4TextBox.Size = new System.Drawing.Size(243, 23);
            this.clientAddressLine4TextBox.TabIndex = 27;
            // 
            // clientButtonFlowLayoutPanel
            // 
            this.clientButtonFlowLayoutPanel.AutoSize = true;
            this.clientButtonFlowLayoutPanel.Controls.Add(this.addClientButton);
            this.clientButtonFlowLayoutPanel.Controls.Add(this.viewClientsButton);
            this.clientButtonFlowLayoutPanel.Controls.Add(this.saveButton);
            this.clientButtonFlowLayoutPanel.Controls.Add(this.fillButton);
            this.clientButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.clientButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.clientButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.clientButtonFlowLayoutPanel.Name = "clientButtonFlowLayoutPanel";
            this.clientButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.clientButtonFlowLayoutPanel.TabIndex = 2;
            // 
            // addClientButton
            // 
            this.addClientButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addClientButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addClientButton.Location = new System.Drawing.Point(4, 4);
            this.addClientButton.Margin = new System.Windows.Forms.Padding(4);
            this.addClientButton.Name = "addClientButton";
            this.addClientButton.Size = new System.Drawing.Size(133, 49);
            this.addClientButton.TabIndex = 1;
            this.addClientButton.Text = "Add";
            this.addClientButton.UseVisualStyleBackColor = false;
            this.addClientButton.Click += new System.EventHandler(this.addClient_Click);
            // 
            // viewClientsButton
            // 
            this.viewClientsButton.BackColor = System.Drawing.Color.Cyan;
            this.viewClientsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewClientsButton.Location = new System.Drawing.Point(145, 4);
            this.viewClientsButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewClientsButton.Name = "viewClientsButton";
            this.viewClientsButton.Size = new System.Drawing.Size(133, 49);
            this.viewClientsButton.TabIndex = 3;
            this.viewClientsButton.Text = "View";
            this.viewClientsButton.UseVisualStyleBackColor = false;
            this.viewClientsButton.Click += new System.EventHandler(this.viewClientsButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.Color.Cyan;
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(286, 4);
            this.saveButton.Margin = new System.Windows.Forms.Padding(4);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(133, 49);
            this.saveButton.TabIndex = 4;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // fillButton
            // 
            this.fillButton.BackColor = System.Drawing.Color.Cyan;
            this.fillButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillButton.Location = new System.Drawing.Point(427, 4);
            this.fillButton.Margin = new System.Windows.Forms.Padding(4);
            this.fillButton.Name = "fillButton";
            this.fillButton.Size = new System.Drawing.Size(133, 49);
            this.fillButton.TabIndex = 5;
            this.fillButton.Text = "Fill";
            this.fillButton.UseVisualStyleBackColor = false;
            this.fillButton.Click += new System.EventHandler(this.fillButton_Click);
            // 
            // hardwareTab
            // 
            this.hardwareTab.AutoScroll = true;
            this.hardwareTab.BackColor = System.Drawing.Color.Transparent;
            this.hardwareTab.Controls.Add(this.hardwareViewPanel);
            this.hardwareTab.Controls.Add(this.addHardwareGroupBox);
            this.hardwareTab.Controls.Add(this.hardwareButtonFlowLayoutPanel);
            this.hardwareTab.ImageIndex = 1;
            this.hardwareTab.Location = new System.Drawing.Point(4, 57);
            this.hardwareTab.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareTab.Name = "hardwareTab";
            this.hardwareTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.hardwareTab.Size = new System.Drawing.Size(1256, 594);
            this.hardwareTab.TabIndex = 1;
            this.hardwareTab.ToolTipText = "Tab for accessing all data manipulation of a hardware entry";
            // 
            // hardwareViewPanel
            // 
            this.hardwareViewPanel.AutoSize = true;
            this.hardwareViewPanel.Controls.Add(this.hardwareDataGridView);
            this.hardwareViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hardwareViewPanel.Location = new System.Drawing.Point(4, 4);
            this.hardwareViewPanel.Name = "hardwareViewPanel";
            this.hardwareViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.hardwareViewPanel.TabIndex = 6;
            // 
            // hardwareDataGridView
            // 
            this.hardwareDataGridView.AllowUserToOrderColumns = true;
            this.hardwareDataGridView.AutoGenerateColumns = false;
            this.hardwareDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.hardwareDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.hardwareDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.hardwareDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hardwareDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.hardwarekeyDataGridViewTextBoxColumn,
            this.categorycodeDataGridViewTextBoxColumn,
            this.vendorDataGridViewTextBoxColumn,
            this.devicenameDataGridViewTextBoxColumn,
            this.modelDataGridViewTextBoxColumn,
            this.serialnumberDataGridViewTextBoxColumn,
            this.clientassetnumberDataGridViewTextBoxColumn,
            this.datepurchasedDataGridViewTextBoxColumn,
            this.warrantyexpiryDataGridViewTextBoxColumn,
            this.datewrittenoffDataGridViewTextBoxColumn,
            this.notesDataGridViewTextBoxColumn1});
            this.hardwareDataGridView.DataSource = this.hardwareBindingSource;
            this.hardwareDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hardwareDataGridView.Location = new System.Drawing.Point(0, 0);
            this.hardwareDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareDataGridView.MultiSelect = false;
            this.hardwareDataGridView.Name = "hardwareDataGridView";
            this.hardwareDataGridView.Size = new System.Drawing.Size(1248, 501);
            this.hardwareDataGridView.TabIndex = 3;
            this.hardwareDataGridView.SelectionChanged += new System.EventHandler(this.HardwareDataGridView_SelectionChanged);
            // 
            // hardwarekeyDataGridViewTextBoxColumn
            // 
            this.hardwarekeyDataGridViewTextBoxColumn.DataPropertyName = "hardware_key";
            this.hardwarekeyDataGridViewTextBoxColumn.HeaderText = "hardware_key";
            this.hardwarekeyDataGridViewTextBoxColumn.Name = "hardwarekeyDataGridViewTextBoxColumn";
            this.hardwarekeyDataGridViewTextBoxColumn.ReadOnly = true;
            this.hardwarekeyDataGridViewTextBoxColumn.Width = 122;
            // 
            // categorycodeDataGridViewTextBoxColumn
            // 
            this.categorycodeDataGridViewTextBoxColumn.DataPropertyName = "category_code";
            this.categorycodeDataGridViewTextBoxColumn.HeaderText = "category_code";
            this.categorycodeDataGridViewTextBoxColumn.Name = "categorycodeDataGridViewTextBoxColumn";
            this.categorycodeDataGridViewTextBoxColumn.Width = 127;
            // 
            // vendorDataGridViewTextBoxColumn
            // 
            this.vendorDataGridViewTextBoxColumn.DataPropertyName = "vendor";
            this.vendorDataGridViewTextBoxColumn.HeaderText = "vendor";
            this.vendorDataGridViewTextBoxColumn.Name = "vendorDataGridViewTextBoxColumn";
            this.vendorDataGridViewTextBoxColumn.Width = 77;
            // 
            // devicenameDataGridViewTextBoxColumn
            // 
            this.devicenameDataGridViewTextBoxColumn.DataPropertyName = "device_name";
            this.devicenameDataGridViewTextBoxColumn.HeaderText = "device_name";
            this.devicenameDataGridViewTextBoxColumn.Name = "devicenameDataGridViewTextBoxColumn";
            this.devicenameDataGridViewTextBoxColumn.Width = 117;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "model";
            this.modelDataGridViewTextBoxColumn.HeaderText = "model";
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.Width = 71;
            // 
            // serialnumberDataGridViewTextBoxColumn
            // 
            this.serialnumberDataGridViewTextBoxColumn.DataPropertyName = "serial_number";
            this.serialnumberDataGridViewTextBoxColumn.HeaderText = "serial_number";
            this.serialnumberDataGridViewTextBoxColumn.Name = "serialnumberDataGridViewTextBoxColumn";
            this.serialnumberDataGridViewTextBoxColumn.Width = 123;
            // 
            // clientassetnumberDataGridViewTextBoxColumn
            // 
            this.clientassetnumberDataGridViewTextBoxColumn.DataPropertyName = "client_asset_number";
            this.clientassetnumberDataGridViewTextBoxColumn.HeaderText = "client_asset_number";
            this.clientassetnumberDataGridViewTextBoxColumn.Name = "clientassetnumberDataGridViewTextBoxColumn";
            this.clientassetnumberDataGridViewTextBoxColumn.Width = 164;
            // 
            // datepurchasedDataGridViewTextBoxColumn
            // 
            this.datepurchasedDataGridViewTextBoxColumn.DataPropertyName = "date_purchased";
            this.datepurchasedDataGridViewTextBoxColumn.HeaderText = "date_purchased";
            this.datepurchasedDataGridViewTextBoxColumn.Name = "datepurchasedDataGridViewTextBoxColumn";
            this.datepurchasedDataGridViewTextBoxColumn.Width = 136;
            // 
            // warrantyexpiryDataGridViewTextBoxColumn
            // 
            this.warrantyexpiryDataGridViewTextBoxColumn.DataPropertyName = "warranty_expiry";
            this.warrantyexpiryDataGridViewTextBoxColumn.HeaderText = "warranty_expiry";
            this.warrantyexpiryDataGridViewTextBoxColumn.Name = "warrantyexpiryDataGridViewTextBoxColumn";
            this.warrantyexpiryDataGridViewTextBoxColumn.Width = 132;
            // 
            // datewrittenoffDataGridViewTextBoxColumn
            // 
            this.datewrittenoffDataGridViewTextBoxColumn.DataPropertyName = "date_written_off";
            this.datewrittenoffDataGridViewTextBoxColumn.HeaderText = "date_written_off";
            this.datewrittenoffDataGridViewTextBoxColumn.Name = "datewrittenoffDataGridViewTextBoxColumn";
            this.datewrittenoffDataGridViewTextBoxColumn.Width = 134;
            // 
            // notesDataGridViewTextBoxColumn1
            // 
            this.notesDataGridViewTextBoxColumn1.DataPropertyName = "notes";
            this.notesDataGridViewTextBoxColumn1.HeaderText = "notes";
            this.notesDataGridViewTextBoxColumn1.Name = "notesDataGridViewTextBoxColumn1";
            this.notesDataGridViewTextBoxColumn1.Width = 68;
            // 
            // hardwareBindingSource
            // 
            this.hardwareBindingSource.DataMember = "Hardware";
            this.hardwareBindingSource.DataSource = this.snapShot_DBDataSet;
            // 
            // addHardwareGroupBox
            // 
            this.addHardwareGroupBox.AutoSize = true;
            this.addHardwareGroupBox.BackColor = System.Drawing.Color.White;
            this.addHardwareGroupBox.Controls.Add(this.addHardwarePanel);
            this.addHardwareGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addHardwareGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addHardwareGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addHardwareGroupBox.Name = "addHardwareGroupBox";
            this.addHardwareGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addHardwareGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addHardwareGroupBox.TabIndex = 5;
            this.addHardwareGroupBox.TabStop = false;
            this.addHardwareGroupBox.Text = "Add Hardware";
            this.addHardwareGroupBox.Visible = false;
            // 
            // addHardwarePanel
            // 
            this.addHardwarePanel.AutoScroll = true;
            this.addHardwarePanel.AutoSize = true;
            this.addHardwarePanel.Controls.Add(this.hardwareClientAssetNumberLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareDateWrittenOffTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareDatePurchasedLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareDateWrittenOffLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareWarrantyExpiryLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareDeviceNameTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareNotesLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareVendorTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareDatePurchasedTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareCategoryCodeTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareWarrantyExpiryTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareDeviceNameLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareNotesTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareVendorLabel);
            this.addHardwarePanel.Controls.Add(this.saveHardwareButton);
            this.addHardwarePanel.Controls.Add(this.hardwareCategoryCodeLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareModelLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareClientAssetNumberTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareSerialNumberLabel);
            this.addHardwarePanel.Controls.Add(this.hardwareSerialNumberTextBox);
            this.addHardwarePanel.Controls.Add(this.hardwareModelTextBox);
            this.addHardwarePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addHardwarePanel.Location = new System.Drawing.Point(4, 20);
            this.addHardwarePanel.Margin = new System.Windows.Forms.Padding(4);
            this.addHardwarePanel.Name = "addHardwarePanel";
            this.addHardwarePanel.Size = new System.Drawing.Size(1240, 477);
            this.addHardwarePanel.TabIndex = 80;
            // 
            // hardwareClientAssetNumberLabel
            // 
            this.hardwareClientAssetNumberLabel.AutoSize = true;
            this.hardwareClientAssetNumberLabel.Location = new System.Drawing.Point(24, 198);
            this.hardwareClientAssetNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareClientAssetNumberLabel.Name = "hardwareClientAssetNumberLabel";
            this.hardwareClientAssetNumberLabel.Size = new System.Drawing.Size(140, 17);
            this.hardwareClientAssetNumberLabel.TabIndex = 68;
            this.hardwareClientAssetNumberLabel.Text = "Client Asset Number:";
            // 
            // hardwareDateWrittenOffTextBox
            // 
            this.hardwareDateWrittenOffTextBox.Location = new System.Drawing.Point(196, 309);
            this.hardwareDateWrittenOffTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareDateWrittenOffTextBox.MaxLength = 8;
            this.hardwareDateWrittenOffTextBox.Name = "hardwareDateWrittenOffTextBox";
            this.hardwareDateWrittenOffTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareDateWrittenOffTextBox.TabIndex = 79;
            // 
            // hardwareDatePurchasedLabel
            // 
            this.hardwareDatePurchasedLabel.AutoSize = true;
            this.hardwareDatePurchasedLabel.Location = new System.Drawing.Point(24, 235);
            this.hardwareDatePurchasedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareDatePurchasedLabel.Name = "hardwareDatePurchasedLabel";
            this.hardwareDatePurchasedLabel.Size = new System.Drawing.Size(114, 17);
            this.hardwareDatePurchasedLabel.TabIndex = 59;
            this.hardwareDatePurchasedLabel.Text = "Date Purchased:";
            // 
            // hardwareDateWrittenOffLabel
            // 
            this.hardwareDateWrittenOffLabel.AutoSize = true;
            this.hardwareDateWrittenOffLabel.Location = new System.Drawing.Point(24, 309);
            this.hardwareDateWrittenOffLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareDateWrittenOffLabel.Name = "hardwareDateWrittenOffLabel";
            this.hardwareDateWrittenOffLabel.Size = new System.Drawing.Size(115, 17);
            this.hardwareDateWrittenOffLabel.TabIndex = 78;
            this.hardwareDateWrittenOffLabel.Text = "Date Written-Off:";
            // 
            // hardwareWarrantyExpiryLabel
            // 
            this.hardwareWarrantyExpiryLabel.AutoSize = true;
            this.hardwareWarrantyExpiryLabel.Location = new System.Drawing.Point(24, 272);
            this.hardwareWarrantyExpiryLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareWarrantyExpiryLabel.Name = "hardwareWarrantyExpiryLabel";
            this.hardwareWarrantyExpiryLabel.Size = new System.Drawing.Size(112, 17);
            this.hardwareWarrantyExpiryLabel.TabIndex = 60;
            this.hardwareWarrantyExpiryLabel.Text = "Warranty Expiry:";
            // 
            // hardwareDeviceNameTextBox
            // 
            this.hardwareDeviceNameTextBox.Location = new System.Drawing.Point(196, 87);
            this.hardwareDeviceNameTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareDeviceNameTextBox.MaxLength = 50;
            this.hardwareDeviceNameTextBox.Name = "hardwareDeviceNameTextBox";
            this.hardwareDeviceNameTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareDeviceNameTextBox.TabIndex = 77;
            // 
            // hardwareNotesLabel
            // 
            this.hardwareNotesLabel.AutoSize = true;
            this.hardwareNotesLabel.Location = new System.Drawing.Point(24, 346);
            this.hardwareNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareNotesLabel.Name = "hardwareNotesLabel";
            this.hardwareNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.hardwareNotesLabel.TabIndex = 61;
            this.hardwareNotesLabel.Text = "Notes:";
            // 
            // hardwareVendorTextBox
            // 
            this.hardwareVendorTextBox.Location = new System.Drawing.Point(196, 50);
            this.hardwareVendorTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareVendorTextBox.MaxLength = 8;
            this.hardwareVendorTextBox.Name = "hardwareVendorTextBox";
            this.hardwareVendorTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareVendorTextBox.TabIndex = 76;
            // 
            // hardwareDatePurchasedTextBox
            // 
            this.hardwareDatePurchasedTextBox.Location = new System.Drawing.Point(196, 235);
            this.hardwareDatePurchasedTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareDatePurchasedTextBox.MaxLength = 8;
            this.hardwareDatePurchasedTextBox.Name = "hardwareDatePurchasedTextBox";
            this.hardwareDatePurchasedTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareDatePurchasedTextBox.TabIndex = 62;
            // 
            // hardwareCategoryCodeTextBox
            // 
            this.hardwareCategoryCodeTextBox.Location = new System.Drawing.Point(196, 14);
            this.hardwareCategoryCodeTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareCategoryCodeTextBox.MaxLength = 8;
            this.hardwareCategoryCodeTextBox.Name = "hardwareCategoryCodeTextBox";
            this.hardwareCategoryCodeTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareCategoryCodeTextBox.TabIndex = 75;
            // 
            // hardwareWarrantyExpiryTextBox
            // 
            this.hardwareWarrantyExpiryTextBox.Location = new System.Drawing.Point(196, 272);
            this.hardwareWarrantyExpiryTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareWarrantyExpiryTextBox.MaxLength = 8;
            this.hardwareWarrantyExpiryTextBox.Name = "hardwareWarrantyExpiryTextBox";
            this.hardwareWarrantyExpiryTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareWarrantyExpiryTextBox.TabIndex = 63;
            // 
            // hardwareDeviceNameLabel
            // 
            this.hardwareDeviceNameLabel.AutoSize = true;
            this.hardwareDeviceNameLabel.Location = new System.Drawing.Point(24, 87);
            this.hardwareDeviceNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareDeviceNameLabel.Name = "hardwareDeviceNameLabel";
            this.hardwareDeviceNameLabel.Size = new System.Drawing.Size(96, 17);
            this.hardwareDeviceNameLabel.TabIndex = 74;
            this.hardwareDeviceNameLabel.Text = "Device Name:";
            // 
            // hardwareNotesTextBox
            // 
            this.hardwareNotesTextBox.Location = new System.Drawing.Point(196, 346);
            this.hardwareNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareNotesTextBox.MaxLength = 50;
            this.hardwareNotesTextBox.Name = "hardwareNotesTextBox";
            this.hardwareNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareNotesTextBox.TabIndex = 64;
            // 
            // hardwareVendorLabel
            // 
            this.hardwareVendorLabel.AutoSize = true;
            this.hardwareVendorLabel.Location = new System.Drawing.Point(24, 50);
            this.hardwareVendorLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareVendorLabel.Name = "hardwareVendorLabel";
            this.hardwareVendorLabel.Size = new System.Drawing.Size(58, 17);
            this.hardwareVendorLabel.TabIndex = 73;
            this.hardwareVendorLabel.Text = "Vendor:";
            // 
            // saveHardwareButton
            // 
            this.saveHardwareButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveHardwareButton.Location = new System.Drawing.Point(196, 389);
            this.saveHardwareButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveHardwareButton.Name = "saveHardwareButton";
            this.saveHardwareButton.Size = new System.Drawing.Size(75, 32);
            this.saveHardwareButton.TabIndex = 65;
            this.saveHardwareButton.Text = "Save";
            this.saveHardwareButton.UseVisualStyleBackColor = false;
            // 
            // hardwareCategoryCodeLabel
            // 
            this.hardwareCategoryCodeLabel.AutoSize = true;
            this.hardwareCategoryCodeLabel.Location = new System.Drawing.Point(24, 14);
            this.hardwareCategoryCodeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareCategoryCodeLabel.Name = "hardwareCategoryCodeLabel";
            this.hardwareCategoryCodeLabel.Size = new System.Drawing.Size(106, 17);
            this.hardwareCategoryCodeLabel.TabIndex = 72;
            this.hardwareCategoryCodeLabel.Text = "Category Code:";
            // 
            // hardwareModelLabel
            // 
            this.hardwareModelLabel.AutoSize = true;
            this.hardwareModelLabel.Location = new System.Drawing.Point(24, 124);
            this.hardwareModelLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareModelLabel.Name = "hardwareModelLabel";
            this.hardwareModelLabel.Size = new System.Drawing.Size(50, 17);
            this.hardwareModelLabel.TabIndex = 66;
            this.hardwareModelLabel.Text = "Model:";
            // 
            // hardwareClientAssetNumberTextBox
            // 
            this.hardwareClientAssetNumberTextBox.Location = new System.Drawing.Point(196, 198);
            this.hardwareClientAssetNumberTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareClientAssetNumberTextBox.MaxLength = 50;
            this.hardwareClientAssetNumberTextBox.Name = "hardwareClientAssetNumberTextBox";
            this.hardwareClientAssetNumberTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareClientAssetNumberTextBox.TabIndex = 71;
            // 
            // hardwareSerialNumberLabel
            // 
            this.hardwareSerialNumberLabel.AutoSize = true;
            this.hardwareSerialNumberLabel.Location = new System.Drawing.Point(24, 161);
            this.hardwareSerialNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hardwareSerialNumberLabel.Name = "hardwareSerialNumberLabel";
            this.hardwareSerialNumberLabel.Size = new System.Drawing.Size(102, 17);
            this.hardwareSerialNumberLabel.TabIndex = 67;
            this.hardwareSerialNumberLabel.Text = "Serial Number:";
            // 
            // hardwareSerialNumberTextBox
            // 
            this.hardwareSerialNumberTextBox.Location = new System.Drawing.Point(196, 161);
            this.hardwareSerialNumberTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareSerialNumberTextBox.MaxLength = 8;
            this.hardwareSerialNumberTextBox.Name = "hardwareSerialNumberTextBox";
            this.hardwareSerialNumberTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareSerialNumberTextBox.TabIndex = 70;
            // 
            // hardwareModelTextBox
            // 
            this.hardwareModelTextBox.Location = new System.Drawing.Point(196, 124);
            this.hardwareModelTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hardwareModelTextBox.MaxLength = 8;
            this.hardwareModelTextBox.Name = "hardwareModelTextBox";
            this.hardwareModelTextBox.Size = new System.Drawing.Size(243, 23);
            this.hardwareModelTextBox.TabIndex = 69;
            // 
            // hardwareButtonFlowLayoutPanel
            // 
            this.hardwareButtonFlowLayoutPanel.AutoSize = true;
            this.hardwareButtonFlowLayoutPanel.Controls.Add(this.addHardwareButton);
            this.hardwareButtonFlowLayoutPanel.Controls.Add(this.viewHardwareButton);
            this.hardwareButtonFlowLayoutPanel.Controls.Add(this.button1);
            this.hardwareButtonFlowLayoutPanel.Controls.Add(this.button2);
            this.hardwareButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.hardwareButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.hardwareButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.hardwareButtonFlowLayoutPanel.Name = "hardwareButtonFlowLayoutPanel";
            this.hardwareButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.hardwareButtonFlowLayoutPanel.TabIndex = 4;
            // 
            // addHardwareButton
            // 
            this.addHardwareButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addHardwareButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addHardwareButton.Location = new System.Drawing.Point(4, 4);
            this.addHardwareButton.Margin = new System.Windows.Forms.Padding(4);
            this.addHardwareButton.Name = "addHardwareButton";
            this.addHardwareButton.Size = new System.Drawing.Size(133, 49);
            this.addHardwareButton.TabIndex = 1;
            this.addHardwareButton.Text = "Add";
            this.addHardwareButton.UseVisualStyleBackColor = false;
            this.addHardwareButton.Click += new System.EventHandler(this.addHardwareButton_Click);
            // 
            // viewHardwareButton
            // 
            this.viewHardwareButton.BackColor = System.Drawing.Color.Cyan;
            this.viewHardwareButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewHardwareButton.Location = new System.Drawing.Point(145, 4);
            this.viewHardwareButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewHardwareButton.Name = "viewHardwareButton";
            this.viewHardwareButton.Size = new System.Drawing.Size(133, 49);
            this.viewHardwareButton.TabIndex = 4;
            this.viewHardwareButton.Text = "View";
            this.viewHardwareButton.UseVisualStyleBackColor = false;
            this.viewHardwareButton.Click += new System.EventHandler(this.viewHardwareButton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Cyan;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(286, 4);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 49);
            this.button1.TabIndex = 5;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Cyan;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(427, 4);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(133, 49);
            this.button2.TabIndex = 6;
            this.button2.Text = "Fill";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // licenseTab
            // 
            this.licenseTab.AutoScroll = true;
            this.licenseTab.Controls.Add(this.licenseViewPanel);
            this.licenseTab.Controls.Add(this.addLicenseGroupBox);
            this.licenseTab.Controls.Add(this.licensesButtonFlowLayoutPanel);
            this.licenseTab.ImageIndex = 2;
            this.licenseTab.Location = new System.Drawing.Point(4, 57);
            this.licenseTab.Margin = new System.Windows.Forms.Padding(4);
            this.licenseTab.Name = "licenseTab";
            this.licenseTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.licenseTab.Size = new System.Drawing.Size(1256, 594);
            this.licenseTab.TabIndex = 2;
            this.licenseTab.ToolTipText = "Tab for accessing all data manipulation of a license entry";
            this.licenseTab.UseVisualStyleBackColor = true;
            // 
            // licenseViewPanel
            // 
            this.licenseViewPanel.AutoSize = true;
            this.licenseViewPanel.Controls.Add(this.licensesDataGridView);
            this.licenseViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.licenseViewPanel.Location = new System.Drawing.Point(4, 4);
            this.licenseViewPanel.Name = "licenseViewPanel";
            this.licenseViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.licenseViewPanel.TabIndex = 6;
            // 
            // licensesDataGridView
            // 
            this.licensesDataGridView.AllowUserToOrderColumns = true;
            this.licensesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.licensesDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.licensesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.licensesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.licensesDataGridView.Location = new System.Drawing.Point(0, 0);
            this.licensesDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.licensesDataGridView.MultiSelect = false;
            this.licensesDataGridView.Name = "licensesDataGridView";
            this.licensesDataGridView.Size = new System.Drawing.Size(1248, 501);
            this.licensesDataGridView.TabIndex = 3;
            this.licensesDataGridView.SelectionChanged += new System.EventHandler(this.LicensesDataGridView_SelectionChanged);
            // 
            // addLicenseGroupBox
            // 
            this.addLicenseGroupBox.AutoSize = true;
            this.addLicenseGroupBox.Controls.Add(this.addLicensePanel);
            this.addLicenseGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addLicenseGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addLicenseGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addLicenseGroupBox.Name = "addLicenseGroupBox";
            this.addLicenseGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addLicenseGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addLicenseGroupBox.TabIndex = 5;
            this.addLicenseGroupBox.TabStop = false;
            this.addLicenseGroupBox.Text = "Add License";
            this.addLicenseGroupBox.Visible = false;
            // 
            // addLicensePanel
            // 
            this.addLicensePanel.AutoScroll = true;
            this.addLicensePanel.AutoSize = true;
            this.addLicensePanel.Controls.Add(this.licensesAllocatedNumericUpDown);
            this.addLicensePanel.Controls.Add(this.licensesPurchasedNumericUpDown);
            this.addLicensePanel.Controls.Add(this.licenseQuantityNumericUpDown);
            this.addLicensePanel.Controls.Add(this.licensePackCoreNumericUpDown);
            this.addLicensePanel.Controls.Add(this.licenseCodeOffsetTextBox);
            this.addLicensePanel.Controls.Add(this.licenseTicketNumberTextBox);
            this.addLicensePanel.Controls.Add(this.licenseTicketNumberLabel);
            this.addLicensePanel.Controls.Add(this.licensesPurchasedLabel);
            this.addLicensePanel.Controls.Add(this.saveLicenseButton);
            this.addLicensePanel.Controls.Add(this.licenseSubscriptionTypeLabel);
            this.addLicensePanel.Controls.Add(this.licenseNotesTextBox);
            this.addLicensePanel.Controls.Add(this.licenseQuoteRefTextBox);
            this.addLicensePanel.Controls.Add(this.licenseExpiryDateTextBox);
            this.addLicensePanel.Controls.Add(this.licenseDatePurchasedTextBox);
            this.addLicensePanel.Controls.Add(this.licensePackCoreLabel);
            this.addLicensePanel.Controls.Add(this.licenseNotesLabel);
            this.addLicensePanel.Controls.Add(this.licenseVendorAllocatedKeyTextBox);
            this.addLicensePanel.Controls.Add(this.licenseExpiryDateLabel);
            this.addLicensePanel.Controls.Add(this.licenseQuantityLabel);
            this.addLicensePanel.Controls.Add(this.licenseDatePurchasedLabel);
            this.addLicensePanel.Controls.Add(this.licenseSubscriptionTypeTextBox);
            this.addLicensePanel.Controls.Add(this.licenseQuoteRefLabel);
            this.addLicensePanel.Controls.Add(this.licenseVendorAllocatedKeyLabel);
            this.addLicensePanel.Controls.Add(this.licensesAllocatedLabel);
            this.addLicensePanel.Controls.Add(this.licenseCodeOffsetLabel);
            this.addLicensePanel.Controls.Add(this.licenseCategoryLabel);
            this.addLicensePanel.Controls.Add(this.licenseProductDescriptionLabel);
            this.addLicensePanel.Controls.Add(this.licenseCategoryTextBox);
            this.addLicensePanel.Controls.Add(this.licenseProductDescriptionTextBox);
            this.addLicensePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addLicensePanel.Location = new System.Drawing.Point(4, 20);
            this.addLicensePanel.Margin = new System.Windows.Forms.Padding(4);
            this.addLicensePanel.Name = "addLicensePanel";
            this.addLicensePanel.Size = new System.Drawing.Size(1240, 477);
            this.addLicensePanel.TabIndex = 109;
            // 
            // licensesAllocatedNumericUpDown
            // 
            this.licensesAllocatedNumericUpDown.Location = new System.Drawing.Point(183, 254);
            this.licensesAllocatedNumericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.licensesAllocatedNumericUpDown.Name = "licensesAllocatedNumericUpDown";
            this.licensesAllocatedNumericUpDown.Size = new System.Drawing.Size(243, 23);
            this.licensesAllocatedNumericUpDown.TabIndex = 111;
            // 
            // licensesPurchasedNumericUpDown
            // 
            this.licensesPurchasedNumericUpDown.Location = new System.Drawing.Point(183, 217);
            this.licensesPurchasedNumericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.licensesPurchasedNumericUpDown.Name = "licensesPurchasedNumericUpDown";
            this.licensesPurchasedNumericUpDown.Size = new System.Drawing.Size(243, 23);
            this.licensesPurchasedNumericUpDown.TabIndex = 110;
            // 
            // licenseQuantityNumericUpDown
            // 
            this.licenseQuantityNumericUpDown.Location = new System.Drawing.Point(183, 180);
            this.licenseQuantityNumericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.licenseQuantityNumericUpDown.Name = "licenseQuantityNumericUpDown";
            this.licenseQuantityNumericUpDown.Size = new System.Drawing.Size(243, 23);
            this.licenseQuantityNumericUpDown.TabIndex = 109;
            // 
            // licensePackCoreNumericUpDown
            // 
            this.licensePackCoreNumericUpDown.Location = new System.Drawing.Point(184, 143);
            this.licensePackCoreNumericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.licensePackCoreNumericUpDown.Name = "licensePackCoreNumericUpDown";
            this.licensePackCoreNumericUpDown.Size = new System.Drawing.Size(243, 23);
            this.licensePackCoreNumericUpDown.TabIndex = 108;
            // 
            // licenseCodeOffsetTextBox
            // 
            this.licenseCodeOffsetTextBox.Location = new System.Drawing.Point(183, -5);
            this.licenseCodeOffsetTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseCodeOffsetTextBox.MaxLength = 3;
            this.licenseCodeOffsetTextBox.Name = "licenseCodeOffsetTextBox";
            this.licenseCodeOffsetTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseCodeOffsetTextBox.TabIndex = 96;
            // 
            // licenseTicketNumberTextBox
            // 
            this.licenseTicketNumberTextBox.Location = new System.Drawing.Point(184, 438);
            this.licenseTicketNumberTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseTicketNumberTextBox.MaxLength = 10;
            this.licenseTicketNumberTextBox.Name = "licenseTicketNumberTextBox";
            this.licenseTicketNumberTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseTicketNumberTextBox.TabIndex = 100;
            // 
            // licenseTicketNumberLabel
            // 
            this.licenseTicketNumberLabel.AutoSize = true;
            this.licenseTicketNumberLabel.Location = new System.Drawing.Point(12, 438);
            this.licenseTicketNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseTicketNumberLabel.Name = "licenseTicketNumberLabel";
            this.licenseTicketNumberLabel.Size = new System.Drawing.Size(104, 17);
            this.licenseTicketNumberLabel.TabIndex = 99;
            this.licenseTicketNumberLabel.Text = "Ticket Number:";
            // 
            // licensesPurchasedLabel
            // 
            this.licensesPurchasedLabel.AutoSize = true;
            this.licensesPurchasedLabel.Location = new System.Drawing.Point(12, 217);
            this.licensesPurchasedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licensesPurchasedLabel.Name = "licensesPurchasedLabel";
            this.licensesPurchasedLabel.Size = new System.Drawing.Size(140, 17);
            this.licensesPurchasedLabel.TabIndex = 107;
            this.licensesPurchasedLabel.Text = "Licenses Purchased:";
            // 
            // saveLicenseButton
            // 
            this.saveLicenseButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveLicenseButton.Location = new System.Drawing.Point(183, 512);
            this.saveLicenseButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveLicenseButton.Name = "saveLicenseButton";
            this.saveLicenseButton.Size = new System.Drawing.Size(75, 32);
            this.saveLicenseButton.TabIndex = 86;
            this.saveLicenseButton.Text = "Save";
            this.saveLicenseButton.UseVisualStyleBackColor = false;
            // 
            // licenseSubscriptionTypeLabel
            // 
            this.licenseSubscriptionTypeLabel.AutoSize = true;
            this.licenseSubscriptionTypeLabel.Location = new System.Drawing.Point(11, 106);
            this.licenseSubscriptionTypeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseSubscriptionTypeLabel.Name = "licenseSubscriptionTypeLabel";
            this.licenseSubscriptionTypeLabel.Size = new System.Drawing.Size(126, 17);
            this.licenseSubscriptionTypeLabel.TabIndex = 87;
            this.licenseSubscriptionTypeLabel.Text = "Subscription Type:";
            // 
            // licenseNotesTextBox
            // 
            this.licenseNotesTextBox.Location = new System.Drawing.Point(184, 475);
            this.licenseNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseNotesTextBox.MaxLength = 50;
            this.licenseNotesTextBox.Name = "licenseNotesTextBox";
            this.licenseNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseNotesTextBox.TabIndex = 85;
            // 
            // licenseQuoteRefTextBox
            // 
            this.licenseQuoteRefTextBox.Location = new System.Drawing.Point(184, 401);
            this.licenseQuoteRefTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseQuoteRefTextBox.MaxLength = 10;
            this.licenseQuoteRefTextBox.Name = "licenseQuoteRefTextBox";
            this.licenseQuoteRefTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseQuoteRefTextBox.TabIndex = 106;
            // 
            // licenseExpiryDateTextBox
            // 
            this.licenseExpiryDateTextBox.Location = new System.Drawing.Point(183, 364);
            this.licenseExpiryDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseExpiryDateTextBox.MaxLength = 8;
            this.licenseExpiryDateTextBox.Name = "licenseExpiryDateTextBox";
            this.licenseExpiryDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseExpiryDateTextBox.TabIndex = 84;
            // 
            // licenseDatePurchasedTextBox
            // 
            this.licenseDatePurchasedTextBox.Location = new System.Drawing.Point(183, 328);
            this.licenseDatePurchasedTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseDatePurchasedTextBox.MaxLength = 8;
            this.licenseDatePurchasedTextBox.Name = "licenseDatePurchasedTextBox";
            this.licenseDatePurchasedTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseDatePurchasedTextBox.TabIndex = 83;
            // 
            // licensePackCoreLabel
            // 
            this.licensePackCoreLabel.AutoSize = true;
            this.licensePackCoreLabel.Location = new System.Drawing.Point(11, 143);
            this.licensePackCoreLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licensePackCoreLabel.Name = "licensePackCoreLabel";
            this.licensePackCoreLabel.Size = new System.Drawing.Size(85, 17);
            this.licensePackCoreLabel.TabIndex = 88;
            this.licensePackCoreLabel.Text = "Pack / Core:";
            // 
            // licenseNotesLabel
            // 
            this.licenseNotesLabel.AutoSize = true;
            this.licenseNotesLabel.Location = new System.Drawing.Point(12, 475);
            this.licenseNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseNotesLabel.Name = "licenseNotesLabel";
            this.licenseNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.licenseNotesLabel.TabIndex = 82;
            this.licenseNotesLabel.Text = "Notes:";
            // 
            // licenseVendorAllocatedKeyTextBox
            // 
            this.licenseVendorAllocatedKeyTextBox.Location = new System.Drawing.Point(184, 291);
            this.licenseVendorAllocatedKeyTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseVendorAllocatedKeyTextBox.MaxLength = 3;
            this.licenseVendorAllocatedKeyTextBox.Name = "licenseVendorAllocatedKeyTextBox";
            this.licenseVendorAllocatedKeyTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseVendorAllocatedKeyTextBox.TabIndex = 105;
            // 
            // licenseExpiryDateLabel
            // 
            this.licenseExpiryDateLabel.AutoSize = true;
            this.licenseExpiryDateLabel.Location = new System.Drawing.Point(11, 364);
            this.licenseExpiryDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseExpiryDateLabel.Name = "licenseExpiryDateLabel";
            this.licenseExpiryDateLabel.Size = new System.Drawing.Size(112, 17);
            this.licenseExpiryDateLabel.TabIndex = 81;
            this.licenseExpiryDateLabel.Text = "Warranty Expiry:";
            // 
            // licenseQuantityLabel
            // 
            this.licenseQuantityLabel.AutoSize = true;
            this.licenseQuantityLabel.Location = new System.Drawing.Point(11, 180);
            this.licenseQuantityLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseQuantityLabel.Name = "licenseQuantityLabel";
            this.licenseQuantityLabel.Size = new System.Drawing.Size(65, 17);
            this.licenseQuantityLabel.TabIndex = 89;
            this.licenseQuantityLabel.Text = "Quantity:";
            // 
            // licenseDatePurchasedLabel
            // 
            this.licenseDatePurchasedLabel.AutoSize = true;
            this.licenseDatePurchasedLabel.Location = new System.Drawing.Point(11, 328);
            this.licenseDatePurchasedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseDatePurchasedLabel.Name = "licenseDatePurchasedLabel";
            this.licenseDatePurchasedLabel.Size = new System.Drawing.Size(114, 17);
            this.licenseDatePurchasedLabel.TabIndex = 80;
            this.licenseDatePurchasedLabel.Text = "Date Purchased:";
            // 
            // licenseSubscriptionTypeTextBox
            // 
            this.licenseSubscriptionTypeTextBox.Location = new System.Drawing.Point(183, 106);
            this.licenseSubscriptionTypeTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseSubscriptionTypeTextBox.MaxLength = 4;
            this.licenseSubscriptionTypeTextBox.Name = "licenseSubscriptionTypeTextBox";
            this.licenseSubscriptionTypeTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseSubscriptionTypeTextBox.TabIndex = 90;
            // 
            // licenseQuoteRefLabel
            // 
            this.licenseQuoteRefLabel.AutoSize = true;
            this.licenseQuoteRefLabel.Location = new System.Drawing.Point(12, 401);
            this.licenseQuoteRefLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseQuoteRefLabel.Name = "licenseQuoteRefLabel";
            this.licenseQuoteRefLabel.Size = new System.Drawing.Size(77, 17);
            this.licenseQuoteRefLabel.TabIndex = 103;
            this.licenseQuoteRefLabel.Text = "Quote Ref:";
            // 
            // licenseVendorAllocatedKeyLabel
            // 
            this.licenseVendorAllocatedKeyLabel.AutoSize = true;
            this.licenseVendorAllocatedKeyLabel.Location = new System.Drawing.Point(12, 291);
            this.licenseVendorAllocatedKeyLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseVendorAllocatedKeyLabel.Name = "licenseVendorAllocatedKeyLabel";
            this.licenseVendorAllocatedKeyLabel.Size = new System.Drawing.Size(148, 17);
            this.licenseVendorAllocatedKeyLabel.TabIndex = 102;
            this.licenseVendorAllocatedKeyLabel.Text = "Vendor Allocated Key:";
            // 
            // licensesAllocatedLabel
            // 
            this.licensesAllocatedLabel.AutoSize = true;
            this.licensesAllocatedLabel.Location = new System.Drawing.Point(12, 254);
            this.licensesAllocatedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licensesAllocatedLabel.Name = "licensesAllocatedLabel";
            this.licensesAllocatedLabel.Size = new System.Drawing.Size(130, 17);
            this.licensesAllocatedLabel.TabIndex = 101;
            this.licensesAllocatedLabel.Text = "Licenses Allocated:";
            // 
            // licenseCodeOffsetLabel
            // 
            this.licenseCodeOffsetLabel.AutoSize = true;
            this.licenseCodeOffsetLabel.Location = new System.Drawing.Point(11, -5);
            this.licenseCodeOffsetLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseCodeOffsetLabel.Name = "licenseCodeOffsetLabel";
            this.licenseCodeOffsetLabel.Size = new System.Drawing.Size(140, 17);
            this.licenseCodeOffsetLabel.TabIndex = 93;
            this.licenseCodeOffsetLabel.Text = "License Code/Offset:";
            // 
            // licenseCategoryLabel
            // 
            this.licenseCategoryLabel.AutoSize = true;
            this.licenseCategoryLabel.Location = new System.Drawing.Point(11, 32);
            this.licenseCategoryLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseCategoryLabel.Name = "licenseCategoryLabel";
            this.licenseCategoryLabel.Size = new System.Drawing.Size(122, 17);
            this.licenseCategoryLabel.TabIndex = 94;
            this.licenseCategoryLabel.Text = "License Category:";
            // 
            // licenseProductDescriptionLabel
            // 
            this.licenseProductDescriptionLabel.AutoSize = true;
            this.licenseProductDescriptionLabel.Location = new System.Drawing.Point(11, 69);
            this.licenseProductDescriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.licenseProductDescriptionLabel.Name = "licenseProductDescriptionLabel";
            this.licenseProductDescriptionLabel.Size = new System.Drawing.Size(136, 17);
            this.licenseProductDescriptionLabel.TabIndex = 95;
            this.licenseProductDescriptionLabel.Text = "Product Description:";
            // 
            // licenseCategoryTextBox
            // 
            this.licenseCategoryTextBox.Location = new System.Drawing.Point(183, 32);
            this.licenseCategoryTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseCategoryTextBox.MaxLength = 30;
            this.licenseCategoryTextBox.Name = "licenseCategoryTextBox";
            this.licenseCategoryTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseCategoryTextBox.TabIndex = 97;
            // 
            // licenseProductDescriptionTextBox
            // 
            this.licenseProductDescriptionTextBox.Location = new System.Drawing.Point(183, 69);
            this.licenseProductDescriptionTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.licenseProductDescriptionTextBox.MaxLength = 30;
            this.licenseProductDescriptionTextBox.Name = "licenseProductDescriptionTextBox";
            this.licenseProductDescriptionTextBox.Size = new System.Drawing.Size(243, 23);
            this.licenseProductDescriptionTextBox.TabIndex = 98;
            // 
            // licensesButtonFlowLayoutPanel
            // 
            this.licensesButtonFlowLayoutPanel.AutoSize = true;
            this.licensesButtonFlowLayoutPanel.Controls.Add(this.addLicenseButton);
            this.licensesButtonFlowLayoutPanel.Controls.Add(this.viewLicensesbutton);
            this.licensesButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.licensesButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.licensesButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.licensesButtonFlowLayoutPanel.Name = "licensesButtonFlowLayoutPanel";
            this.licensesButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.licensesButtonFlowLayoutPanel.TabIndex = 4;
            // 
            // addLicenseButton
            // 
            this.addLicenseButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addLicenseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addLicenseButton.Location = new System.Drawing.Point(4, 4);
            this.addLicenseButton.Margin = new System.Windows.Forms.Padding(4);
            this.addLicenseButton.Name = "addLicenseButton";
            this.addLicenseButton.Size = new System.Drawing.Size(133, 49);
            this.addLicenseButton.TabIndex = 1;
            this.addLicenseButton.Text = "Add";
            this.addLicenseButton.UseVisualStyleBackColor = false;
            this.addLicenseButton.Click += new System.EventHandler(this.addLicenseButton_Click);
            // 
            // viewLicensesbutton
            // 
            this.viewLicensesbutton.BackColor = System.Drawing.Color.Cyan;
            this.viewLicensesbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewLicensesbutton.Location = new System.Drawing.Point(145, 4);
            this.viewLicensesbutton.Margin = new System.Windows.Forms.Padding(4);
            this.viewLicensesbutton.Name = "viewLicensesbutton";
            this.viewLicensesbutton.Size = new System.Drawing.Size(133, 49);
            this.viewLicensesbutton.TabIndex = 5;
            this.viewLicensesbutton.Text = "View";
            this.viewLicensesbutton.UseVisualStyleBackColor = false;
            this.viewLicensesbutton.Click += new System.EventHandler(this.viewLicensesbutton_Click);
            // 
            // usersTab
            // 
            this.usersTab.AutoScroll = true;
            this.usersTab.Controls.Add(this.userViewPanel);
            this.usersTab.Controls.Add(this.addUsersGroupBox);
            this.usersTab.Controls.Add(this.userButtonFlowLayoutPanel);
            this.usersTab.ImageIndex = 3;
            this.usersTab.Location = new System.Drawing.Point(4, 57);
            this.usersTab.Margin = new System.Windows.Forms.Padding(4);
            this.usersTab.Name = "usersTab";
            this.usersTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.usersTab.Size = new System.Drawing.Size(1256, 594);
            this.usersTab.TabIndex = 3;
            this.usersTab.ToolTipText = "Tab for accessing all data manipulation of a user entry";
            this.usersTab.UseVisualStyleBackColor = true;
            // 
            // userViewPanel
            // 
            this.userViewPanel.AutoSize = true;
            this.userViewPanel.Controls.Add(this.usersDataGridView);
            this.userViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userViewPanel.Location = new System.Drawing.Point(4, 4);
            this.userViewPanel.Name = "userViewPanel";
            this.userViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.userViewPanel.TabIndex = 6;
            // 
            // usersDataGridView
            // 
            this.usersDataGridView.AllowUserToOrderColumns = true;
            this.usersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.usersDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.usersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usersDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.usersDataGridView.Location = new System.Drawing.Point(0, 0);
            this.usersDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.usersDataGridView.MultiSelect = false;
            this.usersDataGridView.Name = "usersDataGridView";
            this.usersDataGridView.Size = new System.Drawing.Size(1248, 501);
            this.usersDataGridView.TabIndex = 3;
            this.usersDataGridView.SelectionChanged += new System.EventHandler(this.UsersDataGridView_SelectionChanged);
            // 
            // addUsersGroupBox
            // 
            this.addUsersGroupBox.AutoSize = true;
            this.addUsersGroupBox.Controls.Add(this.addUserPanel);
            this.addUsersGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addUsersGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addUsersGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addUsersGroupBox.Name = "addUsersGroupBox";
            this.addUsersGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addUsersGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addUsersGroupBox.TabIndex = 5;
            this.addUsersGroupBox.TabStop = false;
            this.addUsersGroupBox.Text = "Add User";
            this.addUsersGroupBox.Visible = false;
            // 
            // addUserPanel
            // 
            this.addUserPanel.AutoScroll = true;
            this.addUserPanel.AutoSize = true;
            this.addUserPanel.Controls.Add(this.userSuspendedDateTextBox);
            this.addUserPanel.Controls.Add(this.userSuspendedDateLabel);
            this.addUserPanel.Controls.Add(this.saveUserButton);
            this.addUserPanel.Controls.Add(this.userNotesTextBox);
            this.addUserPanel.Controls.Add(this.userTerminationDateTextBox);
            this.addUserPanel.Controls.Add(this.userCommencementDateTextBox);
            this.addUserPanel.Controls.Add(this.user1stNameTextBox);
            this.addUserPanel.Controls.Add(this.userNotesLabel);
            this.addUserPanel.Controls.Add(this.userSurnameTextBox);
            this.addUserPanel.Controls.Add(this.userCommencementDateLabel);
            this.addUserPanel.Controls.Add(this.user1stNameLabel);
            this.addUserPanel.Controls.Add(this.userTerminationDateLabel);
            this.addUserPanel.Controls.Add(this.userSurnameLabel);
            this.addUserPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addUserPanel.Location = new System.Drawing.Point(4, 20);
            this.addUserPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addUserPanel.Name = "addUserPanel";
            this.addUserPanel.Size = new System.Drawing.Size(1240, 477);
            this.addUserPanel.TabIndex = 0;
            // 
            // userSuspendedDateTextBox
            // 
            this.userSuspendedDateTextBox.Location = new System.Drawing.Point(176, 160);
            this.userSuspendedDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userSuspendedDateTextBox.MaxLength = 8;
            this.userSuspendedDateTextBox.Name = "userSuspendedDateTextBox";
            this.userSuspendedDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.userSuspendedDateTextBox.TabIndex = 115;
            // 
            // userSuspendedDateLabel
            // 
            this.userSuspendedDateLabel.AutoSize = true;
            this.userSuspendedDateLabel.Location = new System.Drawing.Point(4, 160);
            this.userSuspendedDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userSuspendedDateLabel.Name = "userSuspendedDateLabel";
            this.userSuspendedDateLabel.Size = new System.Drawing.Size(118, 17);
            this.userSuspendedDateLabel.TabIndex = 114;
            this.userSuspendedDateLabel.Text = "Suspended Date:";
            // 
            // saveUserButton
            // 
            this.saveUserButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveUserButton.Location = new System.Drawing.Point(176, 234);
            this.saveUserButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveUserButton.Name = "saveUserButton";
            this.saveUserButton.Size = new System.Drawing.Size(75, 32);
            this.saveUserButton.TabIndex = 113;
            this.saveUserButton.Text = "Save";
            this.saveUserButton.UseVisualStyleBackColor = false;
            // 
            // userNotesTextBox
            // 
            this.userNotesTextBox.Location = new System.Drawing.Point(176, 197);
            this.userNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userNotesTextBox.MaxLength = 50;
            this.userNotesTextBox.Name = "userNotesTextBox";
            this.userNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.userNotesTextBox.TabIndex = 112;
            // 
            // userTerminationDateTextBox
            // 
            this.userTerminationDateTextBox.Location = new System.Drawing.Point(176, 123);
            this.userTerminationDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userTerminationDateTextBox.MaxLength = 8;
            this.userTerminationDateTextBox.Name = "userTerminationDateTextBox";
            this.userTerminationDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.userTerminationDateTextBox.TabIndex = 119;
            // 
            // userCommencementDateTextBox
            // 
            this.userCommencementDateTextBox.Location = new System.Drawing.Point(175, 86);
            this.userCommencementDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userCommencementDateTextBox.MaxLength = 8;
            this.userCommencementDateTextBox.Name = "userCommencementDateTextBox";
            this.userCommencementDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.userCommencementDateTextBox.TabIndex = 111;
            // 
            // user1stNameTextBox
            // 
            this.user1stNameTextBox.Location = new System.Drawing.Point(175, 49);
            this.user1stNameTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.user1stNameTextBox.MaxLength = 20;
            this.user1stNameTextBox.Name = "user1stNameTextBox";
            this.user1stNameTextBox.Size = new System.Drawing.Size(243, 23);
            this.user1stNameTextBox.TabIndex = 110;
            // 
            // userNotesLabel
            // 
            this.userNotesLabel.AutoSize = true;
            this.userNotesLabel.Location = new System.Drawing.Point(4, 197);
            this.userNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userNotesLabel.Name = "userNotesLabel";
            this.userNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.userNotesLabel.TabIndex = 109;
            this.userNotesLabel.Text = "Notes:";
            // 
            // userSurnameTextBox
            // 
            this.userSurnameTextBox.Location = new System.Drawing.Point(176, 12);
            this.userSurnameTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userSurnameTextBox.MaxLength = 20;
            this.userSurnameTextBox.Name = "userSurnameTextBox";
            this.userSurnameTextBox.Size = new System.Drawing.Size(243, 23);
            this.userSurnameTextBox.TabIndex = 118;
            // 
            // userCommencementDateLabel
            // 
            this.userCommencementDateLabel.AutoSize = true;
            this.userCommencementDateLabel.Location = new System.Drawing.Point(3, 86);
            this.userCommencementDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userCommencementDateLabel.Name = "userCommencementDateLabel";
            this.userCommencementDateLabel.Size = new System.Drawing.Size(147, 17);
            this.userCommencementDateLabel.TabIndex = 108;
            this.userCommencementDateLabel.Text = "Commencement Date:";
            // 
            // user1stNameLabel
            // 
            this.user1stNameLabel.AutoSize = true;
            this.user1stNameLabel.Location = new System.Drawing.Point(3, 49);
            this.user1stNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.user1stNameLabel.Name = "user1stNameLabel";
            this.user1stNameLabel.Size = new System.Drawing.Size(106, 17);
            this.user1stNameLabel.TabIndex = 107;
            this.user1stNameLabel.Text = "User 1st Name:";
            // 
            // userTerminationDateLabel
            // 
            this.userTerminationDateLabel.AutoSize = true;
            this.userTerminationDateLabel.Location = new System.Drawing.Point(4, 123);
            this.userTerminationDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userTerminationDateLabel.Name = "userTerminationDateLabel";
            this.userTerminationDateLabel.Size = new System.Drawing.Size(121, 17);
            this.userTerminationDateLabel.TabIndex = 117;
            this.userTerminationDateLabel.Text = "Termination Date:";
            // 
            // userSurnameLabel
            // 
            this.userSurnameLabel.AutoSize = true;
            this.userSurnameLabel.Location = new System.Drawing.Point(4, 12);
            this.userSurnameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userSurnameLabel.Name = "userSurnameLabel";
            this.userSurnameLabel.Size = new System.Drawing.Size(103, 17);
            this.userSurnameLabel.TabIndex = 116;
            this.userSurnameLabel.Text = "User Surname:";
            // 
            // userButtonFlowLayoutPanel
            // 
            this.userButtonFlowLayoutPanel.AutoSize = true;
            this.userButtonFlowLayoutPanel.Controls.Add(this.addUserButton);
            this.userButtonFlowLayoutPanel.Controls.Add(this.viewUsersButton);
            this.userButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.userButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.userButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.userButtonFlowLayoutPanel.Name = "userButtonFlowLayoutPanel";
            this.userButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.userButtonFlowLayoutPanel.TabIndex = 4;
            // 
            // addUserButton
            // 
            this.addUserButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUserButton.Location = new System.Drawing.Point(4, 4);
            this.addUserButton.Margin = new System.Windows.Forms.Padding(4);
            this.addUserButton.Name = "addUserButton";
            this.addUserButton.Size = new System.Drawing.Size(133, 49);
            this.addUserButton.TabIndex = 1;
            this.addUserButton.Text = "Add";
            this.addUserButton.UseVisualStyleBackColor = false;
            this.addUserButton.Click += new System.EventHandler(this.addUserButton_Click);
            // 
            // viewUsersButton
            // 
            this.viewUsersButton.BackColor = System.Drawing.Color.Cyan;
            this.viewUsersButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewUsersButton.Location = new System.Drawing.Point(145, 4);
            this.viewUsersButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewUsersButton.Name = "viewUsersButton";
            this.viewUsersButton.Size = new System.Drawing.Size(133, 49);
            this.viewUsersButton.TabIndex = 6;
            this.viewUsersButton.Text = "View";
            this.viewUsersButton.UseVisualStyleBackColor = false;
            this.viewUsersButton.Click += new System.EventHandler(this.viewUsersButton_Click);
            // 
            // emailAddressesTab
            // 
            this.emailAddressesTab.AutoScroll = true;
            this.emailAddressesTab.Controls.Add(this.emailAddressViewPanel);
            this.emailAddressesTab.Controls.Add(this.addEmailAddressGroupBox);
            this.emailAddressesTab.Controls.Add(this.emailAddressesButtonFlowLayoutPanel);
            this.emailAddressesTab.ImageIndex = 4;
            this.emailAddressesTab.Location = new System.Drawing.Point(4, 57);
            this.emailAddressesTab.Margin = new System.Windows.Forms.Padding(4);
            this.emailAddressesTab.Name = "emailAddressesTab";
            this.emailAddressesTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.emailAddressesTab.Size = new System.Drawing.Size(1256, 594);
            this.emailAddressesTab.TabIndex = 4;
            this.emailAddressesTab.ToolTipText = "Tab for accessing all data manipulation of a email addresses entry";
            this.emailAddressesTab.UseVisualStyleBackColor = true;
            // 
            // emailAddressViewPanel
            // 
            this.emailAddressViewPanel.AutoSize = true;
            this.emailAddressViewPanel.Controls.Add(this.emailAddressesGridView);
            this.emailAddressViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.emailAddressViewPanel.Location = new System.Drawing.Point(4, 4);
            this.emailAddressViewPanel.Name = "emailAddressViewPanel";
            this.emailAddressViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.emailAddressViewPanel.TabIndex = 6;
            // 
            // emailAddressesGridView
            // 
            this.emailAddressesGridView.AllowUserToAddRows = false;
            this.emailAddressesGridView.AllowUserToDeleteRows = false;
            this.emailAddressesGridView.AllowUserToOrderColumns = true;
            this.emailAddressesGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.emailAddressesGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.emailAddressesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.emailAddressesGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.emailAddressesGridView.Location = new System.Drawing.Point(0, 0);
            this.emailAddressesGridView.Margin = new System.Windows.Forms.Padding(4);
            this.emailAddressesGridView.MultiSelect = false;
            this.emailAddressesGridView.Name = "emailAddressesGridView";
            this.emailAddressesGridView.ReadOnly = true;
            this.emailAddressesGridView.Size = new System.Drawing.Size(1248, 501);
            this.emailAddressesGridView.TabIndex = 3;
            this.emailAddressesGridView.SelectionChanged += new System.EventHandler(this.EmailAddressDataGridView_SelectionChanged);
            // 
            // addEmailAddressGroupBox
            // 
            this.addEmailAddressGroupBox.AutoSize = true;
            this.addEmailAddressGroupBox.Controls.Add(this.addEmailAddressPanel);
            this.addEmailAddressGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addEmailAddressGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addEmailAddressGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addEmailAddressGroupBox.Name = "addEmailAddressGroupBox";
            this.addEmailAddressGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addEmailAddressGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addEmailAddressGroupBox.TabIndex = 5;
            this.addEmailAddressGroupBox.TabStop = false;
            this.addEmailAddressGroupBox.Text = "Add Email Address";
            this.addEmailAddressGroupBox.Visible = false;
            // 
            // addEmailAddressPanel
            // 
            this.addEmailAddressPanel.AutoScroll = true;
            this.addEmailAddressPanel.AutoSize = true;
            this.addEmailAddressPanel.Controls.Add(this.saveEmailAddressButton);
            this.addEmailAddressPanel.Controls.Add(this.emailAddressNotesTextBox);
            this.addEmailAddressPanel.Controls.Add(this.emailAddressMailboxTypeTextBox);
            this.addEmailAddressPanel.Controls.Add(this.emailAddressTextBox);
            this.addEmailAddressPanel.Controls.Add(this.emailAddressNotesLabel);
            this.addEmailAddressPanel.Controls.Add(this.emailAddressMailboxTypeLabel);
            this.addEmailAddressPanel.Controls.Add(this.emailAddressLabel);
            this.addEmailAddressPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addEmailAddressPanel.Location = new System.Drawing.Point(4, 20);
            this.addEmailAddressPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addEmailAddressPanel.Name = "addEmailAddressPanel";
            this.addEmailAddressPanel.Size = new System.Drawing.Size(1240, 477);
            this.addEmailAddressPanel.TabIndex = 0;
            // 
            // saveEmailAddressButton
            // 
            this.saveEmailAddressButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveEmailAddressButton.Location = new System.Drawing.Point(141, 174);
            this.saveEmailAddressButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveEmailAddressButton.Name = "saveEmailAddressButton";
            this.saveEmailAddressButton.Size = new System.Drawing.Size(75, 32);
            this.saveEmailAddressButton.TabIndex = 55;
            this.saveEmailAddressButton.Text = "Save";
            this.saveEmailAddressButton.UseVisualStyleBackColor = false;
            // 
            // emailAddressNotesTextBox
            // 
            this.emailAddressNotesTextBox.Location = new System.Drawing.Point(141, 124);
            this.emailAddressNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.emailAddressNotesTextBox.MaxLength = 50;
            this.emailAddressNotesTextBox.Name = "emailAddressNotesTextBox";
            this.emailAddressNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.emailAddressNotesTextBox.TabIndex = 54;
            // 
            // emailAddressMailboxTypeTextBox
            // 
            this.emailAddressMailboxTypeTextBox.Location = new System.Drawing.Point(141, 75);
            this.emailAddressMailboxTypeTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.emailAddressMailboxTypeTextBox.MaxLength = 3;
            this.emailAddressMailboxTypeTextBox.Name = "emailAddressMailboxTypeTextBox";
            this.emailAddressMailboxTypeTextBox.Size = new System.Drawing.Size(243, 23);
            this.emailAddressMailboxTypeTextBox.TabIndex = 53;
            // 
            // emailAddressTextBox
            // 
            this.emailAddressTextBox.Location = new System.Drawing.Point(141, 26);
            this.emailAddressTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.emailAddressTextBox.MaxLength = 30;
            this.emailAddressTextBox.Name = "emailAddressTextBox";
            this.emailAddressTextBox.Size = new System.Drawing.Size(243, 23);
            this.emailAddressTextBox.TabIndex = 52;
            // 
            // emailAddressNotesLabel
            // 
            this.emailAddressNotesLabel.AutoSize = true;
            this.emailAddressNotesLabel.Location = new System.Drawing.Point(7, 124);
            this.emailAddressNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emailAddressNotesLabel.Name = "emailAddressNotesLabel";
            this.emailAddressNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.emailAddressNotesLabel.TabIndex = 51;
            this.emailAddressNotesLabel.Text = "Notes:";
            // 
            // emailAddressMailboxTypeLabel
            // 
            this.emailAddressMailboxTypeLabel.AutoSize = true;
            this.emailAddressMailboxTypeLabel.Location = new System.Drawing.Point(7, 75);
            this.emailAddressMailboxTypeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emailAddressMailboxTypeLabel.Name = "emailAddressMailboxTypeLabel";
            this.emailAddressMailboxTypeLabel.Size = new System.Drawing.Size(95, 17);
            this.emailAddressMailboxTypeLabel.TabIndex = 50;
            this.emailAddressMailboxTypeLabel.Text = "Mailbox Type:";
            // 
            // emailAddressLabel
            // 
            this.emailAddressLabel.AutoSize = true;
            this.emailAddressLabel.Location = new System.Drawing.Point(7, 26);
            this.emailAddressLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emailAddressLabel.Name = "emailAddressLabel";
            this.emailAddressLabel.Size = new System.Drawing.Size(102, 17);
            this.emailAddressLabel.TabIndex = 49;
            this.emailAddressLabel.Text = "Email Address:";
            // 
            // emailAddressesButtonFlowLayoutPanel
            // 
            this.emailAddressesButtonFlowLayoutPanel.AutoSize = true;
            this.emailAddressesButtonFlowLayoutPanel.Controls.Add(this.addEmailAddressesButton);
            this.emailAddressesButtonFlowLayoutPanel.Controls.Add(this.viewEmailAddressessButton);
            this.emailAddressesButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.emailAddressesButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.emailAddressesButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.emailAddressesButtonFlowLayoutPanel.Name = "emailAddressesButtonFlowLayoutPanel";
            this.emailAddressesButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.emailAddressesButtonFlowLayoutPanel.TabIndex = 4;
            // 
            // addEmailAddressesButton
            // 
            this.addEmailAddressesButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addEmailAddressesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addEmailAddressesButton.Location = new System.Drawing.Point(4, 4);
            this.addEmailAddressesButton.Margin = new System.Windows.Forms.Padding(4);
            this.addEmailAddressesButton.Name = "addEmailAddressesButton";
            this.addEmailAddressesButton.Size = new System.Drawing.Size(133, 49);
            this.addEmailAddressesButton.TabIndex = 1;
            this.addEmailAddressesButton.Text = "Add";
            this.addEmailAddressesButton.UseVisualStyleBackColor = false;
            this.addEmailAddressesButton.Click += new System.EventHandler(this.addEmailAddressesButton_Click);
            // 
            // viewEmailAddressessButton
            // 
            this.viewEmailAddressessButton.BackColor = System.Drawing.Color.Cyan;
            this.viewEmailAddressessButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewEmailAddressessButton.Location = new System.Drawing.Point(145, 4);
            this.viewEmailAddressessButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewEmailAddressessButton.Name = "viewEmailAddressessButton";
            this.viewEmailAddressessButton.Size = new System.Drawing.Size(133, 49);
            this.viewEmailAddressessButton.TabIndex = 6;
            this.viewEmailAddressessButton.Text = "View";
            this.viewEmailAddressessButton.UseVisualStyleBackColor = false;
            this.viewEmailAddressessButton.Click += new System.EventHandler(this.viewEmailAddressessButton_Click);
            // 
            // warrantiesTab
            // 
            this.warrantiesTab.AutoScroll = true;
            this.warrantiesTab.Controls.Add(this.warrantyViewPanel);
            this.warrantiesTab.Controls.Add(this.addWarrantyGroupBox);
            this.warrantiesTab.Controls.Add(this.warrantiesButtonFlowLayoutPanel);
            this.warrantiesTab.ImageIndex = 5;
            this.warrantiesTab.Location = new System.Drawing.Point(4, 57);
            this.warrantiesTab.Margin = new System.Windows.Forms.Padding(4);
            this.warrantiesTab.Name = "warrantiesTab";
            this.warrantiesTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.warrantiesTab.Size = new System.Drawing.Size(1256, 594);
            this.warrantiesTab.TabIndex = 5;
            this.warrantiesTab.ToolTipText = "Tab for accessing all data manipulation of a warranty entry";
            this.warrantiesTab.UseVisualStyleBackColor = true;
            // 
            // warrantyViewPanel
            // 
            this.warrantyViewPanel.AutoSize = true;
            this.warrantyViewPanel.Controls.Add(this.warrantiesGridView);
            this.warrantyViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.warrantyViewPanel.Location = new System.Drawing.Point(4, 4);
            this.warrantyViewPanel.Name = "warrantyViewPanel";
            this.warrantyViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.warrantyViewPanel.TabIndex = 8;
            // 
            // warrantiesGridView
            // 
            this.warrantiesGridView.AllowUserToAddRows = false;
            this.warrantiesGridView.AllowUserToDeleteRows = false;
            this.warrantiesGridView.AllowUserToOrderColumns = true;
            this.warrantiesGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.warrantiesGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.warrantiesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.warrantiesGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.warrantiesGridView.Location = new System.Drawing.Point(0, 0);
            this.warrantiesGridView.Margin = new System.Windows.Forms.Padding(4);
            this.warrantiesGridView.MultiSelect = false;
            this.warrantiesGridView.Name = "warrantiesGridView";
            this.warrantiesGridView.ReadOnly = true;
            this.warrantiesGridView.Size = new System.Drawing.Size(1248, 501);
            this.warrantiesGridView.TabIndex = 5;
            this.warrantiesGridView.SelectionChanged += new System.EventHandler(this.WarrantyDataGridView_SelectionChanged);
            // 
            // addWarrantyGroupBox
            // 
            this.addWarrantyGroupBox.AutoSize = true;
            this.addWarrantyGroupBox.Controls.Add(this.addWarrantyPanel);
            this.addWarrantyGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addWarrantyGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addWarrantyGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addWarrantyGroupBox.Name = "addWarrantyGroupBox";
            this.addWarrantyGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addWarrantyGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addWarrantyGroupBox.TabIndex = 7;
            this.addWarrantyGroupBox.TabStop = false;
            this.addWarrantyGroupBox.Text = "Add Warranty";
            this.addWarrantyGroupBox.Visible = false;
            // 
            // addWarrantyPanel
            // 
            this.addWarrantyPanel.AutoScroll = true;
            this.addWarrantyPanel.AutoSize = true;
            this.addWarrantyPanel.Controls.Add(this.warrantyTypeLabel);
            this.addWarrantyPanel.Controls.Add(this.warrantyStatusInactiveRadioButton);
            this.addWarrantyPanel.Controls.Add(this.warrantyStartDateLabel);
            this.addWarrantyPanel.Controls.Add(this.warrantyStatusActiveRadioButton);
            this.addWarrantyPanel.Controls.Add(this.warrantyExpiryDateLabel);
            this.addWarrantyPanel.Controls.Add(this.warrantyStatusLabel);
            this.addWarrantyPanel.Controls.Add(this.warrantyNotesLabel);
            this.addWarrantyPanel.Controls.Add(this.warrantyHardwareItemKeyTextBox);
            this.addWarrantyPanel.Controls.Add(this.warrantyStartDateTextBox);
            this.addWarrantyPanel.Controls.Add(this.warrantyTypeTextBox);
            this.addWarrantyPanel.Controls.Add(this.warrantyExpiryDateTextBox);
            this.addWarrantyPanel.Controls.Add(this.warrantyHardwareItemKeyLabel);
            this.addWarrantyPanel.Controls.Add(this.warrantyNotesTextBox);
            this.addWarrantyPanel.Controls.Add(this.saveWarrantyButton);
            this.addWarrantyPanel.Controls.Add(this.warrantyTicketNumberTextBox);
            this.addWarrantyPanel.Controls.Add(this.warrantyQuoteRefLabel);
            this.addWarrantyPanel.Controls.Add(this.warrantyQuoteRefTextBox);
            this.addWarrantyPanel.Controls.Add(this.warrantyTicketNumberLabel);
            this.addWarrantyPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addWarrantyPanel.Location = new System.Drawing.Point(4, 20);
            this.addWarrantyPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addWarrantyPanel.Name = "addWarrantyPanel";
            this.addWarrantyPanel.Size = new System.Drawing.Size(1240, 477);
            this.addWarrantyPanel.TabIndex = 98;
            // 
            // warrantyTypeLabel
            // 
            this.warrantyTypeLabel.AutoSize = true;
            this.warrantyTypeLabel.Location = new System.Drawing.Point(21, 17);
            this.warrantyTypeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyTypeLabel.Name = "warrantyTypeLabel";
            this.warrantyTypeLabel.Size = new System.Drawing.Size(106, 17);
            this.warrantyTypeLabel.TabIndex = 91;
            this.warrantyTypeLabel.Text = "Warranty Type:";
            // 
            // warrantyStatusInactiveRadioButton
            // 
            this.warrantyStatusInactiveRadioButton.AutoSize = true;
            this.warrantyStatusInactiveRadioButton.Location = new System.Drawing.Point(353, 116);
            this.warrantyStatusInactiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyStatusInactiveRadioButton.Name = "warrantyStatusInactiveRadioButton";
            this.warrantyStatusInactiveRadioButton.Size = new System.Drawing.Size(74, 21);
            this.warrantyStatusInactiveRadioButton.TabIndex = 97;
            this.warrantyStatusInactiveRadioButton.Text = "Inactive";
            this.warrantyStatusInactiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // warrantyStartDateLabel
            // 
            this.warrantyStartDateLabel.AutoSize = true;
            this.warrantyStartDateLabel.Location = new System.Drawing.Point(21, 165);
            this.warrantyStartDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyStartDateLabel.Name = "warrantyStartDateLabel";
            this.warrantyStartDateLabel.Size = new System.Drawing.Size(76, 17);
            this.warrantyStartDateLabel.TabIndex = 78;
            this.warrantyStartDateLabel.Text = "Start Date:";
            // 
            // warrantyStatusActiveRadioButton
            // 
            this.warrantyStatusActiveRadioButton.AutoSize = true;
            this.warrantyStatusActiveRadioButton.Checked = true;
            this.warrantyStatusActiveRadioButton.Location = new System.Drawing.Point(193, 116);
            this.warrantyStatusActiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyStatusActiveRadioButton.Name = "warrantyStatusActiveRadioButton";
            this.warrantyStatusActiveRadioButton.Size = new System.Drawing.Size(64, 21);
            this.warrantyStatusActiveRadioButton.TabIndex = 96;
            this.warrantyStatusActiveRadioButton.TabStop = true;
            this.warrantyStatusActiveRadioButton.Text = "Active";
            this.warrantyStatusActiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // warrantyExpiryDateLabel
            // 
            this.warrantyExpiryDateLabel.AutoSize = true;
            this.warrantyExpiryDateLabel.Location = new System.Drawing.Point(21, 214);
            this.warrantyExpiryDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyExpiryDateLabel.Name = "warrantyExpiryDateLabel";
            this.warrantyExpiryDateLabel.Size = new System.Drawing.Size(84, 17);
            this.warrantyExpiryDateLabel.TabIndex = 79;
            this.warrantyExpiryDateLabel.Text = "Expiry Date:";
            // 
            // warrantyStatusLabel
            // 
            this.warrantyStatusLabel.AutoSize = true;
            this.warrantyStatusLabel.Location = new System.Drawing.Point(21, 116);
            this.warrantyStatusLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyStatusLabel.Name = "warrantyStatusLabel";
            this.warrantyStatusLabel.Size = new System.Drawing.Size(52, 17);
            this.warrantyStatusLabel.TabIndex = 95;
            this.warrantyStatusLabel.Text = "Status:";
            // 
            // warrantyNotesLabel
            // 
            this.warrantyNotesLabel.AutoSize = true;
            this.warrantyNotesLabel.Location = new System.Drawing.Point(21, 362);
            this.warrantyNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyNotesLabel.Name = "warrantyNotesLabel";
            this.warrantyNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.warrantyNotesLabel.TabIndex = 80;
            this.warrantyNotesLabel.Text = "Notes:";
            // 
            // warrantyHardwareItemKeyTextBox
            // 
            this.warrantyHardwareItemKeyTextBox.Location = new System.Drawing.Point(193, 66);
            this.warrantyHardwareItemKeyTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyHardwareItemKeyTextBox.MaxLength = 50;
            this.warrantyHardwareItemKeyTextBox.Name = "warrantyHardwareItemKeyTextBox";
            this.warrantyHardwareItemKeyTextBox.Size = new System.Drawing.Size(243, 23);
            this.warrantyHardwareItemKeyTextBox.TabIndex = 94;
            // 
            // warrantyStartDateTextBox
            // 
            this.warrantyStartDateTextBox.Location = new System.Drawing.Point(193, 165);
            this.warrantyStartDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyStartDateTextBox.MaxLength = 8;
            this.warrantyStartDateTextBox.Name = "warrantyStartDateTextBox";
            this.warrantyStartDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.warrantyStartDateTextBox.TabIndex = 81;
            // 
            // warrantyTypeTextBox
            // 
            this.warrantyTypeTextBox.Location = new System.Drawing.Point(193, 17);
            this.warrantyTypeTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyTypeTextBox.MaxLength = 8;
            this.warrantyTypeTextBox.Name = "warrantyTypeTextBox";
            this.warrantyTypeTextBox.Size = new System.Drawing.Size(243, 23);
            this.warrantyTypeTextBox.TabIndex = 93;
            // 
            // warrantyExpiryDateTextBox
            // 
            this.warrantyExpiryDateTextBox.Location = new System.Drawing.Point(193, 214);
            this.warrantyExpiryDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyExpiryDateTextBox.MaxLength = 8;
            this.warrantyExpiryDateTextBox.Name = "warrantyExpiryDateTextBox";
            this.warrantyExpiryDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.warrantyExpiryDateTextBox.TabIndex = 82;
            // 
            // warrantyHardwareItemKeyLabel
            // 
            this.warrantyHardwareItemKeyLabel.AutoSize = true;
            this.warrantyHardwareItemKeyLabel.Location = new System.Drawing.Point(21, 66);
            this.warrantyHardwareItemKeyLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyHardwareItemKeyLabel.Name = "warrantyHardwareItemKeyLabel";
            this.warrantyHardwareItemKeyLabel.Size = new System.Drawing.Size(131, 17);
            this.warrantyHardwareItemKeyLabel.TabIndex = 92;
            this.warrantyHardwareItemKeyLabel.Text = "Hardware Item Key:";
            // 
            // warrantyNotesTextBox
            // 
            this.warrantyNotesTextBox.Location = new System.Drawing.Point(193, 362);
            this.warrantyNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyNotesTextBox.MaxLength = 50;
            this.warrantyNotesTextBox.Name = "warrantyNotesTextBox";
            this.warrantyNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.warrantyNotesTextBox.TabIndex = 83;
            // 
            // saveWarrantyButton
            // 
            this.saveWarrantyButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveWarrantyButton.Location = new System.Drawing.Point(193, 415);
            this.saveWarrantyButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveWarrantyButton.Name = "saveWarrantyButton";
            this.saveWarrantyButton.Size = new System.Drawing.Size(75, 32);
            this.saveWarrantyButton.TabIndex = 84;
            this.saveWarrantyButton.Text = "Save";
            this.saveWarrantyButton.UseVisualStyleBackColor = false;
            // 
            // warrantyTicketNumberTextBox
            // 
            this.warrantyTicketNumberTextBox.Location = new System.Drawing.Point(193, 313);
            this.warrantyTicketNumberTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyTicketNumberTextBox.MaxLength = 10;
            this.warrantyTicketNumberTextBox.Name = "warrantyTicketNumberTextBox";
            this.warrantyTicketNumberTextBox.Size = new System.Drawing.Size(243, 23);
            this.warrantyTicketNumberTextBox.TabIndex = 90;
            // 
            // warrantyQuoteRefLabel
            // 
            this.warrantyQuoteRefLabel.AutoSize = true;
            this.warrantyQuoteRefLabel.Location = new System.Drawing.Point(21, 263);
            this.warrantyQuoteRefLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyQuoteRefLabel.Name = "warrantyQuoteRefLabel";
            this.warrantyQuoteRefLabel.Size = new System.Drawing.Size(77, 17);
            this.warrantyQuoteRefLabel.TabIndex = 86;
            this.warrantyQuoteRefLabel.Text = "Quote Ref:";
            // 
            // warrantyQuoteRefTextBox
            // 
            this.warrantyQuoteRefTextBox.Location = new System.Drawing.Point(193, 263);
            this.warrantyQuoteRefTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.warrantyQuoteRefTextBox.MaxLength = 10;
            this.warrantyQuoteRefTextBox.Name = "warrantyQuoteRefTextBox";
            this.warrantyQuoteRefTextBox.Size = new System.Drawing.Size(243, 23);
            this.warrantyQuoteRefTextBox.TabIndex = 89;
            // 
            // warrantyTicketNumberLabel
            // 
            this.warrantyTicketNumberLabel.AutoSize = true;
            this.warrantyTicketNumberLabel.Location = new System.Drawing.Point(21, 313);
            this.warrantyTicketNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warrantyTicketNumberLabel.Name = "warrantyTicketNumberLabel";
            this.warrantyTicketNumberLabel.Size = new System.Drawing.Size(104, 17);
            this.warrantyTicketNumberLabel.TabIndex = 87;
            this.warrantyTicketNumberLabel.Text = "Ticket Number:";
            // 
            // warrantiesButtonFlowLayoutPanel
            // 
            this.warrantiesButtonFlowLayoutPanel.AutoSize = true;
            this.warrantiesButtonFlowLayoutPanel.Controls.Add(this.addWarrantiesButton);
            this.warrantiesButtonFlowLayoutPanel.Controls.Add(this.viewWarrantiesButton);
            this.warrantiesButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.warrantiesButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.warrantiesButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.warrantiesButtonFlowLayoutPanel.Name = "warrantiesButtonFlowLayoutPanel";
            this.warrantiesButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.warrantiesButtonFlowLayoutPanel.TabIndex = 6;
            // 
            // addWarrantiesButton
            // 
            this.addWarrantiesButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addWarrantiesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addWarrantiesButton.Location = new System.Drawing.Point(4, 4);
            this.addWarrantiesButton.Margin = new System.Windows.Forms.Padding(4);
            this.addWarrantiesButton.Name = "addWarrantiesButton";
            this.addWarrantiesButton.Size = new System.Drawing.Size(133, 49);
            this.addWarrantiesButton.TabIndex = 1;
            this.addWarrantiesButton.Text = "Add";
            this.addWarrantiesButton.UseVisualStyleBackColor = false;
            this.addWarrantiesButton.Click += new System.EventHandler(this.addWarrantiesButton_Click);
            // 
            // viewWarrantiesButton
            // 
            this.viewWarrantiesButton.BackColor = System.Drawing.Color.Cyan;
            this.viewWarrantiesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewWarrantiesButton.Location = new System.Drawing.Point(145, 4);
            this.viewWarrantiesButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewWarrantiesButton.Name = "viewWarrantiesButton";
            this.viewWarrantiesButton.Size = new System.Drawing.Size(133, 49);
            this.viewWarrantiesButton.TabIndex = 5;
            this.viewWarrantiesButton.Text = "View";
            this.viewWarrantiesButton.UseVisualStyleBackColor = false;
            this.viewWarrantiesButton.Click += new System.EventHandler(this.viewWarrantiesButton_Click);
            // 
            // communicationLinksTab
            // 
            this.communicationLinksTab.AutoScroll = true;
            this.communicationLinksTab.Controls.Add(this.communicationLinkViewPanel);
            this.communicationLinksTab.Controls.Add(this.addCommunicationsLinkGroupBox);
            this.communicationLinksTab.Controls.Add(this.communicationLinksButtonFlowLayoutPanel);
            this.communicationLinksTab.ImageIndex = 6;
            this.communicationLinksTab.Location = new System.Drawing.Point(4, 57);
            this.communicationLinksTab.Margin = new System.Windows.Forms.Padding(4);
            this.communicationLinksTab.Name = "communicationLinksTab";
            this.communicationLinksTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.communicationLinksTab.Size = new System.Drawing.Size(1256, 594);
            this.communicationLinksTab.TabIndex = 6;
            this.communicationLinksTab.ToolTipText = "Tab for accessing all data manipulation of a communication links entry";
            this.communicationLinksTab.UseVisualStyleBackColor = true;
            // 
            // communicationLinkViewPanel
            // 
            this.communicationLinkViewPanel.AutoSize = true;
            this.communicationLinkViewPanel.Controls.Add(this.communicationLinksGridView);
            this.communicationLinkViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.communicationLinkViewPanel.Location = new System.Drawing.Point(4, 4);
            this.communicationLinkViewPanel.Name = "communicationLinkViewPanel";
            this.communicationLinkViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.communicationLinkViewPanel.TabIndex = 8;
            // 
            // communicationLinksGridView
            // 
            this.communicationLinksGridView.AllowUserToAddRows = false;
            this.communicationLinksGridView.AllowUserToDeleteRows = false;
            this.communicationLinksGridView.AllowUserToOrderColumns = true;
            this.communicationLinksGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.communicationLinksGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.communicationLinksGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.communicationLinksGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.communicationLinksGridView.Location = new System.Drawing.Point(0, 0);
            this.communicationLinksGridView.Margin = new System.Windows.Forms.Padding(4);
            this.communicationLinksGridView.MultiSelect = false;
            this.communicationLinksGridView.Name = "communicationLinksGridView";
            this.communicationLinksGridView.ReadOnly = true;
            this.communicationLinksGridView.Size = new System.Drawing.Size(1248, 501);
            this.communicationLinksGridView.TabIndex = 5;
            this.communicationLinksGridView.SelectionChanged += new System.EventHandler(this.CommunicationLinksDataGridView_SelectionChanged);
            // 
            // addCommunicationsLinkGroupBox
            // 
            this.addCommunicationsLinkGroupBox.Controls.Add(this.addCommunicationLinkPanel);
            this.addCommunicationsLinkGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addCommunicationsLinkGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addCommunicationsLinkGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addCommunicationsLinkGroupBox.Name = "addCommunicationsLinkGroupBox";
            this.addCommunicationsLinkGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addCommunicationsLinkGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addCommunicationsLinkGroupBox.TabIndex = 7;
            this.addCommunicationsLinkGroupBox.TabStop = false;
            this.addCommunicationsLinkGroupBox.Text = "Add Communications Link";
            this.addCommunicationsLinkGroupBox.Visible = false;
            // 
            // addCommunicationLinkPanel
            // 
            this.addCommunicationLinkPanel.AutoScroll = true;
            this.addCommunicationLinkPanel.AutoSize = true;
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksVendorTextBox);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksConnectivityAgreementInactiveRadioButton);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkCommencementDateLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksConnectivityAgreementActiveRadioButton);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkTermLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkTermNumericUpDown);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkNotesLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkExpiryDateTextBox);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkCommencementDateTextBox);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkExpiryDateLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinkNotesTextBox);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksTypeTextBox);
            this.addCommunicationLinkPanel.Controls.Add(this.saveCommunicationLinkButton);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksSpeedLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksTypeLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksHardwareItemKeyLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksVendorLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksConnectivityAgreementLabel);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksHardwareItemKeyTextBox);
            this.addCommunicationLinkPanel.Controls.Add(this.communicationLinksSpeedTextBox);
            this.addCommunicationLinkPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addCommunicationLinkPanel.Location = new System.Drawing.Point(4, 20);
            this.addCommunicationLinkPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addCommunicationLinkPanel.Name = "addCommunicationLinkPanel";
            this.addCommunicationLinkPanel.Size = new System.Drawing.Size(1240, 477);
            this.addCommunicationLinkPanel.TabIndex = 102;
            // 
            // communicationLinksVendorTextBox
            // 
            this.communicationLinksVendorTextBox.Location = new System.Drawing.Point(180, 2);
            this.communicationLinksVendorTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinksVendorTextBox.MaxLength = 3;
            this.communicationLinksVendorTextBox.Name = "communicationLinksVendorTextBox";
            this.communicationLinksVendorTextBox.Size = new System.Drawing.Size(243, 23);
            this.communicationLinksVendorTextBox.TabIndex = 95;
            // 
            // communicationLinksConnectivityAgreementInactiveRadioButton
            // 
            this.communicationLinksConnectivityAgreementInactiveRadioButton.AutoSize = true;
            this.communicationLinksConnectivityAgreementInactiveRadioButton.Location = new System.Drawing.Point(340, 199);
            this.communicationLinksConnectivityAgreementInactiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinksConnectivityAgreementInactiveRadioButton.Name = "communicationLinksConnectivityAgreementInactiveRadioButton";
            this.communicationLinksConnectivityAgreementInactiveRadioButton.Size = new System.Drawing.Size(74, 21);
            this.communicationLinksConnectivityAgreementInactiveRadioButton.TabIndex = 101;
            this.communicationLinksConnectivityAgreementInactiveRadioButton.Text = "Inactive";
            this.communicationLinksConnectivityAgreementInactiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // communicationLinkCommencementDateLabel
            // 
            this.communicationLinkCommencementDateLabel.AutoSize = true;
            this.communicationLinkCommencementDateLabel.Location = new System.Drawing.Point(8, 249);
            this.communicationLinkCommencementDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinkCommencementDateLabel.Name = "communicationLinkCommencementDateLabel";
            this.communicationLinkCommencementDateLabel.Size = new System.Drawing.Size(147, 17);
            this.communicationLinkCommencementDateLabel.TabIndex = 80;
            this.communicationLinkCommencementDateLabel.Text = "Commencement Date:";
            // 
            // communicationLinksConnectivityAgreementActiveRadioButton
            // 
            this.communicationLinksConnectivityAgreementActiveRadioButton.AutoSize = true;
            this.communicationLinksConnectivityAgreementActiveRadioButton.Checked = true;
            this.communicationLinksConnectivityAgreementActiveRadioButton.Location = new System.Drawing.Point(180, 199);
            this.communicationLinksConnectivityAgreementActiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinksConnectivityAgreementActiveRadioButton.Name = "communicationLinksConnectivityAgreementActiveRadioButton";
            this.communicationLinksConnectivityAgreementActiveRadioButton.Size = new System.Drawing.Size(64, 21);
            this.communicationLinksConnectivityAgreementActiveRadioButton.TabIndex = 100;
            this.communicationLinksConnectivityAgreementActiveRadioButton.TabStop = true;
            this.communicationLinksConnectivityAgreementActiveRadioButton.Text = "Active";
            this.communicationLinksConnectivityAgreementActiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // communicationLinkTermLabel
            // 
            this.communicationLinkTermLabel.AutoSize = true;
            this.communicationLinkTermLabel.Location = new System.Drawing.Point(8, 298);
            this.communicationLinkTermLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinkTermLabel.Name = "communicationLinkTermLabel";
            this.communicationLinkTermLabel.Size = new System.Drawing.Size(101, 17);
            this.communicationLinkTermLabel.TabIndex = 81;
            this.communicationLinkTermLabel.Text = "Term(Months):";
            // 
            // communicationLinkTermNumericUpDown
            // 
            this.communicationLinkTermNumericUpDown.Location = new System.Drawing.Point(180, 298);
            this.communicationLinkTermNumericUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.communicationLinkTermNumericUpDown.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.communicationLinkTermNumericUpDown.Name = "communicationLinkTermNumericUpDown";
            this.communicationLinkTermNumericUpDown.Size = new System.Drawing.Size(244, 23);
            this.communicationLinkTermNumericUpDown.TabIndex = 99;
            // 
            // communicationLinkNotesLabel
            // 
            this.communicationLinkNotesLabel.AutoSize = true;
            this.communicationLinkNotesLabel.Location = new System.Drawing.Point(8, 396);
            this.communicationLinkNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinkNotesLabel.Name = "communicationLinkNotesLabel";
            this.communicationLinkNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.communicationLinkNotesLabel.TabIndex = 82;
            this.communicationLinkNotesLabel.Text = "Notes:";
            // 
            // communicationLinkExpiryDateTextBox
            // 
            this.communicationLinkExpiryDateTextBox.Location = new System.Drawing.Point(180, 347);
            this.communicationLinkExpiryDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinkExpiryDateTextBox.MaxLength = 8;
            this.communicationLinkExpiryDateTextBox.Name = "communicationLinkExpiryDateTextBox";
            this.communicationLinkExpiryDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.communicationLinkExpiryDateTextBox.TabIndex = 98;
            // 
            // communicationLinkCommencementDateTextBox
            // 
            this.communicationLinkCommencementDateTextBox.Location = new System.Drawing.Point(180, 249);
            this.communicationLinkCommencementDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinkCommencementDateTextBox.MaxLength = 8;
            this.communicationLinkCommencementDateTextBox.Name = "communicationLinkCommencementDateTextBox";
            this.communicationLinkCommencementDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.communicationLinkCommencementDateTextBox.TabIndex = 83;
            // 
            // communicationLinkExpiryDateLabel
            // 
            this.communicationLinkExpiryDateLabel.AutoSize = true;
            this.communicationLinkExpiryDateLabel.Location = new System.Drawing.Point(8, 347);
            this.communicationLinkExpiryDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinkExpiryDateLabel.Name = "communicationLinkExpiryDateLabel";
            this.communicationLinkExpiryDateLabel.Size = new System.Drawing.Size(84, 17);
            this.communicationLinkExpiryDateLabel.TabIndex = 97;
            this.communicationLinkExpiryDateLabel.Text = "Expiry Date:";
            // 
            // communicationLinkNotesTextBox
            // 
            this.communicationLinkNotesTextBox.Location = new System.Drawing.Point(180, 396);
            this.communicationLinkNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinkNotesTextBox.MaxLength = 50;
            this.communicationLinkNotesTextBox.Name = "communicationLinkNotesTextBox";
            this.communicationLinkNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.communicationLinkNotesTextBox.TabIndex = 85;
            // 
            // communicationLinksTypeTextBox
            // 
            this.communicationLinksTypeTextBox.Location = new System.Drawing.Point(180, 52);
            this.communicationLinksTypeTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinksTypeTextBox.MaxLength = 10;
            this.communicationLinksTypeTextBox.Name = "communicationLinksTypeTextBox";
            this.communicationLinksTypeTextBox.Size = new System.Drawing.Size(243, 23);
            this.communicationLinksTypeTextBox.TabIndex = 96;
            // 
            // saveCommunicationLinkButton
            // 
            this.saveCommunicationLinkButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveCommunicationLinkButton.Location = new System.Drawing.Point(180, 446);
            this.saveCommunicationLinkButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveCommunicationLinkButton.Name = "saveCommunicationLinkButton";
            this.saveCommunicationLinkButton.Size = new System.Drawing.Size(75, 32);
            this.saveCommunicationLinkButton.TabIndex = 86;
            this.saveCommunicationLinkButton.Text = "Save";
            this.saveCommunicationLinkButton.UseVisualStyleBackColor = false;
            // 
            // communicationLinksSpeedLabel
            // 
            this.communicationLinksSpeedLabel.AutoSize = true;
            this.communicationLinksSpeedLabel.Location = new System.Drawing.Point(8, 101);
            this.communicationLinksSpeedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinksSpeedLabel.Name = "communicationLinksSpeedLabel";
            this.communicationLinksSpeedLabel.Size = new System.Drawing.Size(53, 17);
            this.communicationLinksSpeedLabel.TabIndex = 87;
            this.communicationLinksSpeedLabel.Text = "Speed:";
            // 
            // communicationLinksTypeLabel
            // 
            this.communicationLinksTypeLabel.AutoSize = true;
            this.communicationLinksTypeLabel.Location = new System.Drawing.Point(8, 52);
            this.communicationLinksTypeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinksTypeLabel.Name = "communicationLinksTypeLabel";
            this.communicationLinksTypeLabel.Size = new System.Drawing.Size(74, 17);
            this.communicationLinksTypeLabel.TabIndex = 94;
            this.communicationLinksTypeLabel.Text = "Link Type:";
            // 
            // communicationLinksHardwareItemKeyLabel
            // 
            this.communicationLinksHardwareItemKeyLabel.AutoSize = true;
            this.communicationLinksHardwareItemKeyLabel.Location = new System.Drawing.Point(8, 150);
            this.communicationLinksHardwareItemKeyLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinksHardwareItemKeyLabel.Name = "communicationLinksHardwareItemKeyLabel";
            this.communicationLinksHardwareItemKeyLabel.Size = new System.Drawing.Size(131, 17);
            this.communicationLinksHardwareItemKeyLabel.TabIndex = 88;
            this.communicationLinksHardwareItemKeyLabel.Text = "Hardware Item Key:";
            // 
            // communicationLinksVendorLabel
            // 
            this.communicationLinksVendorLabel.AutoSize = true;
            this.communicationLinksVendorLabel.Location = new System.Drawing.Point(8, 2);
            this.communicationLinksVendorLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinksVendorLabel.Name = "communicationLinksVendorLabel";
            this.communicationLinksVendorLabel.Size = new System.Drawing.Size(158, 17);
            this.communicationLinksVendorLabel.TabIndex = 93;
            this.communicationLinksVendorLabel.Text = "Communication Vendor:";
            // 
            // communicationLinksConnectivityAgreementLabel
            // 
            this.communicationLinksConnectivityAgreementLabel.AutoSize = true;
            this.communicationLinksConnectivityAgreementLabel.Location = new System.Drawing.Point(8, 199);
            this.communicationLinksConnectivityAgreementLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.communicationLinksConnectivityAgreementLabel.Name = "communicationLinksConnectivityAgreementLabel";
            this.communicationLinksConnectivityAgreementLabel.Size = new System.Drawing.Size(161, 17);
            this.communicationLinksConnectivityAgreementLabel.TabIndex = 89;
            this.communicationLinksConnectivityAgreementLabel.Text = "Connectivity Agreement:";
            // 
            // communicationLinksHardwareItemKeyTextBox
            // 
            this.communicationLinksHardwareItemKeyTextBox.Location = new System.Drawing.Point(180, 150);
            this.communicationLinksHardwareItemKeyTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinksHardwareItemKeyTextBox.MaxLength = 8;
            this.communicationLinksHardwareItemKeyTextBox.Name = "communicationLinksHardwareItemKeyTextBox";
            this.communicationLinksHardwareItemKeyTextBox.Size = new System.Drawing.Size(243, 23);
            this.communicationLinksHardwareItemKeyTextBox.TabIndex = 91;
            // 
            // communicationLinksSpeedTextBox
            // 
            this.communicationLinksSpeedTextBox.Location = new System.Drawing.Point(180, 101);
            this.communicationLinksSpeedTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.communicationLinksSpeedTextBox.MaxLength = 8;
            this.communicationLinksSpeedTextBox.Name = "communicationLinksSpeedTextBox";
            this.communicationLinksSpeedTextBox.Size = new System.Drawing.Size(243, 23);
            this.communicationLinksSpeedTextBox.TabIndex = 90;
            // 
            // communicationLinksButtonFlowLayoutPanel
            // 
            this.communicationLinksButtonFlowLayoutPanel.AutoSize = true;
            this.communicationLinksButtonFlowLayoutPanel.Controls.Add(this.addCommunicationLinksButton);
            this.communicationLinksButtonFlowLayoutPanel.Controls.Add(this.viewCommunicationLinksButton);
            this.communicationLinksButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.communicationLinksButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.communicationLinksButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.communicationLinksButtonFlowLayoutPanel.Name = "communicationLinksButtonFlowLayoutPanel";
            this.communicationLinksButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.communicationLinksButtonFlowLayoutPanel.TabIndex = 6;
            // 
            // addCommunicationLinksButton
            // 
            this.addCommunicationLinksButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addCommunicationLinksButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCommunicationLinksButton.Location = new System.Drawing.Point(4, 4);
            this.addCommunicationLinksButton.Margin = new System.Windows.Forms.Padding(4);
            this.addCommunicationLinksButton.Name = "addCommunicationLinksButton";
            this.addCommunicationLinksButton.Size = new System.Drawing.Size(133, 49);
            this.addCommunicationLinksButton.TabIndex = 1;
            this.addCommunicationLinksButton.Text = "Add";
            this.addCommunicationLinksButton.UseVisualStyleBackColor = false;
            this.addCommunicationLinksButton.Click += new System.EventHandler(this.addCommunicationLinksButton_Click);
            // 
            // viewCommunicationLinksButton
            // 
            this.viewCommunicationLinksButton.BackColor = System.Drawing.Color.Cyan;
            this.viewCommunicationLinksButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewCommunicationLinksButton.Location = new System.Drawing.Point(145, 4);
            this.viewCommunicationLinksButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewCommunicationLinksButton.Name = "viewCommunicationLinksButton";
            this.viewCommunicationLinksButton.Size = new System.Drawing.Size(133, 49);
            this.viewCommunicationLinksButton.TabIndex = 6;
            this.viewCommunicationLinksButton.Text = "View";
            this.viewCommunicationLinksButton.UseVisualStyleBackColor = false;
            this.viewCommunicationLinksButton.Click += new System.EventHandler(this.viewCommunicationLinksButton_Click);
            // 
            // supportAgreementsTab
            // 
            this.supportAgreementsTab.AutoScroll = true;
            this.supportAgreementsTab.Controls.Add(this.supportAgreementViewPanel);
            this.supportAgreementsTab.Controls.Add(this.addSupportAgreementGroupBox);
            this.supportAgreementsTab.Controls.Add(this.supportAgreementsButtonFlowLayoutPanel);
            this.supportAgreementsTab.ImageIndex = 7;
            this.supportAgreementsTab.Location = new System.Drawing.Point(4, 57);
            this.supportAgreementsTab.Margin = new System.Windows.Forms.Padding(4);
            this.supportAgreementsTab.Name = "supportAgreementsTab";
            this.supportAgreementsTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.supportAgreementsTab.Size = new System.Drawing.Size(1256, 594);
            this.supportAgreementsTab.TabIndex = 7;
            this.supportAgreementsTab.ToolTipText = "Tab for accessing all data manipulation of a support agreement entry";
            this.supportAgreementsTab.UseVisualStyleBackColor = true;
            // 
            // supportAgreementViewPanel
            // 
            this.supportAgreementViewPanel.AutoSize = true;
            this.supportAgreementViewPanel.Controls.Add(this.supportAgreementsGridView);
            this.supportAgreementViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.supportAgreementViewPanel.Location = new System.Drawing.Point(4, 4);
            this.supportAgreementViewPanel.Name = "supportAgreementViewPanel";
            this.supportAgreementViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.supportAgreementViewPanel.TabIndex = 10;
            // 
            // supportAgreementsGridView
            // 
            this.supportAgreementsGridView.AllowUserToAddRows = false;
            this.supportAgreementsGridView.AllowUserToDeleteRows = false;
            this.supportAgreementsGridView.AllowUserToOrderColumns = true;
            this.supportAgreementsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.supportAgreementsGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.supportAgreementsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.supportAgreementsGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.supportAgreementsGridView.Location = new System.Drawing.Point(0, 0);
            this.supportAgreementsGridView.Margin = new System.Windows.Forms.Padding(4);
            this.supportAgreementsGridView.Name = "supportAgreementsGridView";
            this.supportAgreementsGridView.ReadOnly = true;
            this.supportAgreementsGridView.Size = new System.Drawing.Size(1248, 501);
            this.supportAgreementsGridView.TabIndex = 7;
            this.supportAgreementsGridView.SelectionChanged += new System.EventHandler(this.SupportAgreementDataGridView_SelectionChanged);
            // 
            // addSupportAgreementGroupBox
            // 
            this.addSupportAgreementGroupBox.AutoSize = true;
            this.addSupportAgreementGroupBox.Controls.Add(this.addSupportAgreementPanel);
            this.addSupportAgreementGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addSupportAgreementGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addSupportAgreementGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addSupportAgreementGroupBox.Name = "addSupportAgreementGroupBox";
            this.addSupportAgreementGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addSupportAgreementGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addSupportAgreementGroupBox.TabIndex = 9;
            this.addSupportAgreementGroupBox.TabStop = false;
            this.addSupportAgreementGroupBox.Text = "Add Support Agreement";
            this.addSupportAgreementGroupBox.Visible = false;
            // 
            // addSupportAgreementPanel
            // 
            this.addSupportAgreementPanel.AutoScroll = true;
            this.addSupportAgreementPanel.AutoSize = true;
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementDescriptionLabel);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementDescriptionTextBox);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementStatusLabel);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementCommencedDateLabel);
            this.addSupportAgreementPanel.Controls.Add(this.saveSupportAgreementButton);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementExpiryDateLabel);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementNotesTextBox);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementLabel);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementExpiryDateTextBox);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementActiveRadioButton);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementCommencementDateTextBox);
            this.addSupportAgreementPanel.Controls.Add(this.supportAgreementInactiveRadioButton);
            this.addSupportAgreementPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addSupportAgreementPanel.Location = new System.Drawing.Point(4, 20);
            this.addSupportAgreementPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addSupportAgreementPanel.Name = "addSupportAgreementPanel";
            this.addSupportAgreementPanel.Size = new System.Drawing.Size(1240, 477);
            this.addSupportAgreementPanel.TabIndex = 61;
            // 
            // supportAgreementDescriptionLabel
            // 
            this.supportAgreementDescriptionLabel.AutoSize = true;
            this.supportAgreementDescriptionLabel.Location = new System.Drawing.Point(11, 15);
            this.supportAgreementDescriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.supportAgreementDescriptionLabel.Name = "supportAgreementDescriptionLabel";
            this.supportAgreementDescriptionLabel.Size = new System.Drawing.Size(156, 17);
            this.supportAgreementDescriptionLabel.TabIndex = 59;
            this.supportAgreementDescriptionLabel.Text = "Agreement Description:";
            // 
            // supportAgreementDescriptionTextBox
            // 
            this.supportAgreementDescriptionTextBox.Location = new System.Drawing.Point(183, 15);
            this.supportAgreementDescriptionTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.supportAgreementDescriptionTextBox.MaxLength = 30;
            this.supportAgreementDescriptionTextBox.Name = "supportAgreementDescriptionTextBox";
            this.supportAgreementDescriptionTextBox.Size = new System.Drawing.Size(243, 23);
            this.supportAgreementDescriptionTextBox.TabIndex = 60;
            // 
            // supportAgreementStatusLabel
            // 
            this.supportAgreementStatusLabel.AutoSize = true;
            this.supportAgreementStatusLabel.Location = new System.Drawing.Point(11, 64);
            this.supportAgreementStatusLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.supportAgreementStatusLabel.Name = "supportAgreementStatusLabel";
            this.supportAgreementStatusLabel.Size = new System.Drawing.Size(52, 17);
            this.supportAgreementStatusLabel.TabIndex = 49;
            this.supportAgreementStatusLabel.Text = "Status:";
            // 
            // supportAgreementCommencedDateLabel
            // 
            this.supportAgreementCommencedDateLabel.AutoSize = true;
            this.supportAgreementCommencedDateLabel.Location = new System.Drawing.Point(11, 113);
            this.supportAgreementCommencedDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.supportAgreementCommencedDateLabel.Name = "supportAgreementCommencedDateLabel";
            this.supportAgreementCommencedDateLabel.Size = new System.Drawing.Size(147, 17);
            this.supportAgreementCommencedDateLabel.TabIndex = 50;
            this.supportAgreementCommencedDateLabel.Text = "Commencement Date:";
            // 
            // saveSupportAgreementButton
            // 
            this.saveSupportAgreementButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveSupportAgreementButton.Location = new System.Drawing.Point(183, 261);
            this.saveSupportAgreementButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveSupportAgreementButton.Name = "saveSupportAgreementButton";
            this.saveSupportAgreementButton.Size = new System.Drawing.Size(75, 32);
            this.saveSupportAgreementButton.TabIndex = 58;
            this.saveSupportAgreementButton.Text = "Save";
            this.saveSupportAgreementButton.UseVisualStyleBackColor = false;
            // 
            // supportAgreementExpiryDateLabel
            // 
            this.supportAgreementExpiryDateLabel.AutoSize = true;
            this.supportAgreementExpiryDateLabel.Location = new System.Drawing.Point(11, 162);
            this.supportAgreementExpiryDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.supportAgreementExpiryDateLabel.Name = "supportAgreementExpiryDateLabel";
            this.supportAgreementExpiryDateLabel.Size = new System.Drawing.Size(84, 17);
            this.supportAgreementExpiryDateLabel.TabIndex = 51;
            this.supportAgreementExpiryDateLabel.Text = "Expiry Date:";
            // 
            // supportAgreementNotesTextBox
            // 
            this.supportAgreementNotesTextBox.Location = new System.Drawing.Point(183, 212);
            this.supportAgreementNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.supportAgreementNotesTextBox.MaxLength = 50;
            this.supportAgreementNotesTextBox.Name = "supportAgreementNotesTextBox";
            this.supportAgreementNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.supportAgreementNotesTextBox.TabIndex = 57;
            // 
            // supportAgreementLabel
            // 
            this.supportAgreementLabel.AutoSize = true;
            this.supportAgreementLabel.Location = new System.Drawing.Point(11, 212);
            this.supportAgreementLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.supportAgreementLabel.Name = "supportAgreementLabel";
            this.supportAgreementLabel.Size = new System.Drawing.Size(49, 17);
            this.supportAgreementLabel.TabIndex = 52;
            this.supportAgreementLabel.Text = "Notes:";
            // 
            // supportAgreementExpiryDateTextBox
            // 
            this.supportAgreementExpiryDateTextBox.Location = new System.Drawing.Point(183, 162);
            this.supportAgreementExpiryDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.supportAgreementExpiryDateTextBox.MaxLength = 8;
            this.supportAgreementExpiryDateTextBox.Name = "supportAgreementExpiryDateTextBox";
            this.supportAgreementExpiryDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.supportAgreementExpiryDateTextBox.TabIndex = 56;
            // 
            // supportAgreementActiveRadioButton
            // 
            this.supportAgreementActiveRadioButton.AutoSize = true;
            this.supportAgreementActiveRadioButton.Checked = true;
            this.supportAgreementActiveRadioButton.Location = new System.Drawing.Point(183, 64);
            this.supportAgreementActiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.supportAgreementActiveRadioButton.Name = "supportAgreementActiveRadioButton";
            this.supportAgreementActiveRadioButton.Size = new System.Drawing.Size(64, 21);
            this.supportAgreementActiveRadioButton.TabIndex = 53;
            this.supportAgreementActiveRadioButton.TabStop = true;
            this.supportAgreementActiveRadioButton.Text = "Active";
            this.supportAgreementActiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // supportAgreementCommencementDateTextBox
            // 
            this.supportAgreementCommencementDateTextBox.Location = new System.Drawing.Point(183, 113);
            this.supportAgreementCommencementDateTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.supportAgreementCommencementDateTextBox.MaxLength = 8;
            this.supportAgreementCommencementDateTextBox.Name = "supportAgreementCommencementDateTextBox";
            this.supportAgreementCommencementDateTextBox.Size = new System.Drawing.Size(243, 23);
            this.supportAgreementCommencementDateTextBox.TabIndex = 55;
            // 
            // supportAgreementInactiveRadioButton
            // 
            this.supportAgreementInactiveRadioButton.AutoSize = true;
            this.supportAgreementInactiveRadioButton.Location = new System.Drawing.Point(343, 64);
            this.supportAgreementInactiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.supportAgreementInactiveRadioButton.Name = "supportAgreementInactiveRadioButton";
            this.supportAgreementInactiveRadioButton.Size = new System.Drawing.Size(74, 21);
            this.supportAgreementInactiveRadioButton.TabIndex = 54;
            this.supportAgreementInactiveRadioButton.Text = "Inactive";
            this.supportAgreementInactiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // supportAgreementsButtonFlowLayoutPanel
            // 
            this.supportAgreementsButtonFlowLayoutPanel.AutoSize = true;
            this.supportAgreementsButtonFlowLayoutPanel.Controls.Add(this.addSupportAgreementsButton);
            this.supportAgreementsButtonFlowLayoutPanel.Controls.Add(this.viewSupportAgreementsButton);
            this.supportAgreementsButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.supportAgreementsButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.supportAgreementsButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.supportAgreementsButtonFlowLayoutPanel.Name = "supportAgreementsButtonFlowLayoutPanel";
            this.supportAgreementsButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.supportAgreementsButtonFlowLayoutPanel.TabIndex = 8;
            // 
            // addSupportAgreementsButton
            // 
            this.addSupportAgreementsButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addSupportAgreementsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addSupportAgreementsButton.Location = new System.Drawing.Point(4, 4);
            this.addSupportAgreementsButton.Margin = new System.Windows.Forms.Padding(4);
            this.addSupportAgreementsButton.Name = "addSupportAgreementsButton";
            this.addSupportAgreementsButton.Size = new System.Drawing.Size(133, 49);
            this.addSupportAgreementsButton.TabIndex = 1;
            this.addSupportAgreementsButton.Text = "Add";
            this.addSupportAgreementsButton.UseVisualStyleBackColor = false;
            this.addSupportAgreementsButton.Click += new System.EventHandler(this.addSupportAgreementsButton_Click);
            // 
            // viewSupportAgreementsButton
            // 
            this.viewSupportAgreementsButton.BackColor = System.Drawing.Color.Cyan;
            this.viewSupportAgreementsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewSupportAgreementsButton.Location = new System.Drawing.Point(145, 4);
            this.viewSupportAgreementsButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewSupportAgreementsButton.Name = "viewSupportAgreementsButton";
            this.viewSupportAgreementsButton.Size = new System.Drawing.Size(133, 49);
            this.viewSupportAgreementsButton.TabIndex = 4;
            this.viewSupportAgreementsButton.Text = "View";
            this.viewSupportAgreementsButton.UseVisualStyleBackColor = false;
            this.viewSupportAgreementsButton.Click += new System.EventHandler(this.viewSupportAgreementsButton_Click);
            // 
            // locationTab
            // 
            this.locationTab.AutoScroll = true;
            this.locationTab.Controls.Add(this.locationViewPanel);
            this.locationTab.Controls.Add(this.addLocationGroupBox);
            this.locationTab.Controls.Add(this.locationsButtonflowLayoutPanel);
            this.locationTab.ImageIndex = 8;
            this.locationTab.Location = new System.Drawing.Point(4, 57);
            this.locationTab.Margin = new System.Windows.Forms.Padding(4);
            this.locationTab.Name = "locationTab";
            this.locationTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.locationTab.Size = new System.Drawing.Size(1256, 594);
            this.locationTab.TabIndex = 8;
            this.locationTab.ToolTipText = "Tab for accessing all data manipulation of a locations entry";
            this.locationTab.UseVisualStyleBackColor = true;
            // 
            // locationViewPanel
            // 
            this.locationViewPanel.AutoSize = true;
            this.locationViewPanel.Controls.Add(this.locationsDataGridView);
            this.locationViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.locationViewPanel.Location = new System.Drawing.Point(4, 4);
            this.locationViewPanel.Name = "locationViewPanel";
            this.locationViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.locationViewPanel.TabIndex = 12;
            // 
            // locationsDataGridView
            // 
            this.locationsDataGridView.AllowUserToAddRows = false;
            this.locationsDataGridView.AllowUserToDeleteRows = false;
            this.locationsDataGridView.AllowUserToOrderColumns = true;
            this.locationsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.locationsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.locationsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.locationsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.locationsDataGridView.Location = new System.Drawing.Point(0, 0);
            this.locationsDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.locationsDataGridView.MultiSelect = false;
            this.locationsDataGridView.Name = "locationsDataGridView";
            this.locationsDataGridView.ReadOnly = true;
            this.locationsDataGridView.Size = new System.Drawing.Size(1248, 501);
            this.locationsDataGridView.TabIndex = 9;
            this.locationsDataGridView.SelectionChanged += new System.EventHandler(this.LocationDataGridView_SelectionChanged);
            // 
            // addLocationGroupBox
            // 
            this.addLocationGroupBox.AutoSize = true;
            this.addLocationGroupBox.Controls.Add(this.addLocationPanel);
            this.addLocationGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addLocationGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addLocationGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addLocationGroupBox.Name = "addLocationGroupBox";
            this.addLocationGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addLocationGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addLocationGroupBox.TabIndex = 11;
            this.addLocationGroupBox.TabStop = false;
            this.addLocationGroupBox.Text = "Add Location";
            this.addLocationGroupBox.Visible = false;
            // 
            // addLocationPanel
            // 
            this.addLocationPanel.AutoScroll = true;
            this.addLocationPanel.AutoSize = true;
            this.addLocationPanel.Controls.Add(this.locationDescriptionLabel);
            this.addLocationPanel.Controls.Add(this.saveLocationButton);
            this.addLocationPanel.Controls.Add(this.locationEnviromentLabel);
            this.addLocationPanel.Controls.Add(this.locationNotesTextBox);
            this.addLocationPanel.Controls.Add(this.locationNotesLabel);
            this.addLocationPanel.Controls.Add(this.locationEnviromentTextBox);
            this.addLocationPanel.Controls.Add(this.locationDescriptionTextBox);
            this.addLocationPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addLocationPanel.Location = new System.Drawing.Point(4, 20);
            this.addLocationPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addLocationPanel.Name = "addLocationPanel";
            this.addLocationPanel.Size = new System.Drawing.Size(1240, 477);
            this.addLocationPanel.TabIndex = 56;
            // 
            // locationDescriptionLabel
            // 
            this.locationDescriptionLabel.AutoSize = true;
            this.locationDescriptionLabel.Location = new System.Drawing.Point(4, 15);
            this.locationDescriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.locationDescriptionLabel.Name = "locationDescriptionLabel";
            this.locationDescriptionLabel.Size = new System.Drawing.Size(141, 17);
            this.locationDescriptionLabel.TabIndex = 49;
            this.locationDescriptionLabel.Text = "Location Description:";
            // 
            // saveLocationButton
            // 
            this.saveLocationButton.BackColor = System.Drawing.Color.LimeGreen;
            this.saveLocationButton.Location = new System.Drawing.Point(173, 159);
            this.saveLocationButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveLocationButton.Name = "saveLocationButton";
            this.saveLocationButton.Size = new System.Drawing.Size(75, 32);
            this.saveLocationButton.TabIndex = 55;
            this.saveLocationButton.Text = "Save";
            this.saveLocationButton.UseVisualStyleBackColor = false;
            // 
            // locationEnviromentLabel
            // 
            this.locationEnviromentLabel.AutoSize = true;
            this.locationEnviromentLabel.Location = new System.Drawing.Point(4, 64);
            this.locationEnviromentLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.locationEnviromentLabel.Name = "locationEnviromentLabel";
            this.locationEnviromentLabel.Size = new System.Drawing.Size(83, 17);
            this.locationEnviromentLabel.TabIndex = 50;
            this.locationEnviromentLabel.Text = "Enviroment:";
            // 
            // locationNotesTextBox
            // 
            this.locationNotesTextBox.Location = new System.Drawing.Point(173, 110);
            this.locationNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.locationNotesTextBox.MaxLength = 50;
            this.locationNotesTextBox.Name = "locationNotesTextBox";
            this.locationNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.locationNotesTextBox.TabIndex = 54;
            // 
            // locationNotesLabel
            // 
            this.locationNotesLabel.AutoSize = true;
            this.locationNotesLabel.Location = new System.Drawing.Point(4, 113);
            this.locationNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.locationNotesLabel.Name = "locationNotesLabel";
            this.locationNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.locationNotesLabel.TabIndex = 51;
            this.locationNotesLabel.Text = "Notes:";
            // 
            // locationEnviromentTextBox
            // 
            this.locationEnviromentTextBox.Location = new System.Drawing.Point(173, 60);
            this.locationEnviromentTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.locationEnviromentTextBox.MaxLength = 50;
            this.locationEnviromentTextBox.Name = "locationEnviromentTextBox";
            this.locationEnviromentTextBox.Size = new System.Drawing.Size(243, 23);
            this.locationEnviromentTextBox.TabIndex = 53;
            // 
            // locationDescriptionTextBox
            // 
            this.locationDescriptionTextBox.Location = new System.Drawing.Point(173, 11);
            this.locationDescriptionTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.locationDescriptionTextBox.MaxLength = 30;
            this.locationDescriptionTextBox.Name = "locationDescriptionTextBox";
            this.locationDescriptionTextBox.Size = new System.Drawing.Size(243, 23);
            this.locationDescriptionTextBox.TabIndex = 52;
            // 
            // locationsButtonflowLayoutPanel
            // 
            this.locationsButtonflowLayoutPanel.AutoSize = true;
            this.locationsButtonflowLayoutPanel.Controls.Add(this.addLocationButton);
            this.locationsButtonflowLayoutPanel.Controls.Add(this.viewLocationsButton);
            this.locationsButtonflowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.locationsButtonflowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.locationsButtonflowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.locationsButtonflowLayoutPanel.Name = "locationsButtonflowLayoutPanel";
            this.locationsButtonflowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.locationsButtonflowLayoutPanel.TabIndex = 10;
            // 
            // addLocationButton
            // 
            this.addLocationButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addLocationButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addLocationButton.Location = new System.Drawing.Point(4, 4);
            this.addLocationButton.Margin = new System.Windows.Forms.Padding(4);
            this.addLocationButton.Name = "addLocationButton";
            this.addLocationButton.Size = new System.Drawing.Size(133, 49);
            this.addLocationButton.TabIndex = 1;
            this.addLocationButton.Text = "Add";
            this.addLocationButton.UseVisualStyleBackColor = false;
            this.addLocationButton.Click += new System.EventHandler(this.addLocationButton_Click);
            // 
            // viewLocationsButton
            // 
            this.viewLocationsButton.BackColor = System.Drawing.Color.Cyan;
            this.viewLocationsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewLocationsButton.Location = new System.Drawing.Point(145, 4);
            this.viewLocationsButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewLocationsButton.Name = "viewLocationsButton";
            this.viewLocationsButton.Size = new System.Drawing.Size(133, 49);
            this.viewLocationsButton.TabIndex = 3;
            this.viewLocationsButton.Text = "View";
            this.viewLocationsButton.UseVisualStyleBackColor = false;
            this.viewLocationsButton.Click += new System.EventHandler(this.viewLocationsButton_Click);
            // 
            // snapshotsTab
            // 
            this.snapshotsTab.Controls.Add(this.snapshotViewPanel);
            this.snapshotsTab.Controls.Add(this.addSnapshotGroupBox);
            this.snapshotsTab.Controls.Add(this.snapshotsButtonFlowLayoutPanel);
            this.snapshotsTab.ImageIndex = 9;
            this.snapshotsTab.Location = new System.Drawing.Point(4, 57);
            this.snapshotsTab.Margin = new System.Windows.Forms.Padding(4);
            this.snapshotsTab.Name = "snapshotsTab";
            this.snapshotsTab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 32);
            this.snapshotsTab.Size = new System.Drawing.Size(1256, 594);
            this.snapshotsTab.TabIndex = 9;
            this.snapshotsTab.ToolTipText = "Tab for accessing all data manipulation of a snapshots entry";
            this.snapshotsTab.UseVisualStyleBackColor = true;
            // 
            // snapshotViewPanel
            // 
            this.snapshotViewPanel.AutoSize = true;
            this.snapshotViewPanel.Controls.Add(this.snapshotsDataGridView);
            this.snapshotViewPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.snapshotViewPanel.Location = new System.Drawing.Point(4, 4);
            this.snapshotViewPanel.Name = "snapshotViewPanel";
            this.snapshotViewPanel.Size = new System.Drawing.Size(1248, 501);
            this.snapshotViewPanel.TabIndex = 12;
            // 
            // snapshotsDataGridView
            // 
            this.snapshotsDataGridView.AllowUserToAddRows = false;
            this.snapshotsDataGridView.AllowUserToDeleteRows = false;
            this.snapshotsDataGridView.AllowUserToOrderColumns = true;
            this.snapshotsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.snapshotsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.snapshotsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.snapshotsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Status,
            this.DateCreated,
            this.DateHistoric,
            this.Notes});
            this.snapshotsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.snapshotsDataGridView.Location = new System.Drawing.Point(0, 0);
            this.snapshotsDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.snapshotsDataGridView.Name = "snapshotsDataGridView";
            this.snapshotsDataGridView.ReadOnly = true;
            this.snapshotsDataGridView.Size = new System.Drawing.Size(1248, 501);
            this.snapshotsDataGridView.TabIndex = 9;
            this.snapshotsDataGridView.SelectionChanged += new System.EventHandler(this.SnapshotDataGridView_SelectionChanged);
            // 
            // Status
            // 
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 73;
            // 
            // DateCreated
            // 
            this.DateCreated.HeaderText = "Date Created";
            this.DateCreated.Name = "DateCreated";
            this.DateCreated.ReadOnly = true;
            this.DateCreated.Width = 117;
            // 
            // DateHistoric
            // 
            this.DateHistoric.HeaderText = "Date Historic";
            this.DateHistoric.Name = "DateHistoric";
            this.DateHistoric.ReadOnly = true;
            this.DateHistoric.Width = 114;
            // 
            // Notes
            // 
            this.Notes.HeaderText = "Notes";
            this.Notes.Name = "Notes";
            this.Notes.ReadOnly = true;
            this.Notes.Width = 70;
            // 
            // addSnapshotGroupBox
            // 
            this.addSnapshotGroupBox.Controls.Add(this.addSnapshotPanel);
            this.addSnapshotGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addSnapshotGroupBox.Location = new System.Drawing.Point(4, 4);
            this.addSnapshotGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.addSnapshotGroupBox.Name = "addSnapshotGroupBox";
            this.addSnapshotGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.addSnapshotGroupBox.Size = new System.Drawing.Size(1248, 501);
            this.addSnapshotGroupBox.TabIndex = 11;
            this.addSnapshotGroupBox.TabStop = false;
            this.addSnapshotGroupBox.Text = "Add Snapshot";
            this.addSnapshotGroupBox.Visible = false;
            // 
            // addSnapshotPanel
            // 
            this.addSnapshotPanel.AutoScroll = true;
            this.addSnapshotPanel.AutoSize = true;
            this.addSnapshotPanel.Controls.Add(this.snapshotStatusLabel);
            this.addSnapshotPanel.Controls.Add(this.snapshotSaveButton);
            this.addSnapshotPanel.Controls.Add(this.snapshotDateCreatedLabel);
            this.addSnapshotPanel.Controls.Add(this.snapshotNotesTextBox);
            this.addSnapshotPanel.Controls.Add(this.snapshotDateHistoricLabel);
            this.addSnapshotPanel.Controls.Add(this.snapshotDateHistoricTextBox);
            this.addSnapshotPanel.Controls.Add(this.snapshotNotesLabel);
            this.addSnapshotPanel.Controls.Add(this.snapshotDateCreatedTextBox);
            this.addSnapshotPanel.Controls.Add(this.snapshotActiveRadioButton);
            this.addSnapshotPanel.Controls.Add(this.snapshotInactiveRadioButton);
            this.addSnapshotPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addSnapshotPanel.Location = new System.Drawing.Point(4, 20);
            this.addSnapshotPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addSnapshotPanel.Name = "addSnapshotPanel";
            this.addSnapshotPanel.Size = new System.Drawing.Size(1240, 477);
            this.addSnapshotPanel.TabIndex = 49;
            // 
            // snapshotStatusLabel
            // 
            this.snapshotStatusLabel.AutoSize = true;
            this.snapshotStatusLabel.Location = new System.Drawing.Point(4, 12);
            this.snapshotStatusLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.snapshotStatusLabel.Name = "snapshotStatusLabel";
            this.snapshotStatusLabel.Size = new System.Drawing.Size(52, 17);
            this.snapshotStatusLabel.TabIndex = 39;
            this.snapshotStatusLabel.Text = "Status:";
            // 
            // snapshotSaveButton
            // 
            this.snapshotSaveButton.BackColor = System.Drawing.Color.LimeGreen;
            this.snapshotSaveButton.Location = new System.Drawing.Point(139, 209);
            this.snapshotSaveButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.snapshotSaveButton.Name = "snapshotSaveButton";
            this.snapshotSaveButton.Size = new System.Drawing.Size(75, 32);
            this.snapshotSaveButton.TabIndex = 48;
            this.snapshotSaveButton.Text = "Save";
            this.snapshotSaveButton.UseVisualStyleBackColor = false;
            // 
            // snapshotDateCreatedLabel
            // 
            this.snapshotDateCreatedLabel.AutoSize = true;
            this.snapshotDateCreatedLabel.Location = new System.Drawing.Point(4, 62);
            this.snapshotDateCreatedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.snapshotDateCreatedLabel.Name = "snapshotDateCreatedLabel";
            this.snapshotDateCreatedLabel.Size = new System.Drawing.Size(96, 17);
            this.snapshotDateCreatedLabel.TabIndex = 40;
            this.snapshotDateCreatedLabel.Text = "Date Created:";
            // 
            // snapshotNotesTextBox
            // 
            this.snapshotNotesTextBox.Location = new System.Drawing.Point(139, 160);
            this.snapshotNotesTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.snapshotNotesTextBox.MaxLength = 50;
            this.snapshotNotesTextBox.Name = "snapshotNotesTextBox";
            this.snapshotNotesTextBox.Size = new System.Drawing.Size(243, 23);
            this.snapshotNotesTextBox.TabIndex = 47;
            // 
            // snapshotDateHistoricLabel
            // 
            this.snapshotDateHistoricLabel.AutoSize = true;
            this.snapshotDateHistoricLabel.Location = new System.Drawing.Point(4, 111);
            this.snapshotDateHistoricLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.snapshotDateHistoricLabel.Name = "snapshotDateHistoricLabel";
            this.snapshotDateHistoricLabel.Size = new System.Drawing.Size(93, 17);
            this.snapshotDateHistoricLabel.TabIndex = 41;
            this.snapshotDateHistoricLabel.Text = "Date Historic:";
            // 
            // snapshotDateHistoricTextBox
            // 
            this.snapshotDateHistoricTextBox.Location = new System.Drawing.Point(139, 111);
            this.snapshotDateHistoricTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.snapshotDateHistoricTextBox.MaxLength = 8;
            this.snapshotDateHistoricTextBox.Name = "snapshotDateHistoricTextBox";
            this.snapshotDateHistoricTextBox.Size = new System.Drawing.Size(243, 23);
            this.snapshotDateHistoricTextBox.TabIndex = 46;
            // 
            // snapshotNotesLabel
            // 
            this.snapshotNotesLabel.AutoSize = true;
            this.snapshotNotesLabel.Location = new System.Drawing.Point(4, 160);
            this.snapshotNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.snapshotNotesLabel.Name = "snapshotNotesLabel";
            this.snapshotNotesLabel.Size = new System.Drawing.Size(49, 17);
            this.snapshotNotesLabel.TabIndex = 42;
            this.snapshotNotesLabel.Text = "Notes:";
            // 
            // snapshotDateCreatedTextBox
            // 
            this.snapshotDateCreatedTextBox.Location = new System.Drawing.Point(139, 62);
            this.snapshotDateCreatedTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.snapshotDateCreatedTextBox.MaxLength = 8;
            this.snapshotDateCreatedTextBox.Name = "snapshotDateCreatedTextBox";
            this.snapshotDateCreatedTextBox.Size = new System.Drawing.Size(243, 23);
            this.snapshotDateCreatedTextBox.TabIndex = 45;
            // 
            // snapshotActiveRadioButton
            // 
            this.snapshotActiveRadioButton.AutoSize = true;
            this.snapshotActiveRadioButton.Checked = true;
            this.snapshotActiveRadioButton.Location = new System.Drawing.Point(139, 12);
            this.snapshotActiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.snapshotActiveRadioButton.Name = "snapshotActiveRadioButton";
            this.snapshotActiveRadioButton.Size = new System.Drawing.Size(64, 21);
            this.snapshotActiveRadioButton.TabIndex = 43;
            this.snapshotActiveRadioButton.TabStop = true;
            this.snapshotActiveRadioButton.Text = "Active";
            this.snapshotActiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // snapshotInactiveRadioButton
            // 
            this.snapshotInactiveRadioButton.AutoSize = true;
            this.snapshotInactiveRadioButton.Location = new System.Drawing.Point(299, 12);
            this.snapshotInactiveRadioButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.snapshotInactiveRadioButton.Name = "snapshotInactiveRadioButton";
            this.snapshotInactiveRadioButton.Size = new System.Drawing.Size(74, 21);
            this.snapshotInactiveRadioButton.TabIndex = 44;
            this.snapshotInactiveRadioButton.Text = "Inactive";
            this.snapshotInactiveRadioButton.UseVisualStyleBackColor = true;
            // 
            // snapshotsButtonFlowLayoutPanel
            // 
            this.snapshotsButtonFlowLayoutPanel.AutoSize = true;
            this.snapshotsButtonFlowLayoutPanel.Controls.Add(this.addSnapshotsButton);
            this.snapshotsButtonFlowLayoutPanel.Controls.Add(this.snapshotsViewButton);
            this.snapshotsButtonFlowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.snapshotsButtonFlowLayoutPanel.Location = new System.Drawing.Point(4, 505);
            this.snapshotsButtonFlowLayoutPanel.Margin = new System.Windows.Forms.Padding(4);
            this.snapshotsButtonFlowLayoutPanel.MaximumSize = new System.Drawing.Size(0, 62);
            this.snapshotsButtonFlowLayoutPanel.Name = "snapshotsButtonFlowLayoutPanel";
            this.snapshotsButtonFlowLayoutPanel.Size = new System.Drawing.Size(1248, 57);
            this.snapshotsButtonFlowLayoutPanel.TabIndex = 10;
            this.snapshotsButtonFlowLayoutPanel.WrapContents = false;
            // 
            // addSnapshotsButton
            // 
            this.addSnapshotsButton.BackColor = System.Drawing.Color.LimeGreen;
            this.addSnapshotsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addSnapshotsButton.Location = new System.Drawing.Point(4, 4);
            this.addSnapshotsButton.Margin = new System.Windows.Forms.Padding(4);
            this.addSnapshotsButton.Name = "addSnapshotsButton";
            this.addSnapshotsButton.Size = new System.Drawing.Size(133, 49);
            this.addSnapshotsButton.TabIndex = 1;
            this.addSnapshotsButton.Text = "Add";
            this.addSnapshotsButton.UseVisualStyleBackColor = false;
            this.addSnapshotsButton.Click += new System.EventHandler(this.addSnapshotsButton_Click);
            // 
            // snapshotsViewButton
            // 
            this.snapshotsViewButton.BackColor = System.Drawing.Color.Cyan;
            this.snapshotsViewButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snapshotsViewButton.Location = new System.Drawing.Point(145, 4);
            this.snapshotsViewButton.Margin = new System.Windows.Forms.Padding(4);
            this.snapshotsViewButton.Name = "snapshotsViewButton";
            this.snapshotsViewButton.Size = new System.Drawing.Size(133, 49);
            this.snapshotsViewButton.TabIndex = 2;
            this.snapshotsViewButton.Text = "View";
            this.snapshotsViewButton.UseVisualStyleBackColor = false;
            this.snapshotsViewButton.Click += new System.EventHandler(this.snapshotsViewButton_Click);
            // 
            // tabImageList
            // 
            this.tabImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("tabImageList.ImageStream")));
            this.tabImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.tabImageList.Images.SetKeyName(0, "Client.jpg");
            this.tabImageList.Images.SetKeyName(1, "Hardware.png");
            this.tabImageList.Images.SetKeyName(2, "Licenses.png");
            this.tabImageList.Images.SetKeyName(3, "Staff.png");
            this.tabImageList.Images.SetKeyName(4, "Email Address.png");
            this.tabImageList.Images.SetKeyName(5, "Warranty.png");
            this.tabImageList.Images.SetKeyName(6, "Communication Link.png");
            this.tabImageList.Images.SetKeyName(7, "Support Agreement.png");
            this.tabImageList.Images.SetKeyName(8, "Location.png");
            this.tabImageList.Images.SetKeyName(9, "Snapshot.png");
            this.tabImageList.Images.SetKeyName(10, "Allocate.png");
            this.tabImageList.Images.SetKeyName(11, "Unallocated.png");
            // 
            // selectedClientNameBox
            // 
            this.selectedClientNameBox.Location = new System.Drawing.Point(55, 4);
            this.selectedClientNameBox.Margin = new System.Windows.Forms.Padding(4);
            this.selectedClientNameBox.Name = "selectedClientNameBox";
            this.selectedClientNameBox.ReadOnly = true;
            this.selectedClientNameBox.Size = new System.Drawing.Size(239, 23);
            this.selectedClientNameBox.TabIndex = 8;
            this.selectedClientNameBox.Text = "<selected client Name here>";
            // 
            // selectedClientLabel
            // 
            this.selectedClientLabel.AutoSize = true;
            this.selectedClientLabel.Location = new System.Drawing.Point(4, 0);
            this.selectedClientLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectedClientLabel.Name = "selectedClientLabel";
            this.selectedClientLabel.Size = new System.Drawing.Size(43, 17);
            this.selectedClientLabel.TabIndex = 9;
            this.selectedClientLabel.Text = "Client";
            this.selectedClientLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // selectedFlowPanel
            // 
            this.selectedFlowPanel.AutoSize = true;
            this.selectedFlowPanel.BackColor = System.Drawing.SystemColors.Control;
            this.selectedFlowPanel.Controls.Add(this.selectedClientLabel);
            this.selectedFlowPanel.Controls.Add(this.selectedClientNameBox);
            this.selectedFlowPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.selectedFlowPanel.Location = new System.Drawing.Point(0, 651);
            this.selectedFlowPanel.Margin = new System.Windows.Forms.Padding(4);
            this.selectedFlowPanel.Name = "selectedFlowPanel";
            this.selectedFlowPanel.Size = new System.Drawing.Size(1264, 31);
            this.selectedFlowPanel.TabIndex = 9;
            this.selectedFlowPanel.WrapContents = false;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // hardwareTableAdapter
            // 
            this.hardwareTableAdapter.ClearBeforeFill = true;
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1264, 682);
            this.Controls.Add(this.selectedFlowPanel);
            this.Controls.Add(this.dataSelectionTabs);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "MainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SnapShot";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainScreen_FormClosed);
            this.Load += new System.EventHandler(this.MainScreen_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.dataSelectionTabs.ResumeLayout(false);
            this.clientsTab.ResumeLayout(false);
            this.clientsTab.PerformLayout();
            this.clientViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.clientDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.snapShot_DBDataSet)).EndInit();
            this.addclientGroupBox.ResumeLayout(false);
            this.addclientGroupBox.PerformLayout();
            this.addClientPanel.ResumeLayout(false);
            this.addClientPanel.PerformLayout();
            this.clientButtonFlowLayoutPanel.ResumeLayout(false);
            this.hardwareTab.ResumeLayout(false);
            this.hardwareTab.PerformLayout();
            this.hardwareViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hardwareDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareBindingSource)).EndInit();
            this.addHardwareGroupBox.ResumeLayout(false);
            this.addHardwareGroupBox.PerformLayout();
            this.addHardwarePanel.ResumeLayout(false);
            this.addHardwarePanel.PerformLayout();
            this.hardwareButtonFlowLayoutPanel.ResumeLayout(false);
            this.licenseTab.ResumeLayout(false);
            this.licenseTab.PerformLayout();
            this.licenseViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.licensesDataGridView)).EndInit();
            this.addLicenseGroupBox.ResumeLayout(false);
            this.addLicenseGroupBox.PerformLayout();
            this.addLicensePanel.ResumeLayout(false);
            this.addLicensePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.licensesAllocatedNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensesPurchasedNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licenseQuantityNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.licensePackCoreNumericUpDown)).EndInit();
            this.licensesButtonFlowLayoutPanel.ResumeLayout(false);
            this.usersTab.ResumeLayout(false);
            this.usersTab.PerformLayout();
            this.userViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.usersDataGridView)).EndInit();
            this.addUsersGroupBox.ResumeLayout(false);
            this.addUsersGroupBox.PerformLayout();
            this.addUserPanel.ResumeLayout(false);
            this.addUserPanel.PerformLayout();
            this.userButtonFlowLayoutPanel.ResumeLayout(false);
            this.emailAddressesTab.ResumeLayout(false);
            this.emailAddressesTab.PerformLayout();
            this.emailAddressViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.emailAddressesGridView)).EndInit();
            this.addEmailAddressGroupBox.ResumeLayout(false);
            this.addEmailAddressGroupBox.PerformLayout();
            this.addEmailAddressPanel.ResumeLayout(false);
            this.addEmailAddressPanel.PerformLayout();
            this.emailAddressesButtonFlowLayoutPanel.ResumeLayout(false);
            this.warrantiesTab.ResumeLayout(false);
            this.warrantiesTab.PerformLayout();
            this.warrantyViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.warrantiesGridView)).EndInit();
            this.addWarrantyGroupBox.ResumeLayout(false);
            this.addWarrantyGroupBox.PerformLayout();
            this.addWarrantyPanel.ResumeLayout(false);
            this.addWarrantyPanel.PerformLayout();
            this.warrantiesButtonFlowLayoutPanel.ResumeLayout(false);
            this.communicationLinksTab.ResumeLayout(false);
            this.communicationLinksTab.PerformLayout();
            this.communicationLinkViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.communicationLinksGridView)).EndInit();
            this.addCommunicationsLinkGroupBox.ResumeLayout(false);
            this.addCommunicationsLinkGroupBox.PerformLayout();
            this.addCommunicationLinkPanel.ResumeLayout(false);
            this.addCommunicationLinkPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.communicationLinkTermNumericUpDown)).EndInit();
            this.communicationLinksButtonFlowLayoutPanel.ResumeLayout(false);
            this.supportAgreementsTab.ResumeLayout(false);
            this.supportAgreementsTab.PerformLayout();
            this.supportAgreementViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.supportAgreementsGridView)).EndInit();
            this.addSupportAgreementGroupBox.ResumeLayout(false);
            this.addSupportAgreementGroupBox.PerformLayout();
            this.addSupportAgreementPanel.ResumeLayout(false);
            this.addSupportAgreementPanel.PerformLayout();
            this.supportAgreementsButtonFlowLayoutPanel.ResumeLayout(false);
            this.locationTab.ResumeLayout(false);
            this.locationTab.PerformLayout();
            this.locationViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.locationsDataGridView)).EndInit();
            this.addLocationGroupBox.ResumeLayout(false);
            this.addLocationGroupBox.PerformLayout();
            this.addLocationPanel.ResumeLayout(false);
            this.addLocationPanel.PerformLayout();
            this.locationsButtonflowLayoutPanel.ResumeLayout(false);
            this.snapshotsTab.ResumeLayout(false);
            this.snapshotsTab.PerformLayout();
            this.snapshotViewPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.snapshotsDataGridView)).EndInit();
            this.addSnapshotGroupBox.ResumeLayout(false);
            this.addSnapshotGroupBox.PerformLayout();
            this.addSnapshotPanel.ResumeLayout(false);
            this.addSnapshotPanel.PerformLayout();
            this.snapshotsButtonFlowLayoutPanel.ResumeLayout(false);
            this.selectedFlowPanel.ResumeLayout(false);
            this.selectedFlowPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newClientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem1;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.TabControl dataSelectionTabs;
        private System.Windows.Forms.TabPage emailAddressesTab;
        private System.Windows.Forms.TabPage warrantiesTab;
        private System.Windows.Forms.TabPage communicationLinksTab;
        private System.Windows.Forms.TabPage supportAgreementsTab;
        private System.Windows.Forms.FlowLayoutPanel emailAddressesButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addEmailAddressesButton;
        private System.Windows.Forms.FlowLayoutPanel warrantiesButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addWarrantiesButton;
        private System.Windows.Forms.DataGridView warrantiesGridView;
        private System.Windows.Forms.FlowLayoutPanel communicationLinksButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addCommunicationLinksButton;
        private System.Windows.Forms.DataGridView communicationLinksGridView;
        private System.Windows.Forms.FlowLayoutPanel supportAgreementsButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addSupportAgreementsButton;
        private System.Windows.Forms.DataGridView supportAgreementsGridView;
        private System.Windows.Forms.TabPage locationTab;
        private System.Windows.Forms.FlowLayoutPanel locationsButtonflowLayoutPanel;
        private System.Windows.Forms.Button addLocationButton;
        private System.Windows.Forms.DataGridView locationsDataGridView;
        private System.Windows.Forms.TabPage snapshotsTab;
        private System.Windows.Forms.FlowLayoutPanel snapshotsButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addSnapshotsButton;
        private System.Windows.Forms.DataGridView snapshotsDataGridView;
        private System.Windows.Forms.TextBox selectedClientNameBox;
        private System.Windows.Forms.Label selectedClientLabel;
        private System.Windows.Forms.FlowLayoutPanel selectedFlowPanel;
        private System.Windows.Forms.GroupBox addSnapshotGroupBox;
        private System.Windows.Forms.Button snapshotsViewButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCreated;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateHistoric;
        private System.Windows.Forms.DataGridViewTextBoxColumn Notes;
        private System.Windows.Forms.Button snapshotSaveButton;
        private System.Windows.Forms.TextBox snapshotNotesTextBox;
        private System.Windows.Forms.TextBox snapshotDateHistoricTextBox;
        private System.Windows.Forms.TextBox snapshotDateCreatedTextBox;
        private System.Windows.Forms.RadioButton snapshotInactiveRadioButton;
        private System.Windows.Forms.RadioButton snapshotActiveRadioButton;
        private System.Windows.Forms.Label snapshotNotesLabel;
        private System.Windows.Forms.Label snapshotDateHistoricLabel;
        private System.Windows.Forms.Label snapshotDateCreatedLabel;
        private System.Windows.Forms.Label snapshotStatusLabel;
        private System.Windows.Forms.GroupBox addLocationGroupBox;
        private System.Windows.Forms.Button viewLocationsButton;
        private System.Windows.Forms.Button saveLocationButton;
        private System.Windows.Forms.TextBox locationNotesTextBox;
        private System.Windows.Forms.TextBox locationEnviromentTextBox;
        private System.Windows.Forms.TextBox locationDescriptionTextBox;
        private System.Windows.Forms.Label locationNotesLabel;
        private System.Windows.Forms.Label locationEnviromentLabel;
        private System.Windows.Forms.Label locationDescriptionLabel;
        private System.Windows.Forms.GroupBox addSupportAgreementGroupBox;
        private System.Windows.Forms.Button viewSupportAgreementsButton;
        private System.Windows.Forms.Button saveSupportAgreementButton;
        private System.Windows.Forms.TextBox supportAgreementNotesTextBox;
        private System.Windows.Forms.TextBox supportAgreementExpiryDateTextBox;
        private System.Windows.Forms.TextBox supportAgreementCommencementDateTextBox;
        private System.Windows.Forms.RadioButton supportAgreementInactiveRadioButton;
        private System.Windows.Forms.RadioButton supportAgreementActiveRadioButton;
        private System.Windows.Forms.Label supportAgreementLabel;
        private System.Windows.Forms.Label supportAgreementExpiryDateLabel;
        private System.Windows.Forms.Label supportAgreementCommencedDateLabel;
        private System.Windows.Forms.Label supportAgreementStatusLabel;
        private System.Windows.Forms.TextBox supportAgreementDescriptionTextBox;
        private System.Windows.Forms.Label supportAgreementDescriptionLabel;
        private System.Windows.Forms.GroupBox addWarrantyGroupBox;
        private System.Windows.Forms.Button viewWarrantiesButton;
        private System.Windows.Forms.RadioButton warrantyStatusInactiveRadioButton;
        private System.Windows.Forms.RadioButton warrantyStatusActiveRadioButton;
        private System.Windows.Forms.Label warrantyStatusLabel;
        private System.Windows.Forms.TextBox warrantyTypeTextBox;
        private System.Windows.Forms.Label warrantyHardwareItemKeyLabel;
        private System.Windows.Forms.Label warrantyTypeLabel;
        private System.Windows.Forms.TextBox warrantyTicketNumberTextBox;
        private System.Windows.Forms.TextBox warrantyQuoteRefTextBox;
        private System.Windows.Forms.Label warrantyTicketNumberLabel;
        private System.Windows.Forms.Label warrantyQuoteRefLabel;
        private System.Windows.Forms.Button saveWarrantyButton;
        private System.Windows.Forms.TextBox warrantyNotesTextBox;
        private System.Windows.Forms.TextBox warrantyExpiryDateTextBox;
        private System.Windows.Forms.TextBox warrantyStartDateTextBox;
        private System.Windows.Forms.Label warrantyNotesLabel;
        private System.Windows.Forms.Label warrantyExpiryDateLabel;
        private System.Windows.Forms.Label warrantyStartDateLabel;
        private System.Windows.Forms.TextBox warrantyHardwareItemKeyTextBox;
        private System.Windows.Forms.GroupBox addCommunicationsLinkGroupBox;
        private System.Windows.Forms.TextBox communicationLinkExpiryDateTextBox;
        private System.Windows.Forms.Label communicationLinkExpiryDateLabel;
        private System.Windows.Forms.TextBox communicationLinksTypeTextBox;
        private System.Windows.Forms.TextBox communicationLinksVendorTextBox;
        private System.Windows.Forms.Label communicationLinksTypeLabel;
        private System.Windows.Forms.Label communicationLinksVendorLabel;
        private System.Windows.Forms.TextBox communicationLinksHardwareItemKeyTextBox;
        private System.Windows.Forms.TextBox communicationLinksSpeedTextBox;
        private System.Windows.Forms.Label communicationLinksConnectivityAgreementLabel;
        private System.Windows.Forms.Label communicationLinksHardwareItemKeyLabel;
        private System.Windows.Forms.Label communicationLinksSpeedLabel;
        private System.Windows.Forms.Button saveCommunicationLinkButton;
        private System.Windows.Forms.TextBox communicationLinkNotesTextBox;
        private System.Windows.Forms.TextBox communicationLinkCommencementDateTextBox;
        private System.Windows.Forms.Label communicationLinkNotesLabel;
        private System.Windows.Forms.Label communicationLinkTermLabel;
        private System.Windows.Forms.Label communicationLinkCommencementDateLabel;
        private System.Windows.Forms.Button viewCommunicationLinksButton;
        private System.Windows.Forms.RadioButton communicationLinksConnectivityAgreementInactiveRadioButton;
        private System.Windows.Forms.RadioButton communicationLinksConnectivityAgreementActiveRadioButton;
        private System.Windows.Forms.NumericUpDown communicationLinkTermNumericUpDown;
        private System.Windows.Forms.Button viewEmailAddressessButton;
        private System.Windows.Forms.GroupBox addEmailAddressGroupBox;
        private System.Windows.Forms.Panel addEmailAddressPanel;
        private System.Windows.Forms.Button saveEmailAddressButton;
        private System.Windows.Forms.TextBox emailAddressNotesTextBox;
        private System.Windows.Forms.TextBox emailAddressMailboxTypeTextBox;
        private System.Windows.Forms.TextBox emailAddressTextBox;
        private System.Windows.Forms.Label emailAddressNotesLabel;
        private System.Windows.Forms.Label emailAddressMailboxTypeLabel;
        private System.Windows.Forms.Label emailAddressLabel;
        private System.Windows.Forms.ImageList tabImageList;
        private System.Windows.Forms.Panel addWarrantyPanel;
        private System.Windows.Forms.Panel addCommunicationLinkPanel;
        private System.Windows.Forms.Panel addSupportAgreementPanel;
        private System.Windows.Forms.Panel addLocationPanel;
        private System.Windows.Forms.Panel addSnapshotPanel;
        private System.Windows.Forms.Panel warrantyViewPanel;
        private System.Windows.Forms.Panel communicationLinkViewPanel;
        private System.Windows.Forms.Panel supportAgreementViewPanel;
        private System.Windows.Forms.Panel locationViewPanel;
        private System.Windows.Forms.Panel snapshotViewPanel;
        private SnapShot_DBDataSet snapShot_DBDataSet;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private SnapShot_DBDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.TabPage clientsTab;
        private System.Windows.Forms.Panel clientViewPanel;
        private System.Windows.Forms.DataGridView clientDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientkeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn businessnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn streetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suburbDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn postcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn billingnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn statusDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn notesDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox addclientGroupBox;
        private System.Windows.Forms.Panel addClientPanel;
        private System.Windows.Forms.TextBox clientAddressLine3TextBox;
        private System.Windows.Forms.Button saveClientButton;
        private System.Windows.Forms.Label clientBussinessNameLabel;
        private System.Windows.Forms.TextBox clientNotesTextBox;
        private System.Windows.Forms.TextBox clientBusinessNameTextBox;
        private System.Windows.Forms.Label clientNotesLabel;
        private System.Windows.Forms.Label clientAddressLineLabel;
        private System.Windows.Forms.RadioButton clientInactiveStatusRadioButton;
        private System.Windows.Forms.TextBox clientAddressLine1TextBox;
        private System.Windows.Forms.RadioButton clientActiveStatusRadioButton;
        private System.Windows.Forms.Label clientAddressLine2Label;
        private System.Windows.Forms.Label clientStatusLabel;
        private System.Windows.Forms.TextBox clientAddressLine2TextBox;
        private System.Windows.Forms.TextBox clientBillingNameTextBox;
        private System.Windows.Forms.Label clientAddressLine3Label;
        private System.Windows.Forms.Label clientBillingNameLabel;
        private System.Windows.Forms.Label clientAddressLine4Label;
        private System.Windows.Forms.TextBox clientAddressLine4TextBox;
        private System.Windows.Forms.TabPage hardwareTab;
        private System.Windows.Forms.Panel hardwareViewPanel;
        private System.Windows.Forms.DataGridView hardwareDataGridView;
        private System.Windows.Forms.GroupBox addHardwareGroupBox;
        private System.Windows.Forms.Panel addHardwarePanel;
        private System.Windows.Forms.Label hardwareClientAssetNumberLabel;
        private System.Windows.Forms.TextBox hardwareDateWrittenOffTextBox;
        private System.Windows.Forms.Label hardwareDatePurchasedLabel;
        private System.Windows.Forms.Label hardwareDateWrittenOffLabel;
        private System.Windows.Forms.Label hardwareWarrantyExpiryLabel;
        private System.Windows.Forms.TextBox hardwareDeviceNameTextBox;
        private System.Windows.Forms.Label hardwareNotesLabel;
        private System.Windows.Forms.TextBox hardwareVendorTextBox;
        private System.Windows.Forms.TextBox hardwareDatePurchasedTextBox;
        private System.Windows.Forms.TextBox hardwareCategoryCodeTextBox;
        private System.Windows.Forms.TextBox hardwareWarrantyExpiryTextBox;
        private System.Windows.Forms.Label hardwareDeviceNameLabel;
        private System.Windows.Forms.TextBox hardwareNotesTextBox;
        private System.Windows.Forms.Label hardwareVendorLabel;
        private System.Windows.Forms.Button saveHardwareButton;
        private System.Windows.Forms.Label hardwareCategoryCodeLabel;
        private System.Windows.Forms.Label hardwareModelLabel;
        private System.Windows.Forms.TextBox hardwareClientAssetNumberTextBox;
        private System.Windows.Forms.Label hardwareSerialNumberLabel;
        private System.Windows.Forms.TextBox hardwareSerialNumberTextBox;
        private System.Windows.Forms.TextBox hardwareModelTextBox;
        private System.Windows.Forms.FlowLayoutPanel hardwareButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addHardwareButton;
        private System.Windows.Forms.Button viewHardwareButton;
        private System.Windows.Forms.TabPage licenseTab;
        private System.Windows.Forms.Panel licenseViewPanel;
        private System.Windows.Forms.DataGridView licensesDataGridView;
        private System.Windows.Forms.GroupBox addLicenseGroupBox;
        private System.Windows.Forms.Panel addLicensePanel;
        private System.Windows.Forms.NumericUpDown licensesAllocatedNumericUpDown;
        private System.Windows.Forms.NumericUpDown licensesPurchasedNumericUpDown;
        private System.Windows.Forms.NumericUpDown licenseQuantityNumericUpDown;
        private System.Windows.Forms.NumericUpDown licensePackCoreNumericUpDown;
        private System.Windows.Forms.TextBox licenseCodeOffsetTextBox;
        private System.Windows.Forms.TextBox licenseTicketNumberTextBox;
        private System.Windows.Forms.Label licenseTicketNumberLabel;
        private System.Windows.Forms.Label licensesPurchasedLabel;
        private System.Windows.Forms.Button saveLicenseButton;
        private System.Windows.Forms.Label licenseSubscriptionTypeLabel;
        private System.Windows.Forms.TextBox licenseNotesTextBox;
        private System.Windows.Forms.TextBox licenseQuoteRefTextBox;
        private System.Windows.Forms.TextBox licenseExpiryDateTextBox;
        private System.Windows.Forms.TextBox licenseDatePurchasedTextBox;
        private System.Windows.Forms.Label licensePackCoreLabel;
        private System.Windows.Forms.Label licenseNotesLabel;
        private System.Windows.Forms.TextBox licenseVendorAllocatedKeyTextBox;
        private System.Windows.Forms.Label licenseExpiryDateLabel;
        private System.Windows.Forms.Label licenseQuantityLabel;
        private System.Windows.Forms.Label licenseDatePurchasedLabel;
        private System.Windows.Forms.TextBox licenseSubscriptionTypeTextBox;
        private System.Windows.Forms.Label licenseQuoteRefLabel;
        private System.Windows.Forms.Label licenseVendorAllocatedKeyLabel;
        private System.Windows.Forms.Label licensesAllocatedLabel;
        private System.Windows.Forms.Label licenseCodeOffsetLabel;
        private System.Windows.Forms.Label licenseCategoryLabel;
        private System.Windows.Forms.Label licenseProductDescriptionLabel;
        private System.Windows.Forms.TextBox licenseCategoryTextBox;
        private System.Windows.Forms.TextBox licenseProductDescriptionTextBox;
        private System.Windows.Forms.FlowLayoutPanel licensesButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addLicenseButton;
        private System.Windows.Forms.Button viewLicensesbutton;
        private System.Windows.Forms.TabPage usersTab;
        private System.Windows.Forms.Panel userViewPanel;
        private System.Windows.Forms.DataGridView usersDataGridView;
        private System.Windows.Forms.GroupBox addUsersGroupBox;
        private System.Windows.Forms.Panel addUserPanel;
        private System.Windows.Forms.TextBox userSuspendedDateTextBox;
        private System.Windows.Forms.Label userSuspendedDateLabel;
        private System.Windows.Forms.Button saveUserButton;
        private System.Windows.Forms.TextBox userNotesTextBox;
        private System.Windows.Forms.TextBox userTerminationDateTextBox;
        private System.Windows.Forms.TextBox userCommencementDateTextBox;
        private System.Windows.Forms.TextBox user1stNameTextBox;
        private System.Windows.Forms.Label userNotesLabel;
        private System.Windows.Forms.TextBox userSurnameTextBox;
        private System.Windows.Forms.Label userCommencementDateLabel;
        private System.Windows.Forms.Label user1stNameLabel;
        private System.Windows.Forms.Label userTerminationDateLabel;
        private System.Windows.Forms.Label userSurnameLabel;
        private System.Windows.Forms.FlowLayoutPanel userButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addUserButton;
        private System.Windows.Forms.Button viewUsersButton;
        private System.Windows.Forms.Panel emailAddressViewPanel;
        private System.Windows.Forms.DataGridView emailAddressesGridView;
        private SnapShot_DBDataSetTableAdapters.HardwareTableAdapter hardwareTableAdapter;
        private System.Windows.Forms.BindingSource hardwareBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn hardwarekeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categorycodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn devicenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientassetnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datepurchasedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn warrantyexpiryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datewrittenoffDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn notesDataGridViewTextBoxColumn1;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.FlowLayoutPanel clientButtonFlowLayoutPanel;
        private System.Windows.Forms.Button addClientButton;
        private System.Windows.Forms.Button viewClientsButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button fillButton;
    }
}

