﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SnapShot.UniqueDataTypes;
using SnapShot.Views;

namespace SnapShot
{
    public partial class MainScreen : Form
    {
        protected Client selectedClient;//selected client
        protected UniqueDataTypes.SnapShot selectedSnapshot; //selected snapshot
        protected Location selectedLocation; //the select Location

        public MainScreen()
        {
            InitializeComponent();
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void clientSelectionToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        /**
         * when activated this will destroy this form and deallocate all resources given to the appalaction, closing it
         */
        private void MainScreen_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose();
            Application.Exit();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.clientBindingSource.EndEdit();
                this.clientTableAdapter.Update(this.snapShot_DBDataSet.Client);
                MessageBox.Show("Update successful");
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Update failed: " + ex);
            }
        }

        private void fillButton_Click(object sender, EventArgs e)
        {
            this.clientTableAdapter.Fill(this.snapShot_DBDataSet.Client);
        }

        private void clientDataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                foreach (DataGridViewRow item in this.clientDataGridView.SelectedRows)
                {
                    clientDataGridView.Rows.RemoveAt(item.Index);
                }
            }
        }

        //temp hardware fill button
        private void button2_Click(object sender, EventArgs e)
        {
            this.hardwareTableAdapter.Fill(this.snapShot_DBDataSet.Hardware);
        }

        //temp hardware update button
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.hardwareBindingSource.EndEdit();
                this.hardwareTableAdapter.Update(this.snapShot_DBDataSet.Hardware);
                MessageBox.Show("Update successful");
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Update failed: " + ex);
            }
        }

        #region clients tab methods
        /**
         * when this method is called the addClientGroupbox is shown, while the clientViewPanel is hidden
         */
        private void addClient_Click(object sender, EventArgs e)
        {
            this.clientViewPanel.Hide();
            this.addclientGroupBox.Show();
            //               ClientDetail clientDetail = new ClientDetail();
            //                clientDetail.Show();
        }

        /**
         * when this method is called it hides the addClientGroupbox, while showing the clientViewPanel
         * in the clients tab
         */
        private void ClientDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (clientDataGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = clientDataGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "C";
            }
        }

        /**
         * when this method is called it hides the clientViewPanel, while showing the addClientGroupbox
         * in the clients tab
         */
        private void viewClientsButton_Click(object sender, EventArgs e)
        {
            this.clientViewPanel.Show();
            this.addclientGroupBox.Hide();
        }

        /**
         * when called this method takes the data in the addClientGroupbox elements and attempts to
         * make a new client entry. on success the view is displayed with the new entry. errors in
         * given data result in error mesage poping up 
         */ 
        private void saveClientButton_Click(object sender, EventArgs e)
        {
            this.viewClientsButton_Click(sender, e);
        }
        #endregion

        #region hardware tab methods
        /**
         * when a hardware is selected in the hardware view, changes all reference to the preious one
         * to the current one
         */
        private void HardwareDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (hardwareDataGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = hardwareDataGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "H";
            }
        }

        /**
         * when called this method hides the hardwareViewPanel in the hardware tab and displays
         * the addHardwareGroupbox
         */
        private void addHardwareButton_Click(object sender, EventArgs e)
        {
            this.hardwareViewPanel.Hide();
            this.addHardwareGroupBox.Show();
        }

        /**
         * when called this method hides the addHardewareGroup box in the hardware tab and
         * displays the hardwareViewPanel
         */
        private void viewHardwareButton_Click(object sender, EventArgs e)
        {
            this.addHardwareGroupBox.Hide();
            this.hardwareViewPanel.Show();
        }
        #endregion

        #region snapshot tab methods
        /**
         * when a snapshot is selected in the snapshot view, changes all reference to the preious one
         * to the current one
         */
        private void SnapshotDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (snapshotsDataGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = snapshotsDataGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "S";
            }
        }

        /**
         * when called this method shows the addSnapshotGroupBox, while hding the snapshotViewPanel
         * in the snapshot tab
         */
        private void addSnapshotsButton_Click(object sender, EventArgs e)
        {
            this.snapshotViewPanel.Hide();
            this.addSnapshotGroupBox.Show();
        }

        /**
         * when called this method shows the snapshotViewPanel, while hiding the addSnapshotGroupBox
         * in the snapshot tab 
         */
        private void snapshotsViewButton_Click(object sender, EventArgs e)
        {
            this.snapshotViewPanel.Show();
            this.addSnapshotGroupBox.Hide();
        }
        #endregion

        #region location tab methods
        /**
         * when a location is selected in the location view, changes all reference to the preious one
         * to the current one
         */
        private void LocationDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (locationsDataGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = locationsDataGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "LO";
            }
        }

        /**
         * when called this method shows the addLocationGroupBoxe, while hiding the locationViewPanel
         * in the license tab
         */
        private void addLocationButton_Click(object sender, EventArgs e)
        {
            this.locationViewPanel.Hide();
            this.addLocationGroupBox.Show();
        }

        /**
         * when called this method shows the locationViewPanel, while hiding the addLocationGroupBox
         * in the license tab
         */
        private void viewLocationsButton_Click(object sender, EventArgs e)
        {
            this.addLocationGroupBox.Hide();
            this.locationViewPanel.Show();
        }
        #endregion

        #region warranty tab methods
        /**
         * when a hardware is selected in the hardware view, changes all reference to the preious one
         * to the current one
         */
        private void WarrantyDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (warrantiesGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = warrantiesGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "W";
            }
        }

        /**
         * when called this method shows the add warraty groupbox, while hiding the warrantiesViewPanel
         */
        private void addWarrantiesButton_Click(object sender, EventArgs e)
        {
            this.warrantyViewPanel.Hide();
            this.addWarrantyGroupBox.Show();
        }

        /**
         * when called this method shows the add warrantiesViewPanel, while hiding the addWarratyGroupbox
         */
        private void viewWarrantiesButton_Click(object sender, EventArgs e)
        {
            this.addWarrantyGroupBox.Hide();
            this.warrantyViewPanel.Show();
        }
        #endregion

        #region user tab methods
        /**
         * when a users is selected in the users view, changes all reference to the preious one to 
         * the current one
         */
        private void UsersDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (usersDataGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = usersDataGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "U";
            }
        }

        /**
         * when called this method shows the addUserGroupBox, while hiding the userViewPanel
         */
        private void addUserButton_Click(object sender, EventArgs e)
        {
            this.userViewPanel.Hide();
            this.addUsersGroupBox.Show();
        }

        /**
         * when called this method shows the userViewPanel, while hiding the addUserGroupBox
         */
        private void viewUsersButton_Click(object sender, EventArgs e)
        {
            this.addUsersGroupBox.Hide();
            this.userViewPanel.Show();
        }
        #endregion

        #region license tab methods
        /**
         * when a license is selected in the licenes view, changes all reference to the preious one to
         * the current one
         */
        private void LicensesDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (licensesDataGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = licensesDataGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "LI";
            }
        }

        /**
        * when called this mehtod makes the addLicenseGroupBox visible, while hiding the licenseViewPanel
        * in the licenses tab
        */
        private void addLicenseButton_Click(object sender, EventArgs e)
        {
            this.licenseViewPanel.Hide();
            this.addLicenseGroupBox.Show();
        }

        /**
         * when called this method makes the licenseDataGridView visible, while hiding the addLicenseGroupBox in the license tab
         */
        private void viewLicensesbutton_Click(object sender, EventArgs e)
        {
            this.addLicenseGroupBox.Hide();
            this.licenseViewPanel.Show();
        }
        #endregion

        #region support agreement tab methods
        /**
         * when a support agreement is selected in the support agreement view, changes all reference to the preious one to the current one
         */
        private void SupportAgreementDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (supportAgreementsGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = supportAgreementsGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "S";
            }
        }

        /**
         * when this method is called it shows the addSupportAgreementGroupBox, while hiding the supportAgreementViewPanel in the support Agreement tab
         */
        private void addSupportAgreementsButton_Click(object sender, EventArgs e)
        {
            this.supportAgreementViewPanel.Hide();
            this.addSupportAgreementGroupBox.Show();
        }

        /**
         * when this method is called it shows the supportAgreementViewPanel, while hiding the addSupportAgreementGroupBox in the support Agreement tab
         */
        private void viewSupportAgreementsButton_Click(object sender, EventArgs e)
        {
            this.addSupportAgreementGroupBox.Hide();
            this.supportAgreementViewPanel.Show();
        }
        #endregion

        #region communication link tab methods
        /**
         * when a communication link is selected in the communication link view, changes all reference to the preious one to the current one
         */
        private void CommunicationLinksDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (communicationLinksGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = communicationLinksGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "CO";
            }
        }

        /**
        * when called this method shows the addCommunicationLinkGroupBox, while hiding the communicationlinkViewPanel
        */
        private void addCommunicationLinksButton_Click(object sender, EventArgs e)
        {
            this.communicationLinkViewPanel.Hide();
            this.addCommunicationsLinkGroupBox.Show();
        }

        /**
        * when called this method shows the communicationlinkViewPanel, while hiding the addCommunicationLinkGroupBox
        */
        private void viewCommunicationLinksButton_Click(object sender, EventArgs e)
        {
            this.addCommunicationsLinkGroupBox.Hide();
            this.communicationLinkViewPanel.Show();
        }
        #endregion

        #region email address tab methods
        /**
         * when a email address is selected in the email address view, changes all reference to the preious one to the current one
         */
        private void EmailAddressDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (emailAddressesGridView.SelectedRows.Count > 0)
            {
                //get the selected entry in the data grid view
                int indexOfSelection = emailAddressesGridView.SelectedRows[0].Index;
                //change reference to selected, to current one
                this.selectedClientNameBox.Text = indexOfSelection.ToString() + "E";
            }
        }

        /**
         * when called this method shows the addEmailAddressGroupBox, while hiding the emailAddressViewPanel
         */
        private void addEmailAddressesButton_Click(object sender, EventArgs e)
        {
            this.emailAddressViewPanel.Hide();
            this.addEmailAddressGroupBox.Show();
        }

        /**
         * when called this method shows the emailAddressViewPanel, while hiding the addEmailAddressGroupBox
         */
        private void viewEmailAddressessButton_Click(object sender, EventArgs e)
        {
            this.addEmailAddressGroupBox.Hide();
            this.emailAddressViewPanel.Show();
        }








        #endregion


    }
}