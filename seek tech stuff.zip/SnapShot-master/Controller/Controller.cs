﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnapShot.Controller
{
    class Controller
    {
        #region Singleton
        private static Controller instance;
        public static Controller Instance
        {
            get
            {
                if (instance == null) instance = new Controller();
                return instance;
            }
        }
        #endregion

        public interface IView
        {
            void ModelChange(object sender, UpdateModelEvent UME);
        }

        public class UpdateModelEvent
        {
            //update data from db (specifc table)
        }
    }
}
