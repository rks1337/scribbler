﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnapShot.Controller
{
    class Model
    {
        // Default instance for the model
        #region Singleton
        static Model instance;
        public static Model Instance
        {
            get
            {
                if (instance == null)
                    instance = new Model();

                return instance;
            }
        }
        #endregion

        public Table_Object tb;
        public Dictionary<string, Table_Object> table_dictionary = new Dictionary<string, Table_Object>();

        //code to retrieve data from DB goes here
        //put the code in the table object, put the table in the dictonary
        //this is only a logical example for the MVC, may change depeding on data retrievale method
    }
}
