﻿namespace SnapShot.Controller
{
    internal class Table_Object
    {
        //this will change
    }
}