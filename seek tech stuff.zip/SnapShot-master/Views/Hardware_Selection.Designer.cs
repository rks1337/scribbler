﻿namespace SnapShot.Views
{
    partial class Hardware_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hardwareGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // hardwareGridView
            // 
            this.hardwareGridView.AllowUserToAddRows = false;
            this.hardwareGridView.AllowUserToDeleteRows = false;
            this.hardwareGridView.AllowUserToOrderColumns = true;
            this.hardwareGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hardwareGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hardwareGridView.Location = new System.Drawing.Point(0, 0);
            this.hardwareGridView.Name = "hardwareGridView";
            this.hardwareGridView.ReadOnly = true;
            this.hardwareGridView.Size = new System.Drawing.Size(307, 450);
            this.hardwareGridView.TabIndex = 0;
            // 
            // Hardware_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 450);
            this.Controls.Add(this.hardwareGridView);
            this.Name = "Hardware_Selection";
            this.Text = "Hardware_Selection";
            ((System.ComponentModel.ISupportInitialize)(this.hardwareGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView hardwareGridView;
    }
}