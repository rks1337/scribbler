﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnapShot.Views
{
    public partial class Location_Selection : Form
    {
        public Location_Selection()
        {
            InitializeComponent();
        }

        // Function to check to see if a form is already opened
        private bool Check_Open_Form(string name)
        {
            FormCollection form_collection = Application.OpenForms;

            foreach (Form form in form_collection)
            {
                if (form.Text == name)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
