﻿namespace SnapShot.Views
{
    partial class Client_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clientDataGridView = new System.Windows.Forms.DataGridView();
            this.BussinessName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddressLine1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddressLine2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddressLine3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddressLine4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillingName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Notes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.clientDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // clientDataGridView
            // 
            this.clientDataGridView.AllowUserToOrderColumns = true;
            this.clientDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.clientDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BussinessName,
            this.AddressLine1,
            this.AddressLine2,
            this.AddressLine3,
            this.AddressLine4,
            this.BillingName,
            this.Status,
            this.Notes});
            this.clientDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clientDataGridView.Location = new System.Drawing.Point(0, 0);
            this.clientDataGridView.MultiSelect = false;
            this.clientDataGridView.Name = "clientDataGridView";
            this.clientDataGridView.Size = new System.Drawing.Size(844, 458);
            this.clientDataGridView.TabIndex = 0;
            this.clientDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.clientDataGridView_CellContentClick);
            this.clientDataGridView.SelectionChanged += new System.EventHandler(this.clientDataGridView_SelectionChanged);
            // 
            // BussinessName
            // 
            this.BussinessName.HeaderText = "Bussiness Name";
            this.BussinessName.Name = "BussinessName";
            // 
            // AddressLine1
            // 
            this.AddressLine1.HeaderText = "Address Line 1";
            this.AddressLine1.Name = "AddressLine1";
            // 
            // AddressLine2
            // 
            this.AddressLine2.HeaderText = "Address Line 2";
            this.AddressLine2.Name = "AddressLine2";
            // 
            // AddressLine3
            // 
            this.AddressLine3.HeaderText = "Address Line 3";
            this.AddressLine3.Name = "AddressLine3";
            // 
            // AddressLine4
            // 
            this.AddressLine4.HeaderText = "Address Line 4";
            this.AddressLine4.Name = "AddressLine4";
            // 
            // BillingName
            // 
            this.BillingName.HeaderText = "Billing Name";
            this.BillingName.Name = "BillingName";
            // 
            // Status
            // 
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            // 
            // Notes
            // 
            this.Notes.HeaderText = "Notes";
            this.Notes.Name = "Notes";
            // 
            // Client_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 458);
            this.Controls.Add(this.clientDataGridView);
            this.Name = "Client_Selection";
            this.Text = "Client_Selection";
            ((System.ComponentModel.ISupportInitialize)(this.clientDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView clientDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn BussinessName;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressLine1;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressLine2;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressLine3;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressLine4;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillingName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn Notes;
    }
}