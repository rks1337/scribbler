﻿namespace SnapShot.Views
{
    partial class Warranty_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.warrantyGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.warrantyGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // warrantyGridView
            // 
            this.warrantyGridView.AllowUserToAddRows = false;
            this.warrantyGridView.AllowUserToDeleteRows = false;
            this.warrantyGridView.AllowUserToOrderColumns = true;
            this.warrantyGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.warrantyGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.warrantyGridView.Location = new System.Drawing.Point(0, 0);
            this.warrantyGridView.Name = "warrantyGridView";
            this.warrantyGridView.ReadOnly = true;
            this.warrantyGridView.Size = new System.Drawing.Size(341, 450);
            this.warrantyGridView.TabIndex = 0;
            // 
            // Warranty_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 450);
            this.Controls.Add(this.warrantyGridView);
            this.Name = "Warranty_Selection";
            this.Text = "Warranty_Selection";
            ((System.ComponentModel.ISupportInitialize)(this.warrantyGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView warrantyGridView;
    }
}