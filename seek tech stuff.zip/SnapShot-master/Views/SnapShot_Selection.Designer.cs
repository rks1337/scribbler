﻿namespace SnapShot.Views
{
    partial class SnapShot_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.snapShotGridView = new System.Windows.Forms.DataGridView();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateHistoric = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Notes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.snapShotGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // snapShotGridView
            // 
            this.snapShotGridView.AllowUserToOrderColumns = true;
            this.snapShotGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.snapShotGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Status,
            this.DateCreated,
            this.DateHistoric,
            this.Notes});
            this.snapShotGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.snapShotGridView.Location = new System.Drawing.Point(0, 0);
            this.snapShotGridView.Name = "snapShotGridView";
            this.snapShotGridView.ReadOnly = true;
            this.snapShotGridView.Size = new System.Drawing.Size(451, 433);
            this.snapShotGridView.TabIndex = 0;
            this.snapShotGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.snapShotGridView_CellContentClick);
            
            // 
            // Status
            // 
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // DateCreated
            // 
            this.DateCreated.HeaderText = "DateCreated";
            this.DateCreated.Name = "DateCreated";
            this.DateCreated.ReadOnly = true;
            // 
            // DateHistoric
            // 
            this.DateHistoric.HeaderText = "DateHistoric";
            this.DateHistoric.Name = "DateHistoric";
            this.DateHistoric.ReadOnly = true;
            // 
            // Notes
            // 
            this.Notes.HeaderText = "Notes";
            this.Notes.Name = "Notes";
            this.Notes.ReadOnly = true;
            // 
            // SnapShot_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 433);
            this.Controls.Add(this.snapShotGridView);
            this.Name = "SnapShot_Selection";
            this.Text = "SnapShot_Selection";
            ((System.ComponentModel.ISupportInitialize)(this.snapShotGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView snapShotGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCreated;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateHistoric;
        private System.Windows.Forms.DataGridViewTextBoxColumn Notes;
    }
}