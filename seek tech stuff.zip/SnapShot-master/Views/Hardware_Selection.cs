﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnapShot.Views
{
    public partial class Hardware_Selection : Form
    {
        public Hardware_Selection()
        {
            InitializeComponent();
        }
    }
}
