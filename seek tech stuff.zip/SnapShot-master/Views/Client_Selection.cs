﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SnapShot.UniqueDataTypes;

namespace SnapShot.Views
{
    public partial class Client_Selection : Form
    {
        private Views.ClientDetail cd; //next screen to be opened
        private Client selectedClient; // the selected client

        public Client_Selection()
        {
            InitializeComponent();
        }

        public Client SelectedClient { get => selectedClient; set => selectedClient = value; }

        /**
         * when a row is selected allow manipulation of the client and open the next form
         */
        private void clientDataGridView_SelectionChanged(object sender, System.EventArgs e)
        {
            //don't do anything if nothing is selected 
            if (clientDataGridView.SelectedRows.Count > 0)
            {
                if (cd == null)
                {
                    SelectedClient = new Client();
                    cd = new Views.ClientDetail();
                    cd.MdiParent = this.MdiParent;
                    if (!Check_Open_Form(cd.Name))
                    {
                        cd.Show();
                    }
                }
                //close old window opened by selection and open it with new selection
                else if (cd != null)
                {
                    cd.Close();
                    cd.Dispose();
                    SelectedClient = new Client();
                    cd = new Views.ClientDetail();
                    cd.MdiParent = this.MdiParent;
                    if (!Check_Open_Form(cd.Name))
                    {
                        cd.Show();
                    }
                }
            }
        }

        // Function to check to see if a form is already opened-code by bogdan
        private bool Check_Open_Form(string name)
        {
            FormCollection form_collection = Application.OpenForms;

            foreach (Form form in form_collection)
            {
                if (form.Text == name)
                {
                    return true;
                }
            }
            return false;
        }

        private void clientDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        /**
         * close windows created by this form
         */
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (cd != null)
            {
                cd.Close();
                cd.Dispose();
            }

        }
    }
}
