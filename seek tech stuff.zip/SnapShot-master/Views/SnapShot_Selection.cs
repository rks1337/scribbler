﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnapShot.Views
{
    public partial class SnapShot_Selection : Form
    {
        public SnapShot_Selection()
        {
            InitializeComponent();
        }

        private void snapShotGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = e.RowIndex;
        }

        // Function to check to see if a form is already opened
        private bool Check_Open_Form(string name)
        {
            FormCollection form_collection = Application.OpenForms;

            foreach (Form form in form_collection)
            {
                if (form.Text == name)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
