﻿namespace SnapShot.Views
{
    partial class SupportAgreement_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.supportAgreementGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.supportAgreementGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // supportAgreementGridView
            // 
            this.supportAgreementGridView.AllowUserToAddRows = false;
            this.supportAgreementGridView.AllowUserToDeleteRows = false;
            this.supportAgreementGridView.AllowUserToOrderColumns = true;
            this.supportAgreementGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.supportAgreementGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.supportAgreementGridView.Location = new System.Drawing.Point(0, 0);
            this.supportAgreementGridView.Name = "supportAgreementGridView";
            this.supportAgreementGridView.ReadOnly = true;
            this.supportAgreementGridView.Size = new System.Drawing.Size(346, 450);
            this.supportAgreementGridView.TabIndex = 0;
            // 
            // SupportAgreement_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 450);
            this.Controls.Add(this.supportAgreementGridView);
            this.Name = "SupportAgreement_Selection";
            this.Text = "SupportAgreement_Selection";
            ((System.ComponentModel.ISupportInitialize)(this.supportAgreementGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView supportAgreementGridView;
    }
}