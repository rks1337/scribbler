﻿namespace SnapShot.Views
{
    partial class Location_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.locationGridView = new System.Windows.Forms.DataGridView();
            this.LocationDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Enviroment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Notes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.locationGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // locationGridView
            // 
            this.locationGridView.AllowUserToOrderColumns = true;
            this.locationGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.locationGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LocationDescription,
            this.Enviroment,
            this.Notes});
            this.locationGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.locationGridView.Location = new System.Drawing.Point(0, 0);
            this.locationGridView.Name = "locationGridView";
            this.locationGridView.ReadOnly = true;
            this.locationGridView.Size = new System.Drawing.Size(344, 446);
            this.locationGridView.TabIndex = 0;
            // 
            // LocationDescription
            // 
            this.LocationDescription.HeaderText = "LocationDescription";
            this.LocationDescription.Name = "LocationDescription";
            this.LocationDescription.ReadOnly = true;
            // 
            // Enviroment
            // 
            this.Enviroment.HeaderText = "Enviroment";
            this.Enviroment.Name = "Enviroment";
            this.Enviroment.ReadOnly = true;
            // 
            // Notes
            // 
            this.Notes.HeaderText = "Notes";
            this.Notes.Name = "Notes";
            this.Notes.ReadOnly = true;
            // 
            // Location_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 446);
            this.Controls.Add(this.locationGridView);
            this.Name = "Location_Selection";
            this.Text = "Location_Selection";
            ((System.ComponentModel.ISupportInitialize)(this.locationGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView locationGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn LocationDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Enviroment;
        private System.Windows.Forms.DataGridViewTextBoxColumn Notes;
    }
}