﻿namespace SnapShot.Views
{
    partial class ClientDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clientDetailGroupBox = new System.Windows.Forms.GroupBox();
            this.saveClientButton = new System.Windows.Forms.Button();
            this.notesTextBox = new System.Windows.Forms.TextBox();
            this.notesLabel = new System.Windows.Forms.Label();
            this.inactiveStatusRadioButton = new System.Windows.Forms.RadioButton();
            this.activeStatusRadioButton = new System.Windows.Forms.RadioButton();
            this.statusLabel = new System.Windows.Forms.Label();
            this.billingNameTextBox = new System.Windows.Forms.TextBox();
            this.billingNameLabel = new System.Windows.Forms.Label();
            this.addressLine4TextBox = new System.Windows.Forms.TextBox();
            this.addressLine4Label = new System.Windows.Forms.Label();
            this.addressLine3TextBox = new System.Windows.Forms.TextBox();
            this.addressLine3Label = new System.Windows.Forms.Label();
            this.addressLine2TextBox = new System.Windows.Forms.TextBox();
            this.addressLine2Label = new System.Windows.Forms.Label();
            this.addressLine1TextBox = new System.Windows.Forms.TextBox();
            this.addressLineLabel = new System.Windows.Forms.Label();
            this.businessNameTextBox = new System.Windows.Forms.TextBox();
            this.bussinessNameLabel = new System.Windows.Forms.Label();
            this.selectedClientNamelabel = new System.Windows.Forms.Label();
            this.clientDetailSelectedClientName = new System.Windows.Forms.TextBox();
            this.clientDetailGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // clientDetailGroupBox
            // 
            this.clientDetailGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.clientDetailGroupBox.Controls.Add(this.saveClientButton);
            this.clientDetailGroupBox.Controls.Add(this.notesTextBox);
            this.clientDetailGroupBox.Controls.Add(this.notesLabel);
            this.clientDetailGroupBox.Controls.Add(this.inactiveStatusRadioButton);
            this.clientDetailGroupBox.Controls.Add(this.activeStatusRadioButton);
            this.clientDetailGroupBox.Controls.Add(this.statusLabel);
            this.clientDetailGroupBox.Controls.Add(this.billingNameTextBox);
            this.clientDetailGroupBox.Controls.Add(this.billingNameLabel);
            this.clientDetailGroupBox.Controls.Add(this.addressLine4TextBox);
            this.clientDetailGroupBox.Controls.Add(this.addressLine4Label);
            this.clientDetailGroupBox.Controls.Add(this.addressLine3TextBox);
            this.clientDetailGroupBox.Controls.Add(this.addressLine3Label);
            this.clientDetailGroupBox.Controls.Add(this.addressLine2TextBox);
            this.clientDetailGroupBox.Controls.Add(this.addressLine2Label);
            this.clientDetailGroupBox.Controls.Add(this.addressLine1TextBox);
            this.clientDetailGroupBox.Controls.Add(this.addressLineLabel);
            this.clientDetailGroupBox.Controls.Add(this.businessNameTextBox);
            this.clientDetailGroupBox.Controls.Add(this.bussinessNameLabel);
            this.clientDetailGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientDetailGroupBox.Location = new System.Drawing.Point(16, 64);
            this.clientDetailGroupBox.Margin = new System.Windows.Forms.Padding(2);
            this.clientDetailGroupBox.Name = "clientDetailGroupBox";
            this.clientDetailGroupBox.Padding = new System.Windows.Forms.Padding(2);
            this.clientDetailGroupBox.Size = new System.Drawing.Size(422, 431);
            this.clientDetailGroupBox.TabIndex = 3;
            this.clientDetailGroupBox.TabStop = false;
            // 
            // saveClientButton
            // 
            this.saveClientButton.Location = new System.Drawing.Point(277, 374);
            this.saveClientButton.Margin = new System.Windows.Forms.Padding(2);
            this.saveClientButton.Name = "saveClientButton";
            this.saveClientButton.Size = new System.Drawing.Size(56, 26);
            this.saveClientButton.TabIndex = 17;
            this.saveClientButton.Text = "Save";
            this.saveClientButton.UseVisualStyleBackColor = true;
            this.saveClientButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // notesTextBox
            // 
            this.notesTextBox.Location = new System.Drawing.Point(150, 321);
            this.notesTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.notesTextBox.Name = "notesTextBox";
            this.notesTextBox.Size = new System.Drawing.Size(183, 21);
            this.notesTextBox.TabIndex = 16;
            // 
            // notesLabel
            // 
            this.notesLabel.AutoSize = true;
            this.notesLabel.Location = new System.Drawing.Point(50, 326);
            this.notesLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.notesLabel.Name = "notesLabel";
            this.notesLabel.Size = new System.Drawing.Size(39, 15);
            this.notesLabel.TabIndex = 15;
            this.notesLabel.Text = "Notes";
            // 
            // inactiveStatusRadioButton
            // 
            this.inactiveStatusRadioButton.AutoSize = true;
            this.inactiveStatusRadioButton.Location = new System.Drawing.Point(229, 284);
            this.inactiveStatusRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.inactiveStatusRadioButton.Name = "inactiveStatusRadioButton";
            this.inactiveStatusRadioButton.Size = new System.Drawing.Size(66, 19);
            this.inactiveStatusRadioButton.TabIndex = 14;
            this.inactiveStatusRadioButton.Text = "Inactive";
            this.inactiveStatusRadioButton.UseVisualStyleBackColor = true;
            // 
            // activeStatusRadioButton
            // 
            this.activeStatusRadioButton.AutoSize = true;
            this.activeStatusRadioButton.Checked = true;
            this.activeStatusRadioButton.Location = new System.Drawing.Point(150, 284);
            this.activeStatusRadioButton.Margin = new System.Windows.Forms.Padding(2);
            this.activeStatusRadioButton.Name = "activeStatusRadioButton";
            this.activeStatusRadioButton.Size = new System.Drawing.Size(56, 19);
            this.activeStatusRadioButton.TabIndex = 13;
            this.activeStatusRadioButton.TabStop = true;
            this.activeStatusRadioButton.Text = "Active";
            this.activeStatusRadioButton.UseVisualStyleBackColor = true;
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(49, 288);
            this.statusLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(41, 15);
            this.statusLabel.TabIndex = 12;
            this.statusLabel.Text = "Status";
            // 
            // billingNameTextBox
            // 
            this.billingNameTextBox.Location = new System.Drawing.Point(151, 241);
            this.billingNameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.billingNameTextBox.Name = "billingNameTextBox";
            this.billingNameTextBox.Size = new System.Drawing.Size(183, 21);
            this.billingNameTextBox.TabIndex = 11;
            // 
            // billingNameLabel
            // 
            this.billingNameLabel.AutoSize = true;
            this.billingNameLabel.Location = new System.Drawing.Point(22, 246);
            this.billingNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.billingNameLabel.Name = "billingNameLabel";
            this.billingNameLabel.Size = new System.Drawing.Size(78, 15);
            this.billingNameLabel.TabIndex = 10;
            this.billingNameLabel.Text = "Billing Name";
            // 
            // addressLine4TextBox
            // 
            this.addressLine4TextBox.Location = new System.Drawing.Point(151, 194);
            this.addressLine4TextBox.Margin = new System.Windows.Forms.Padding(2);
            this.addressLine4TextBox.Name = "addressLine4TextBox";
            this.addressLine4TextBox.Size = new System.Drawing.Size(183, 21);
            this.addressLine4TextBox.TabIndex = 9;
            // 
            // addressLine4Label
            // 
            this.addressLine4Label.AutoSize = true;
            this.addressLine4Label.Location = new System.Drawing.Point(8, 199);
            this.addressLine4Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addressLine4Label.Name = "addressLine4Label";
            this.addressLine4Label.Size = new System.Drawing.Size(88, 15);
            this.addressLine4Label.TabIndex = 8;
            this.addressLine4Label.Text = "Address Line 4";
            // 
            // addressLine3TextBox
            // 
            this.addressLine3TextBox.Location = new System.Drawing.Point(151, 151);
            this.addressLine3TextBox.Margin = new System.Windows.Forms.Padding(2);
            this.addressLine3TextBox.Name = "addressLine3TextBox";
            this.addressLine3TextBox.Size = new System.Drawing.Size(183, 21);
            this.addressLine3TextBox.TabIndex = 7;
            // 
            // addressLine3Label
            // 
            this.addressLine3Label.AutoSize = true;
            this.addressLine3Label.Location = new System.Drawing.Point(8, 156);
            this.addressLine3Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addressLine3Label.Name = "addressLine3Label";
            this.addressLine3Label.Size = new System.Drawing.Size(88, 15);
            this.addressLine3Label.TabIndex = 6;
            this.addressLine3Label.Text = "Address Line 3";
            // 
            // addressLine2TextBox
            // 
            this.addressLine2TextBox.Location = new System.Drawing.Point(151, 114);
            this.addressLine2TextBox.Margin = new System.Windows.Forms.Padding(2);
            this.addressLine2TextBox.Name = "addressLine2TextBox";
            this.addressLine2TextBox.Size = new System.Drawing.Size(183, 21);
            this.addressLine2TextBox.TabIndex = 5;
            // 
            // addressLine2Label
            // 
            this.addressLine2Label.AutoSize = true;
            this.addressLine2Label.Location = new System.Drawing.Point(8, 119);
            this.addressLine2Label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addressLine2Label.Name = "addressLine2Label";
            this.addressLine2Label.Size = new System.Drawing.Size(88, 15);
            this.addressLine2Label.TabIndex = 4;
            this.addressLine2Label.Text = "Address Line 2";
            // 
            // addressLine1TextBox
            // 
            this.addressLine1TextBox.Location = new System.Drawing.Point(151, 73);
            this.addressLine1TextBox.Margin = new System.Windows.Forms.Padding(2);
            this.addressLine1TextBox.Name = "addressLine1TextBox";
            this.addressLine1TextBox.Size = new System.Drawing.Size(183, 21);
            this.addressLine1TextBox.TabIndex = 3;
            // 
            // addressLineLabel
            // 
            this.addressLineLabel.AutoSize = true;
            this.addressLineLabel.Location = new System.Drawing.Point(8, 78);
            this.addressLineLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addressLineLabel.Name = "addressLineLabel";
            this.addressLineLabel.Size = new System.Drawing.Size(88, 15);
            this.addressLineLabel.TabIndex = 2;
            this.addressLineLabel.Text = "Address Line 1";
            // 
            // businessNameTextBox
            // 
            this.businessNameTextBox.Location = new System.Drawing.Point(151, 34);
            this.businessNameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.businessNameTextBox.Name = "businessNameTextBox";
            this.businessNameTextBox.Size = new System.Drawing.Size(183, 21);
            this.businessNameTextBox.TabIndex = 1;
            // 
            // bussinessNameLabel
            // 
            this.bussinessNameLabel.AutoSize = true;
            this.bussinessNameLabel.Location = new System.Drawing.Point(5, 39);
            this.bussinessNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bussinessNameLabel.Name = "bussinessNameLabel";
            this.bussinessNameLabel.Size = new System.Drawing.Size(94, 15);
            this.bussinessNameLabel.TabIndex = 0;
            this.bussinessNameLabel.Text = "Business Name";
            // 
            // selectedClientNamelabel
            // 
            this.selectedClientNamelabel.AutoSize = true;
            this.selectedClientNamelabel.Location = new System.Drawing.Point(22, 24);
            this.selectedClientNamelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.selectedClientNamelabel.Name = "selectedClientNamelabel";
            this.selectedClientNamelabel.Size = new System.Drawing.Size(67, 13);
            this.selectedClientNamelabel.TabIndex = 4;
            this.selectedClientNamelabel.Text = "Client Name:";
            // 
            // clientDetailSelectedClientName
            // 
            this.clientDetailSelectedClientName.Location = new System.Drawing.Point(167, 20);
            this.clientDetailSelectedClientName.Margin = new System.Windows.Forms.Padding(2);
            this.clientDetailSelectedClientName.Name = "clientDetailSelectedClientName";
            this.clientDetailSelectedClientName.Size = new System.Drawing.Size(183, 20);
            this.clientDetailSelectedClientName.TabIndex = 5;
            // 
            // ClientDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 525);
            this.Controls.Add(this.clientDetailSelectedClientName);
            this.Controls.Add(this.selectedClientNamelabel);
            this.Controls.Add(this.clientDetailGroupBox);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ClientDetail";
            this.Text = "ClientDetail";
            this.clientDetailGroupBox.ResumeLayout(false);
            this.clientDetailGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox clientDetailGroupBox;
        private System.Windows.Forms.Button saveClientButton;
        private System.Windows.Forms.TextBox notesTextBox;
        private System.Windows.Forms.Label notesLabel;
        private System.Windows.Forms.RadioButton inactiveStatusRadioButton;
        private System.Windows.Forms.RadioButton activeStatusRadioButton;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.TextBox billingNameTextBox;
        private System.Windows.Forms.Label billingNameLabel;
        private System.Windows.Forms.TextBox addressLine4TextBox;
        private System.Windows.Forms.Label addressLine4Label;
        private System.Windows.Forms.TextBox addressLine3TextBox;
        private System.Windows.Forms.Label addressLine3Label;
        private System.Windows.Forms.TextBox addressLine2TextBox;
        private System.Windows.Forms.Label addressLine2Label;
        private System.Windows.Forms.TextBox addressLine1TextBox;
        private System.Windows.Forms.Label addressLineLabel;
        private System.Windows.Forms.TextBox businessNameTextBox;
        private System.Windows.Forms.Label bussinessNameLabel;
        private System.Windows.Forms.Label selectedClientNamelabel;
        private System.Windows.Forms.TextBox clientDetailSelectedClientName;
    }
}