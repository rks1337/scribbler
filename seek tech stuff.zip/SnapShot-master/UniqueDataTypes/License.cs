﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class License
    {
        private int _clientKey; //key for the client this relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //key for the Location this relates to
        private int _licenseKey; //key for the lisense this relates to
        private string _codeOffset; //license code and or offset value
        private string _category; //license category
        private string _description; //desrciption of what the license is
        private string _subscriptionType; //license subscription type
        private int _packCores; //number of license sold together
        private int _quantity; //how many license pack/cores were purchased
        private int _purchased; //exactly how many license were bought
        private int _allocated; //remaining number of licenses
        private string _allocatedKey; // key for the what this was allocated to
        private DateTime _purchasedDate;//when it was purchased
        private DateTime _expire;//expire date
        private string _quoteRef;//quote ref number
        private string _ticket;//ticket number of it
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public int LicenseKey
        {
            get
            {
                return _licenseKey;
            }
        }

        public string CodeOffset
        {
            get
            {
                return _codeOffset;
            }

            set
            {
                _codeOffset = value;
            }
        }

        public string Category
        {
            get
            {
                return _category;
            }

            set
            {
                _category = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public string SubscriptionType
        {
            get
            {
                return _subscriptionType;
            }

            set
            {
                _subscriptionType = value;
            }
        }

        public int PackCores
        {
            get
            {
                return _packCores;
            }

            set
            {
                _packCores = value;
            }
        }

        public int Quantity
        {
            get
            {
                return _quantity;
            }

            set
            {
                _quantity = value;
            }
        }

        public int Purchased
        {
            get
            {
                return _purchased;
            }

            set
            {
                _purchased = value;
            }
        }

        public int Allocated
        {
            get
            {
                return _allocated;
            }

            set
            {
                _allocated = value;
            }
        }

        public string AllocatedKey
        {
            get
            {
                return _allocatedKey;
            }

            set
            {
                _allocatedKey = value;
            }
        }

        public DateTime PurchasedDate
        {
            get
            {
                return _purchasedDate;
            }

            set
            {
                _purchasedDate = value;
            }
        }

        public DateTime Expire
        {
            get
            {
                return _expire;
            }

            set
            {
                _expire = value;
            }
        }

        public string QuoteRef
        {
            get
            {
                return _quoteRef;
            }

            set
            {
                _quoteRef = value;
            }
        }

        public string Ticket
        {
            get
            {
                return _ticket;
            }

            set
            {
                _ticket = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public License()
        {
        }

        /**
         * creates license from given data
         */

        public License(int inClientKey, int inSnapshotKey, int inLocationKey, int inLicenseKey,
              string inCodeOffset, string inCategory, string inDescription, string inSubscriptionType,
              int inPackCores, int inQuantity, int inPurchased, int inAllocated, string inAllocatedKey,
              DateTime inPurchasedDate, DateTime inExpire, string inQuoteRef, string inTicket, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _licenseKey = inLicenseKey;
            _codeOffset = inCodeOffset;
            _category = inCategory;
            _description = inDescription;
            _subscriptionType = inSubscriptionType;
            _packCores = inPackCores;
            _quantity = inQuantity;
            _purchased = inPurchased;
            _allocated = inAllocated;
            _allocatedKey = inAllocatedKey;
            _purchasedDate = inPurchasedDate;
            _expire = inExpire;
            _quoteRef = inQuoteRef;
            _ticket = inTicket;
            _notes = inNotes;
        }

        /**
         * creates license from given license
         */

        public License(License other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _licenseKey = other.LicenseKey;
            _codeOffset = other.CodeOffset;
            _category = other.Category;
            _description = other.Description;
            _subscriptionType = other.SubscriptionType;
            _packCores = other.PackCores;
            _quantity = other.Quantity;
            _purchased = other.Purchased;
            _allocated = other.Allocated;
            _allocatedKey = other.AllocatedKey;
            _purchasedDate = other.PurchasedDate;
            _expire = other.Expire;
            _quoteRef = other.QuoteRef;
            _ticket = other.Ticket;
            _notes = other.Notes;
        }

        /**
         * true false test to see if obj is equal to this license
         */

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                License other = (License)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the license hash value
         */

        public override int GetHashCode()
        {
            return this.LicenseKey;
        }

        /**
         * goives the license as a string
         */

        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "License ID: " + this.LicenseKey.ToString();
            result += "\n " + "Code/Offset: " + this.CodeOffset;
            result += "\n " + "Subscription Category: " + this.Category;
            result += "\n " + "Subscription Desrciption: " + this.Description;
            result += "\n " + "Subscription Type: " + this.SubscriptionType;
            result += "\n " + "Pack/cores: " + this.PackCores.ToString();
            result += "\n " + "Quantity: " + this.Quantity.ToString();
            result += "\n " + "Total number of liscense bought: " + this.Purchased.ToString();
            result += "\n " + "NUmber of license allocated: " + this.Allocated.ToString();
            result += "\n " + "Allocated key: " + this.AllocatedKey;
            result += "\n " + "Purchase date: " + this.PurchasedDate.ToLongDateString();
            result += "\n " + "Expire Date: " + this.Expire.ToLongDateString();
            result += "\n " + "quote ref: " + this.QuoteRef;
            result += "\n " + "ticket: " + this.Ticket;
            result += "\n " + "notes: " + this.Notes;
            return result;
        }
    }
}