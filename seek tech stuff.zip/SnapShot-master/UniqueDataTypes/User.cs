﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class User
    {
        private int _clientKey; //key for the client this relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //key for the Location this relates to
        private int _userKey; //key for the user this relates to
        private string _surname;//surname of user
        private string _firstName;//users 1st name
        private DateTime _commenced; // when user started/created
        private DateTime _terminated; //date user was terminated
        private DateTime _suspended; //date user was suspended
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public int UserKey
        {
            get
            {
                return _userKey;
            }
        }

        public string Surname
        {
            get
            {
                return _surname;
            }

            set
            {
                _surname = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        public DateTime Commenced
        {
            get
            {
                return _commenced;
            }

            set
            {
                _commenced = value;
            }
        }

        public DateTime Terminated
        {
            get
            {
                return _terminated;
            }

            set
            {
                _terminated = value;
            }
        }

        public DateTime Suspended
        {
            get
            {
                return _suspended;
            }

            set
            {
                _suspended = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public User()
        {
        }

        /**
        * creates user from given data
        */
        public User(int inClientKey, int inSnapshotKey, int inLocationKey, int inUserKey, string inSurname,
            string inFirstName, DateTime inCommenced, DateTime inTermination, DateTime inSuspended, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _userKey = inUserKey;
            _surname = inSurname;
            _firstName = inFirstName;
            _commenced = inCommenced;
            _terminated = inTermination;
            _suspended = inSuspended;
            _notes = inNotes;
        }

        /**
         * creates user from given user
         */
        public User(User other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _userKey = other.UserKey;
            _surname = other.Surname;
            _firstName = other.FirstName;
            _commenced = other.Commenced;
            _terminated = other.Terminated;
            _suspended = other.Suspended;
            _notes = other.Notes;
        }

        /**
         * tells whether the given obj is equal to this user
         */
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                User other = (User)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the hash value of the user
         */
        public override int GetHashCode()
        {
            return this.UserKey;
        }

        /**
         * gives the user as a string
         */
        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "User ID: " + this.UserKey.ToString();
            result += "\n" + "Surname: " + this.Surname;
            result += "\n" + "First Name" + this.FirstName;
            result += "\n " + "Commenced: " + this.Commenced.ToLongDateString();
            result += "\n " + "Terminated: " + this.Terminated.ToLongDateString();
            result += "\n " + "Suspended: " + this.Suspended.ToLongDateString();
            result += "\n " + "notes: " + this.Notes;
            return result;
        }
    }
}