﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class Warranty
    {
        private int _clientKey; //key for the client this relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //key for the Location this relates to
        private int _warrantyKey; //key for the warranty this relates to
        private string _warrantyType;//type of warranty
        private int _hardwareKey; //key for the hardware this relates to
        private bool _status;//whether is active or inactive
        private DateTime _startDate; // when warranty started
        private DateTime _warrentyExpires; // warranty expire date
        private string _quoteRef;//quote ref number
        private string _ticket;//ticket number oif warranty
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public int WarrantyKey
        {
            get
            {
                return _warrantyKey;
            }
        }

        public string WarrantyType
        {
            get
            {
                return _warrantyType;
            }

            set
            {
                _warrantyType = value;
            }
        }

        public int HardwareKey
        {
            get
            {
                return _hardwareKey;
            }

            set
            {
                _hardwareKey = value;
            }
        }

        public bool Status
        {
            get
            {
                return _status;
            }

            set
            {
                _status = value;
            }
        }

        public DateTime StartDate
        {
            get
            {
                return _startDate;
            }

            set
            {
                _startDate = value;
            }
        }

        public DateTime WarrentyExpires
        {
            get
            {
                return _warrentyExpires;
            }

            set
            {
                _warrentyExpires = value;
            }
        }

        public string QuoteRef
        {
            get
            {
                return _quoteRef;
            }

            set
            {
                _quoteRef = value;
            }
        }

        public string Ticket
        {
            get
            {
                return _ticket;
            }

            set
            {
                _ticket = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public Warranty()
        {
        }

        /**
         * creates warranty from given data
         */

        public Warranty(int inClientKey, int inSnapshotKey, int inLocationKey, int inWarrantyKey,
            string inWarrantyType, int inHardwareKey, bool inStatus, DateTime inStart, DateTime inExpire,
            string inQuoteRef, string inTicket, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _warrantyKey = inWarrantyKey;
            _warrantyType = inWarrantyType;
            _hardwareKey = inHardwareKey;
            _status = inStatus;
            _startDate = inStart;
            _warrentyExpires = inExpire;
            _quoteRef = inQuoteRef;
            _ticket = inTicket;
            _notes = inNotes;
        }

        /**
         * creates warranty from given warranty
         */

        public Warranty(Warranty other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _warrantyKey = other.WarrantyKey;
            _warrantyType = other.WarrantyType;
            _hardwareKey = other.HardwareKey;
            _status = other.Status;
            _startDate = other.StartDate;
            _warrentyExpires = other.WarrentyExpires;
            _quoteRef = other.QuoteRef;
            _ticket = other.Ticket;
            _notes = other.Notes;
        }

        /**
         * tells whether the given obj is equal to this warranty
         */

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                Warranty other = (Warranty)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the hash value of the warranty
         */

        public override int GetHashCode()
        {
            return this.WarrantyKey;
        }

        /**
         * gives the warrenty as a string
         */

        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "Warranty ID: " + this.WarrantyKey.ToString();
            result += "\n " + "warranty type: " + this.WarrantyType;
            result += "\n " + "hardware ID: " + this.HardwareKey.ToString();
            result += "\n " + "status: " + this.Status.ToString();
            result += "\n " + "Start date: " + this.StartDate.ToLongDateString();
            result += "\n " + "Warranty expirery: " + this.WarrentyExpires.ToLongDateString();            
            result += "\n " + "quote ref: " + this.QuoteRef;
            result += "\n " + "ticket: " + this.Ticket;
            result += "\n " + "notes: " + this.Notes;
            return result; ;
        }
    }
}