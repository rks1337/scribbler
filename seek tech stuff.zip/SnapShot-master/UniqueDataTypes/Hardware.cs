﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class Hardware
    {
        private int _clientKey; //key for the client snapshot relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //key for the Location this relates to
        private int _hardwareKey; //key for the hardware this relates to
        private string _categoryCode; //code for hardware
        private string _vendor; // vendor of hardware
        private string _deviceName; // device name
        private string _model; // device model
        private string _serialNumber; // serial number
        private DateTime _datePurchased; // date purchased
        private DateTime _warrentyExpires; // warranty expire date
        private DateTime _writtenOff; // date hardware written off
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public int HardwareKey
        {
            get
            {
                return _hardwareKey;
            }
        }

        public string CategoryCode
        {
            get
            {
                return _categoryCode;
            }

            set
            {
                _categoryCode = value;
            }
        }

        public string Vendor
        {
            get
            {
                return _vendor;
            }

            set
            {
                _vendor = value;
            }
        }

        public string DeviceName
        {
            get
            {
                return _deviceName;
            }

            set
            {
                _deviceName = value;
            }
        }

        public string Model
        {
            get
            {
                return _model;
            }

            set
            {
                _model = value;
            }
        }

        public string SerialNumber
        {
            get
            {
                return _serialNumber;
            }

            set
            {
                _serialNumber = value;
            }
        }

        public DateTime DatePurchased
        {
            get
            {
                return _datePurchased;
            }

            set
            {
                _datePurchased = value;
            }
        }

        public DateTime WarrentyExpires
        {
            get
            {
                return _warrentyExpires;
            }

            set
            {
                _warrentyExpires = value;
            }
        }

        public DateTime WrittenOff
        {
            get
            {
                return _writtenOff;
            }

            set
            {
                _writtenOff = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public Hardware()
        {
        }

        /**
         * creates a hardware from given data
         */

        public Hardware(int inClientKey, int inSnapshotKey, int inLocationKey, int inHardwareKey,
            string inCategoraryCode, string inVendor, string inDeviceName, string inModel,
            string inSerialNumber, DateTime inPurchased, DateTime inwarrentyExpires, DateTime inWrittenOffDate,
            string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _hardwareKey = inHardwareKey;
            _categoryCode = inCategoraryCode;
            _vendor = inVendor;
            _deviceName = inDeviceName;
            _model = inModel;
            _serialNumber = inSerialNumber;
            _datePurchased = inPurchased;
            _warrentyExpires = inwarrentyExpires;
            _writtenOff = inWrittenOffDate;
            _notes = inNotes;
        }

        /**
         * creates a copy of a hardware
         */

        public Hardware(Hardware other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _hardwareKey = other.HardwareKey;
            _categoryCode = other.CategoryCode;
            _vendor = other.Vendor;
            _deviceName = other.DeviceName;
            _model = other.Model;
            _serialNumber = other.SerialNumber;
            _datePurchased = other.DatePurchased;
            _warrentyExpires = other.WarrentyExpires;
            _writtenOff = other.WrittenOff;
            _notes = other.Notes;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                Hardware other = (Hardware)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        public override int GetHashCode()
        {
            return this.HardwareKey;
        }

        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "Hardware ID: " + this.HardwareKey.ToString();
            result += "\n " + "Catergorary: " + this.CategoryCode;
            result += "\n " + "Vendor: " + this.Vendor;
            result += "\n " + "DeviceName: " + this.DeviceName;
            result += "\n " + "Model: " + this.Model;
            result += "\n " + "Serial Number: " + this.SerialNumber;
            result += "\n " + "Purchased: " + this.DatePurchased.ToLongDateString();
            result += "\n " + "Warranty expirery: " + this.WarrentyExpires.ToLongDateString();
            result += "\n " + "Written off date: " + this.WrittenOff.ToLongDateString();
            result += "\n " + "notes: " + this.Notes;
            return result; ;
        }
    }
}