﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class Client
    {
        private int _clientKey; //clients id
        private string _businessName; //name of the bussiness
        private string _addressLine1; //1st line of clients address
        private string _addressLine2; //2nd line of clients address
        private string _addressLine3; //3rd line of clients address
        private string _addressLine4; //4th line of clients address
        private string _billingName; // where the bill is sent
        private bool _status;//whether client is active or inactive
        private string _notes;//additional notes about the client

        // setter getters for class variables
        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public string BusinessName
        {
            get
            {
                return _businessName;
            }

            set
            {
                _businessName = value;
            }
        }

        public string AddressLine1
        {
            get
            {
                return _addressLine1;
            }

            set
            {
                _addressLine1 = value;
            }
        }

        public string AddressLine2
        {
            get
            {
                return _addressLine2;
            }

            set
            {
                _addressLine2 = value;
            }
        }

        public string AddressLine3
        {
            get
            {
                return _addressLine3;
            }

            set
            {
                _addressLine3 = value;
            }
        }

        public string AddressLine4
        {
            get
            {
                return _addressLine4;
            }

            set
            {
                _addressLine4 = value;
            }
        }

        public string BillingName
        {
            get
            {
                return _billingName;
            }

            set
            {
                _billingName = value;
            }
        }

        public bool Status
        {
            get
            {
                return _status;
            }

            set
            {
                _status = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public Client()
        {
        }

        /**
         * creates a client with the given data
         */

        public Client(int inClientKey, string inBusinessName, string inAddressLine1, string inAddressLine2,
             string inAddressLine3, string inAddressLine4, string inBillingName, bool inStatus, string inNotes)
        {
            _clientKey = inClientKey;
            _businessName = inBusinessName;
            _addressLine1 = inAddressLine1;
            _addressLine2 = inAddressLine2;
            _addressLine3 = inAddressLine3;
            _addressLine4 = inAddressLine4;
            _billingName = inBillingName;
            _status = inStatus;
            _notes = inNotes;
        }

        /**
         * creates a client form the given client
         */

        public Client(Client other)
        {
            _clientKey = other.ClientKey;
            _businessName = other.BusinessName;
            _addressLine1 = other.AddressLine1;
            _addressLine2 = other.AddressLine2;
            _addressLine3 = other.AddressLine3;
            _addressLine4 = other.AddressLine4;
            _billingName = other.BillingName;
            _status = other.Status;
            _notes = other.Notes;
        }

        /**
         * returns true if object equals client
         */

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                Client other = (Client)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the clients key
         */

        public override int GetHashCode()
        {
            return this.ClientKey;
        }

        /**
         * gives the client as a string
         */

        public override string ToString()
        {
            string result = "";
            result += "ID: " + this.ClientKey.ToString();
            result += "\n " + "bussinessName: " + this.BusinessName;
            result += "\n " + "addressLine1: " + this.AddressLine1;
            result += "\n " + "addressLine2: " + this.AddressLine2;
            result += "\n " + "addressLine3: " + this.AddressLine3;
            result += "\n " + "addressLine4: " + this.AddressLine4;
            result += "\n " + "billingName: " + this.BillingName;
            result += "\n " + "status: " + this.Status.ToString();
            result += "\n " + "notes: " + this.Notes;
            return result;
        }
    }
}