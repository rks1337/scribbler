﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class SnapShot
    {
        private int _clientKey; //key for the client snapshot relates to
        private int _snapshotKey; //snapshot ID
        private DateTime _created;//when snapshot was created
        private DateTime _historic;//when snapshot expired
        private bool _status;//whether is active or inactive
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public DateTime Created
        {
            get
            {
                return _created;
            }

            set
            {
                _created = value;
            }
        }

        public DateTime Historic
        {
            get
            {
                return _historic;
            }

            set
            {
                _historic = value;
            }
        }

        public bool Status
        {
            get
            {
                return _status;
            }

            set
            {
                _status = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public SnapShot()
        {
        }

        /**
         * creates snapshot from given data
         */

        public SnapShot(int inClientKey, int inSnapshotKey, DateTime inCreated, DateTime inHistoric,
            bool inStatus, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _created = inCreated;
            _historic = inHistoric;
            _status = inStatus;
            _notes = inNotes;
        }

        /**
         * creates a copy of the other snapshot
         */

        public SnapShot(SnapShot other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _created = other.Created;
            _historic = other.Historic;
            _status = other.Status;
            _notes = other.Notes;
        }

        /**
         * gives the snap shot as a string
         */ 
        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Created: " + this.Created.ToLongDateString();
            result += "\n " + "Historic: " + this.Historic.ToLongDateString();
            result += "\n " + "status: " + this.Status.ToString();
            result += "\n " + "notes: " + this.Notes;
            return result;
        }

        /**
         * tests whether the given object is equal to this snapshot
         */ 
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                SnapShot other = (SnapShot)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the snapshots hash value
         */ 
        public override int GetHashCode()
        {
            return this.SnapshotKey;
        }
    }
}