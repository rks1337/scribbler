﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class EmailAddress
    {
        private int _clientKey; //key for the client this relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //Key for the Location this relates to
        private int _emailKey; //Key for the Email address this relates to
        private int _userKey; //Key for the User this relates to
        private string _emailAddressURL; //the url for the email address
        private string _mailBoxType; //the type of mailbox the email is
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public int EmailKey
        {
            get
            {
                return _emailKey;
            }
        }

        public int UserKey
        {
            get
            {
                return _userKey;
            }

            set
            {
                _userKey = value;
            }
        }

        public string EmailAddressURL
        {
            get
            {
                return _emailAddressURL;
            }

            set
            {
                _emailAddressURL = value;
            }
        }

        public string MailBoxType
        {
            get
            {
                return _mailBoxType;
            }

            set
            {
                _mailBoxType = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public EmailAddress()
        {
        }

        /**
         * creates email address based on given data
         */

        public EmailAddress(int inClientKey, int inSnapshotKey, int inLocationKey, int inEmailKey, int inUserKey, string inEmailAddressURL,
            string inMailBoxType, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _emailKey = inEmailKey;
            _userKey = inUserKey;
            _emailAddressURL = inEmailAddressURL;
            _mailBoxType = inMailBoxType;
            _notes = inNotes;
        }

        /**
         * creates a location copy
         */

        public EmailAddress(EmailAddress other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _emailKey = other.EmailKey;
            _userKey = other.UserKey;
            _emailAddressURL = other.EmailAddressURL;
            _mailBoxType = other.MailBoxType;
            _notes = other.Notes;
        }

        /**
         * gives the email address as a string
         */

        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "Email ID: " + this.EmailKey.ToString();
            result += "\n " + "User ID: " + this.UserKey.ToString();
            result += "\n " + "Email Address: " + this.EmailAddressURL;
            result += "\n " + "Mailbox Type: " + this.MailBoxType;
            result += "\n " + "Notes: " + this.Notes;
            return result;
        }

        /**
         * tests whetehr given object is equal to this email address
         */

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                EmailAddress other = (EmailAddress)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the hash value of the email address
         */

        public override int GetHashCode()
        {
            return this.EmailKey;
        }
    }
}