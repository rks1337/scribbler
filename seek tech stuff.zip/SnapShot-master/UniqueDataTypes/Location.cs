﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class Location
    {
        private int _clientKey; //key for the client snapshot relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //ID for the Location
        private string _description; //description of the location
        private string _enviroment; //enviroment of the location
        private string _notes;//additional notes

        //setters and getters
        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public string Enviroment
        {
            get
            {
                return _enviroment;
            }

            set
            {
                _enviroment = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public Location()
        {
        }

        /**
         * creates location based on given data
         */

        public Location(int inClientKey, int inSnapshotKey, int inLocationKey, string inDescription,
            string inEnviroment, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _description = inDescription;
            _enviroment = inEnviroment;
            _notes = inNotes;
        }

        /**
         * creates a location copy
         */

        public Location(Location other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _description = other.Description;
            _enviroment = other.Enviroment;
            _notes = other.Notes;
        }

        /**
         * gives the location as a string
         */ 
        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "Description: " + this.Description;
            result += "\n " + "Enviroment: " + this.Enviroment;
            result += "\n " + "notes: " + this.Notes;
            return result;
        }

        /**
         * tests whether the given object is equal to this location
         */ 
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                Location other = (Location)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the locations hash value
         */ 
        public override int GetHashCode()
        {
            return this.LocationKey;
        }
    }
}