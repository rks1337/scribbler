﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class SupportAgreement
    {
        private int _clientKey; //key for the client snapshot relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //key for the Location this relates to
        private int _agreementKey; //key for the Location this relates to
        private string _description; //description of the agreement
        private DateTime _commencement;//when support agreement was commenced
        private DateTime _expiryDate;//when support agreement expires
        private bool _status;//whether is active or inactive
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public int AgreementKey
        {
            get
            {
                return _agreementKey;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public DateTime Commencement
        {
            get
            {
                return _commencement;
            }

            set
            {
                _commencement = value;
            }
        }

        public DateTime ExpiryDate
        {
            get
            {
                return _expiryDate;
            }

            set
            {
                _expiryDate = value;
            }
        }

        public bool Status
        {
            get
            {
                return _status;
            }

            set
            {
                _status = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public SupportAgreement()
        {
        }

        /**
         * creates a support agreement from the given data
         */ 
        public SupportAgreement(int inClientKey, int inSnapshotKey, int inLocationKey, int inAgreementKey,
            string inDescription, bool inStasus, DateTime inCommencement, DateTime inExpiryDate, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _agreementKey = inAgreementKey;
            _description = inDescription;
            _status = inStasus;
            _commencement = inCommencement;
            _expiryDate = inExpiryDate;
            _notes = inNotes;
        }

        /**
         * creates a copy of the given support agreement
         */ 
        public SupportAgreement(SupportAgreement other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _agreementKey = other.AgreementKey;
            _description = other.Description;
            _status = other.Status;
            _commencement = other.Commencement;
            _expiryDate = other.ExpiryDate;
            _notes = other.Notes;
        }

        /**
         * tests whether the given object is equal to this support agreement
         */ 
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                SupportAgreement other = (SupportAgreement)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the support agreements hash value
         */ 
        public override int GetHashCode()
        {
            return this.AgreementKey;
        }

        /**
         * gives the support argeement as a string
         */ 
        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "Agreement ID: " + this.AgreementKey.ToString();
            result += "\n " + "Description: " + this.Description;
            result += "\n " + "Status: " + this.Status.ToString();
            result += "\n " + "Commenced: " + this.Commencement.ToLongDateString();
            result += "\n " + "Expired: " + this.ExpiryDate.ToLongDateString();
            result += "\n " + "notes: " + this.Notes;
            return result;
        }
    }
}