﻿using System;

namespace SnapShot.UniqueDataTypes
{
    public class CommunicationLink
    {
        private int _clientKey; //key for the client this relates to
        private int _snapshotKey; //key for the snapshot this relates to
        private int _locationKey; //key for the Location this relates to
        private int _communicationLinkKey; //key for the communication link this relates to
        private string _communicationVendor; // seller of the link
        private string _linkType; //what type of link this is
        private string _speed; //how many bits per second the connection is limited to
        private int _hardwareKey; //key for the hardware this relates to
        private bool _connectivityAgreement; //whether is active or inactive
        private DateTime _commenced;//when snapshot was created
        private int _term; //how many months the link lasts for
        private DateTime _expire;//expire date
        private string _notes;//additional notes

        public int ClientKey
        {
            get
            {
                return _clientKey;
            }
        }

        public int SnapshotKey
        {
            get
            {
                return _snapshotKey;
            }
        }

        public int LocationKey
        {
            get
            {
                return _locationKey;
            }
        }

        public int CommunicationLinkKey
        {
            get
            {
                return _communicationLinkKey;
            }
        }

        public string CommunicationVendor
        {
            get
            {
                return _communicationVendor;
            }

            set
            {
                _communicationVendor = value;
            }
        }

        public string LinkType
        {
            get
            {
                return _linkType;
            }

            set
            {
                _linkType = value;
            }
        }

        public string Speed
        {
            get
            {
                return _speed;
            }

            set
            {
                _speed = value;
            }
        }

        public int HardwareKey
        {
            get
            {
                return _hardwareKey;
            }

            set
            {
                _hardwareKey = value;
            }
        }

        public bool ConnectivityAgreement
        {
            get
            {
                return _connectivityAgreement;
            }

            set
            {
                _connectivityAgreement = value;
            }
        }

        public DateTime Commenced
        {
            get
            {
                return _commenced;
            }

            set
            {
                _commenced = value;
            }
        }

        public int Term
        {
            get
            {
                return _term;
            }

            set
            {
                _term = value;
            }
        }

        public DateTime Expire
        {
            get
            {
                return _expire;
            }

            set
            {
                _expire = value;
            }
        }

        public string Notes
        {
            get
            {
                return _notes;
            }

            set
            {
                _notes = value;
            }
        }

        public CommunicationLink()
        {
        }

        /**
         * creates CommunicationLink from the given data
         */

        public CommunicationLink(int inClientKey, int inSnapshotKey, int inLocationKey, int incommunicationLinkKey,
            string inVendor, string inLinkType, string inSpeed, int inHardwareKey, bool inConnectAgree,
            DateTime inCommenced, int inTerm, DateTime inExpire, string inNotes)
        {
            _clientKey = inClientKey;
            _snapshotKey = inSnapshotKey;
            _locationKey = inLocationKey;
            _communicationLinkKey = incommunicationLinkKey;
            _communicationVendor = inVendor;
            _linkType = inLinkType;
            _speed = inSpeed;
            _hardwareKey = inHardwareKey;
            _connectivityAgreement = inConnectAgree;
            _commenced = inCommenced;
            _term = inTerm;
            _expire = inExpire;
            _notes = inNotes;
        }

        /**
         * creates CommunicationLink from given CommunicationLink
         */

        public CommunicationLink(CommunicationLink other)
        {
            _clientKey = other.ClientKey;
            _snapshotKey = other.SnapshotKey;
            _locationKey = other.LocationKey;
            _communicationLinkKey = other.CommunicationLinkKey;
            _communicationVendor = other.CommunicationVendor;
            _linkType = other.LinkType;
            _speed = other.Speed;
            _hardwareKey = other.HardwareKey;
            _connectivityAgreement = other.ConnectivityAgreement;
            _commenced = other.Commenced;
            _term = other.Term;
            _expire = other.Expire;
            _notes = other.Notes;
        }

        /**
         * tests whether the given object is equal to this communication link
         */ 
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }
            if (obj.GetType() == this.GetType())
            {
                CommunicationLink other = (CommunicationLink)obj;
                if (other.ToString().Equals(this.ToString()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /**
         * gives the communication links hash value
         */ 
        public override int GetHashCode()
        {
            return this.CommunicationLinkKey;
        }

        /**
         * gives the communication link as a string
         */ 
        public override string ToString()
        {
            string result = "";
            result += "Client ID: " + this.ClientKey.ToString();
            result += "\n " + "Snapshot ID: " + this.SnapshotKey.ToString();
            result += "\n " + "Location ID: " + this.LocationKey.ToString();
            result += "\n " + "Communication link ID: " + this.CommunicationLinkKey.ToString();
            result += "\n " + "Vendor: " + this._communicationVendor;
            result += "\n " + "Link type: " + this.LinkType;
            result += "\n " + "Speed: " + this.Speed;
            result += "\n " + "hardware ID: " + this.HardwareKey.ToString();
            result += "\n " + "Connectivity Agreement: " + this.ConnectivityAgreement.ToString();
            result += "\n " + "Commenced: " + this.Commenced.ToLongDateString();
            result += "\n " + "Term: " + this.LocationKey.ToString();
            result += "\n " + "Expire date: " + this.Expire.ToLongDateString();
            result += "\n " + "notes: " + this.Notes;
            return result;
        }
    }
}