﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Data.Entity;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace snap_shot_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public Client client { get; set; }
        SnapShot_DBEntities snapshot_DBEntities = new SnapShot_DBEntities();
        System.Windows.Data.CollectionViewSource clientViewSource;
        List<Client> client_search_result = new List<Client>();
        String client_business_name;



        public MainWindow()
        {
            InitializeComponent();
            clientViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("clientViewSource")));
            DataContext = this;
            load_client_list();
        }

        private void load_client_list()
        {
            IQueryable<Client> Query = snapshot_DBEntities.Clients;
            client_search_result = Query.ToList();
            Console.WriteLine(Query.ToList().Count);
            foreach (Client c in client_search_result)
            {
                client_list_view.Items.Add(new ClientView() { business_name = "  " + c.business_name });
            }
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Load data by setting the CollectionViewSource.Source property:
            clientViewSource.Source = snapshot_DBEntities.Clients.Local;
            snapshot_DBEntities.Clients.Load();
        }

        private void exit_button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        #region asset button click events
        private void all_items_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(all_items_button.Name);
        }

        private void hardware_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(hardware_button.Name);
        }

        private void licenses_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(licenses_button.Name);
        }

        private void users_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(users_button.Name);
        }

        private void comm_links_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(comm_links_button.Name);
        }

        private void warranty_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(warranty_button.Name);
        }

        private void support_agreement_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(support_agreement_button.Name);
        }

        private void emails_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(emails_button.Name);
        }
        #endregion

        private void change_asset_button_style(string buttonName)
        {
            int count = asset_stack_panel.Children.Count;

            for (int i = 0; i < count; i++)
            {
                if (asset_stack_panel.Children[i] is Button && ((Button)asset_stack_panel.Children[i]).Name.Equals(buttonName, StringComparison.OrdinalIgnoreCase))
                {
                    ((Button)asset_stack_panel.Children[i]).Background = Brushes.White;
                }
                if (asset_stack_panel.Children[i] is Button && !((Button)asset_stack_panel.Children[i]).Name.Equals(buttonName, StringComparison.OrdinalIgnoreCase))
                {
                    ((Button)asset_stack_panel.Children[i]).Background = Brushes.Transparent;
                }
            }
        }

        private void client_searchbox_KeyDown(object sender, KeyEventArgs e)
        {
            client_list_view.Items.Clear();

            IQueryable<Client> Query = snapshot_DBEntities.Clients;

            if (!string.IsNullOrEmpty(client_searchbox.Text))
                Query = Query.Where(c => c.business_name.Contains(client_searchbox.Text));

            client_search_result = Query.ToList();

            foreach (Client c in client_search_result)
            {
                client_list_view.Items.Add(new ClientView() { business_name = "  " + c.business_name });
            }
        }

        private void client_list_view_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var selected = this.client_list_view.SelectedItem as ClientView;
            client_business_name = selected.business_name;
            change_asset_button_style(all_items_button.Name);
            working_client_label.Content = client_business_name;
            tab_control.SelectedIndex = 1;
        }

        private void client_searchbox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            client_list_view.Items.Clear();
            tab_control.SelectedIndex = 0;

            IQueryable<Client> Query = snapshot_DBEntities.Clients;

            if (!string.IsNullOrEmpty(client_searchbox.Text))
                Query = Query.Where(c => c.business_name.Contains(client_searchbox.Text));

            client_search_result = Query.ToList();

            foreach (Client c in client_search_result)
            {
                client_list_view.Items.Add(new ClientView() { business_name = "  " + c.business_name });
            }
        }
    }

    public class ClientView
    {
        public string business_name { get; set; }
    }

    public class MultiplyConverter : IMultiValueConverter
    {
        public MultiplyConverter()
        {
        }

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            double result = 1.0;
            for (int i = 0; i < values.Length; i++)
            {
                if (values[i] is double)
                    result *= (double)values[i];
            }

            return result;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new Exception("Not implemented");
        }
    }
}