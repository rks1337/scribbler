CREATE TABLE Location (
  location_key INTEGER   NOT NULL ,
  client_key INTEGER   NOT NULL   ,
  location_description VARCHAR(50)   ,
  environment VARCHAR(50)    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(location_key));




CREATE TABLE Support_Agreement (
  agreement_key INTEGER   NOT NULL ,
  location_key INTEGER   NOT NULL ,
  agreement_description VARCHAR(50)    ,
  status BIT    ,
  commencement_date DATE    ,
  expiry_date DATE    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(agreement_key));




CREATE TABLE Warranty (
  warranty_key INTEGER   NOT NULL ,
  location_key INTEGER   NOT NULL ,
  warranty_type VARCHAR(3)    ,
  status_1 BIT    ,
  start_date DATE    ,
  expiry_date DATE    ,
  quote_reference VARCHAR(10)    ,
  ticket_number VARCHAR(10)    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(warranty_key));




CREATE TABLE [User] (
  user_key INTEGER   NOT NULL ,
  location_key INTEGER   NOT NULL ,
  surname VARCHAR(20)   NOT NULL ,
  firstname VARCHAR(20)   NOT NULL ,
  commencement_date DATE    ,
  termination_date DATE    ,
  suspend_date DATE    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(user_key));




CREATE TABLE Communication_Link (
  communication_link_key INTEGER   NOT NULL ,
  location_key INTEGER   NOT NULL ,
  communication_vendor VARCHAR(3)   NOT NULL ,
  link_type VARCHAR(10)    ,
  speed VARCHAR(8)    ,
  connectivity_agreement BIT    ,
  commencement_date DATE    ,
  term_months INTEGER    ,
  expiry_date DATE    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(communication_link_key));




CREATE TABLE Client (
  client_key INTEGER   NOT NULL ,
  business_name VARCHAR(50)   NOT NULL ,
  street VARCHAR(50)    ,
  suburb VARCHAR(50)    ,
  state VARCHAR(30)    ,
  postcode VARCHAR(6)    ,
  billing_name VARCHAR(50)    ,
  status BIT    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(client_key));




CREATE TABLE Email_Address (
  email_key INTEGER   NOT NULL ,
  location_key INTEGER   NOT NULL ,
  email_address VARCHAR(50)   NOT NULL ,
  mailbox_type VARCHAR(3)    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(email_key));




CREATE TABLE License (
  license_key INTEGER   NOT NULL ,
  location_key INTEGER   NOT NULL ,
  license_code VARCHAR(3)   NOT NULL ,
  license_category VARCHAR(50)    ,
  product_description VARCHAR(50)    ,
  subscription_type VARCHAR(4)    ,
  pack_cores INTEGER    ,
  quantity INTEGER    ,
  licenses_purchased INTEGER    ,
  licenses_allocated INTEGER    ,
  vendor_allocated_key VARCHAR(3)    ,
  date_purchased DATE    ,
  expiry_date DATE    ,
  quote_reference VARCHAR(10)    ,
  ticket_number INTEGER    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(license_key));




CREATE TABLE Hardware (
  hardware_key INTEGER   NOT NULL ,
  location_key INTEGER   NOT NULL ,
  category_code VARCHAR(3)    ,
  vendor VARCHAR(50)    ,
  device_name VARCHAR(50)    ,
  model VARCHAR(50)    ,
  serial_number VARCHAR(20)    ,
  client_asset_number VARCHAR(20)    ,
  date_purchased DATE    ,
  warranty_expiry DATE    ,
  date_written_off DATE    ,
  notes VARCHAR(50)      ,
PRIMARY KEY(hardware_key));
