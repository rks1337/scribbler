﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Data.Entity;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace snap_shot_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public Client client { get; set; }
        SnapShot_DBEntities snapshot_DBEntities = new SnapShot_DBEntities();
        System.Windows.Data.CollectionViewSource clientViewSource;
        List<Client> client_search_result = new List<Client>();
        String client_business_name;

        public MainWindow()
        {
            InitializeComponent();
            clientViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("clientViewSource")));
            DataContext = this;
            load_client_list();

            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Ideal);

            //disable asset selection buttons
            all_items_button.IsEnabled = false;
            hardware_button.IsEnabled = false;
            licenses_button.IsEnabled = false;
            users_button.IsEnabled = false;
            comm_links_button.IsEnabled = false;
            warranty_button.IsEnabled = false;
            support_agreement_button.IsEnabled = false;
            emails_button.IsEnabled = false;
        }

        private void load_client_list()
        {
            IQueryable<Client> Query = snapshot_DBEntities.Clients;
            client_search_result = Query.ToList();
            Console.WriteLine(Query.ToList().Count);
            foreach (Client c in client_search_result)
            {
                client_list_view.Items.Add(new ClientView() { business_name = c.business_name });
            }
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Load data by setting the CollectionViewSource.Source property:
            clientViewSource.Source = snapshot_DBEntities.Clients.Local;
            snapshot_DBEntities.Clients.Load();
        }

        private void exit_button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        #region asset button click events

        // needs stored function
        private void all_items_button_Click(object sender, RoutedEventArgs e)
        {
            change_asset_button_style(all_items_button.Name);
        }

        private void hardware_button_Click(object sender, RoutedEventArgs e)
        {
            var join = (from h in snapshot_DBEntities.Hardwares
                        join l in snapshot_DBEntities.Locations
                        on h.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == client_business_name
                        select h).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(hardware_button.Name);
            working_client_label.Content = client_business_name + " • All Locations • Hardware";

            if (tab_control.SelectedIndex != 1)
                tab_control.SelectedIndex = 1;
        }

        private void licenses_button_Click(object sender, RoutedEventArgs e)
        {
            var join = (from li in snapshot_DBEntities.Licenses
                        join l in snapshot_DBEntities.Locations
                        on li.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == client_business_name
                        select li).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(licenses_button.Name);
            working_client_label.Content = client_business_name + " • All Locations • Licenses";

            if (tab_control.SelectedIndex != 1)
                tab_control.SelectedIndex = 1;
        }

        private void users_button_Click(object sender, RoutedEventArgs e)
        {
            var join = (from u in snapshot_DBEntities.Users
                        join l in snapshot_DBEntities.Locations
                        on u.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == client_business_name
                        select u).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(users_button.Name);
            working_client_label.Content = client_business_name + " • All Locations • Users";

            if (tab_control.SelectedIndex != 1)
                tab_control.SelectedIndex = 1;
        }

        private void comm_links_button_Click(object sender, RoutedEventArgs e)
        {
            var join = (from cl in snapshot_DBEntities.Communication_Link
                        join l in snapshot_DBEntities.Locations
                        on cl.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == client_business_name
                        select cl).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(comm_links_button.Name);
            working_client_label.Content = client_business_name + " • All Locations • Comm-Links";

            if (tab_control.SelectedIndex != 1)
                tab_control.SelectedIndex = 1;
        }

        private void warranty_button_Click(object sender, RoutedEventArgs e)
        {
            var join = (from w in snapshot_DBEntities.Warranties
                        join l in snapshot_DBEntities.Locations
                        on w.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == client_business_name
                        select w).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(warranty_button.Name);
            working_client_label.Content = client_business_name + " • All Locations • Warranties";

            if (tab_control.SelectedIndex != 1)
                tab_control.SelectedIndex = 1;
        }

        private void support_agreement_button_Click(object sender, RoutedEventArgs e)
        {
            var join = (from sa in snapshot_DBEntities.Support_Agreement
                        join l in snapshot_DBEntities.Locations
                        on sa.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == client_business_name
                        select sa).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(support_agreement_button.Name);
            working_client_label.Content = client_business_name + " • All Locations • Support Agreements";

            if (tab_control.SelectedIndex != 1)
                tab_control.SelectedIndex = 1;
        }

        private void emails_button_Click(object sender, RoutedEventArgs e)
        {
            var join = (from ea in snapshot_DBEntities.Email_Address
                        join l in snapshot_DBEntities.Locations
                        on ea.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == client_business_name
                        select ea).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(emails_button.Name);
            working_client_label.Content = client_business_name + " • All Locations • Emails";

            if (tab_control.SelectedIndex != 1)
                tab_control.SelectedIndex = 1;
        }
        #endregion

        private void change_asset_button_style(string buttonName)
        {
            int count = asset_stack_panel.Children.Count;

            for (int i = 0; i < count; i++)
            {
                if (asset_stack_panel.Children[i] is Button && ((Button)asset_stack_panel.Children[i]).Name.Equals(buttonName, StringComparison.OrdinalIgnoreCase))
                {
                    ((Button)asset_stack_panel.Children[i]).Background = Brushes.White;
                }
                if (asset_stack_panel.Children[i] is Button && !((Button)asset_stack_panel.Children[i]).Name.Equals(buttonName, StringComparison.OrdinalIgnoreCase))
                {
                    ((Button)asset_stack_panel.Children[i]).Background = Brushes.Transparent;
                }
            }
        }

        //search clients while user is typing
        private void client_searchbox_KeyDown(object sender, KeyEventArgs e)
        {
            client_list_view.Items.Clear();

            IQueryable<Client> Query = snapshot_DBEntities.Clients;

            if (!string.IsNullOrEmpty(client_searchbox.Text))
                Query = Query.Where(c => c.business_name.Contains(client_searchbox.Text));

            client_search_result = Query.ToList();

            foreach (Client c in client_search_result)
            {
                client_list_view.Items.Add(new ClientView() { business_name = c.business_name });
            }
        }

        //display client list when user clicks search box
        private void client_searchbox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            client_list_view.Items.Clear();
            tab_control.SelectedIndex = 0;

            IQueryable<Client> Query = snapshot_DBEntities.Clients;

            if (!string.IsNullOrEmpty(client_searchbox.Text))
                Query = Query.Where(c => c.business_name.Contains(client_searchbox.Text));

            client_search_result = Query.ToList();

            foreach (Client c in client_search_result)
            {
                client_list_view.Items.Add(new ClientView() { business_name = c.business_name });
            }

            int count = asset_stack_panel.Children.Count;

            for (int i = 0; i < count; i++)
            {
                if (asset_stack_panel.Children[i] is Button)
                {
                    ((Button)asset_stack_panel.Children[i]).Background = Brushes.Transparent;
                }
            }

            working_client_label.Content = "Select Client";

        }

        //select client function
        private void client_list_view_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var selected = this.client_list_view.SelectedItem as ClientView;
            var join = (from h in snapshot_DBEntities.Hardwares
                        join l in snapshot_DBEntities.Locations
                        on h.location_key equals l.location_key
                        join c in snapshot_DBEntities.Clients
                        on l.client_key equals c.client_key
                        where c.business_name == selected.business_name
                        select h).ToList();
            asset_data_grid.ItemsSource = join;

            change_asset_button_style(hardware_button.Name);
            client_business_name = selected.business_name;
            working_client_label.Content = selected.business_name + " • All Locations • Hardware";

            //enable asset selection buttons
            hardware_button.IsEnabled = true;
            licenses_button.IsEnabled = true;
            users_button.IsEnabled = true;
            comm_links_button.IsEnabled = true;
            warranty_button.IsEnabled = true;
            support_agreement_button.IsEnabled = true;
            emails_button.IsEnabled = true;

            tab_control.SelectedIndex = 1;
        }
    }

    public class ClientView
    {
        public string business_name { get; set; }
    }

    public class MultiplyConverter : IMultiValueConverter
    {
        public MultiplyConverter()
        {
        }

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            double result = 1.0;
            for (int i = 0; i < values.Length; i++)
            {
                if (values[i] is double)
                    result *= (double)values[i];
            }

            return result;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new Exception("Not implemented");
        }
    }
}